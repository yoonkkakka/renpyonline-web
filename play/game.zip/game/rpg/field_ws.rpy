# 표준 라이브러리(socket/ssl)만으로 만든 최소 WebSocket 클라이언트 (PC 빌드 전용).
# RFC6455 최소 구현: 핸드셰이크 + 텍스트 프레임 송수신 + 핑퐁. 재연결/조각화는 v1 범위 밖.

init -6 python:
    import os
    import struct as _struct
    import threading as _threading
    import queue as _queue
    import base64 as _b64
    import json as _json
    import hashlib as _hashlib

    # socket/ssl 은 웹(emscripten)에는 없고, 일부 PC 환경에서도 OpenSSL 라이브러리가
    # 없으면 import 자체가 실패할 수 있다. 여기서 실패해도 게임 전체가 죽지 않도록
    # 감싸두고, 실제로 필드에 들어가려 할 때만(FieldSocket.connect) 못 쓴다고 알려준다.
    _socket = None
    _ssl = None
    if renpy.windows:
        try:
            import socket as _socket
            import ssl as _ssl
        except Exception:
            _socket = None
            _ssl = None

    _WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

    class FieldSocketError(Exception):
        pass

    class FieldSocket(object):
        """하나의 /ws/field 연결. connect() 는 블로킹(핸드셰이크까지만),
        이후 수신은 백그라운드 스레드가 담당하고 inbox 큐로 전달한다."""

        def __init__(self):
            self.sock = None
            self.thread = None
            self.inbox = _queue.Queue()
            self.connected = False
            self._send_lock = _threading.Lock()
            self._closing = False

        def connect(self, host, port, path, use_tls, timeout=15):
            if _socket is None:
                raise FieldSocketError(u"이 환경에서는 실시간 필드 접속을 지원하지 않아요.")
            raw = _socket.create_connection((host, port), timeout=timeout)
            if use_tls:
                cafile = os.path.join(config.gamedir, "cacert.pem")
                ctx = _ssl.create_default_context(cafile=cafile if os.path.exists(cafile) else None)
                sock = ctx.wrap_socket(raw, server_hostname=host)
            else:
                sock = raw
            key = _b64.b64encode(os.urandom(16)).decode("ascii")
            req = (
                "GET %s HTTP/1.1\r\n"
                "Host: %s\r\n"
                "Upgrade: websocket\r\n"
                "Connection: Upgrade\r\n"
                "Sec-WebSocket-Key: %s\r\n"
                "Sec-WebSocket-Version: 13\r\n"
                "\r\n"
            ) % (path, host, key)
            sock.sendall(req.encode("utf-8"))
            resp = self._read_http_headers(sock)
            if "101" not in resp.split("\r\n", 1)[0]:
                sock.close()
                raise FieldSocketError(u"핸드셰이크 실패: %s" % resp.splitlines()[0])
            expect = _b64.b64encode(_hashlib.sha1((key + _WS_GUID).encode("ascii")).digest()).decode("ascii")
            if expect.lower() not in resp.lower():
                sock.close()
                raise FieldSocketError(u"핸드셰이크 서명 불일치")
            sock.settimeout(None)
            self.sock = sock
            self.connected = True
            self.thread = _threading.Thread(target=self._recv_loop, daemon=True)
            self.thread.start()

        def _read_http_headers(self, sock):
            data = b""
            sock.settimeout(15)
            while b"\r\n\r\n" not in data:
                chunk = sock.recv(4096)
                if not chunk:
                    break
                data += chunk
            return data.decode("iso-8859-1", errors="replace")

        # ── 프레임 인코딩/디코딩 ──────────────────────────
        def _send_frame(self, opcode, payload):
            if not self.sock:
                return
            mask = os.urandom(4)
            length = len(payload)
            if length <= 125:
                header = _struct.pack("!BB", 0x80 | opcode, 0x80 | length)
            elif length <= 0xFFFF:
                header = _struct.pack("!BBH", 0x80 | opcode, 0x80 | 126, length)
            else:
                header = _struct.pack("!BBQ", 0x80 | opcode, 0x80 | 127, length)
            masked = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
            with self._send_lock:
                self.sock.sendall(header + mask + masked)

        def send_json(self, obj):
            try:
                self._send_frame(0x1, _json.dumps(obj).encode("utf-8"))
            except Exception:
                self.connected = False

        def _recv_exact(self, n):
            buf = b""
            while len(buf) < n:
                chunk = self.sock.recv(n - len(buf))
                if not chunk:
                    raise FieldSocketError("connection closed")
                buf += chunk
            return buf

        def _recv_loop(self):
            try:
                while not self._closing:
                    b1, b2 = self._recv_exact(2)
                    opcode = b1 & 0x0F
                    length = b2 & 0x7F
                    if length == 126:
                        (length,) = _struct.unpack("!H", self._recv_exact(2))
                    elif length == 127:
                        (length,) = _struct.unpack("!Q", self._recv_exact(8))
                    payload = self._recv_exact(length) if length else b""
                    if opcode == 0x8:   # close
                        break
                    elif opcode == 0x9:   # ping -> pong
                        self._send_frame(0xA, payload)
                    elif opcode == 0x1:   # text
                        try:
                            self.inbox.put(_json.loads(payload.decode("utf-8")))
                        except Exception:
                            pass
                    # 0xA(pong)/조각화 프레임은 v1에서 무시
            except Exception:
                pass
            finally:
                self.connected = False
                self.inbox.put({"t": "_closed"})

        def poll(self):
            """받은 메시지를 리스트로 한 번에 비워서 반환(메인 스레드에서 매 틱 호출)."""
            out = []
            try:
                while True:
                    out.append(self.inbox.get_nowait())
            except _queue.Empty:
                pass
            return out

        def close(self):
            self._closing = True
            try:
                if self.sock:
                    self._send_frame(0x8, b"")
                    self.sock.close()
            except Exception:
                pass
            self.connected = False
