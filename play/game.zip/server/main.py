"""렌파이 온라인 백엔드 (FastAPI). 실행: uvicorn main:app --host 127.0.0.1 --port 8000

Ren'Py 의 renpy.fetch 는 HTTP 오류 본문을 읽기 어려워서, 모든 응답을 HTTP 200 으로 주고
{"ok": false, "error": "..."} 형태로 실패를 알린다.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import secrets
import time
import uuid
from pathlib import Path

from fastapi import Depends, FastAPI, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

import rules as R
from store import LOCK, make_repo

# .env 간이 로더
_env = Path(__file__).parent / ".env"
if _env.exists():
    for line in _env.read_text(encoding="utf-8").splitlines():
        if "=" in line and not line.strip().startswith("#"):
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())

DEV = os.getenv("DEV_MODE") == "1"
ON_RENDER = bool(os.getenv("RENDER"))
if ON_RENDER and not (os.getenv("SUPABASE_URL") and os.getenv("SUPABASE_KEY")):
    # Render 디스크는 재배포/재시작 때 초기화되므로 로컬 JSON 저장소를 쓰면 데이터가 사라진다.
    raise RuntimeError("Render 에서는 SUPABASE_URL / SUPABASE_KEY 환경변수가 필수입니다.")
if ON_RENDER and not os.getenv("TOKEN_SECRET"):
    raise RuntimeError("Render 에서는 TOKEN_SECRET 환경변수가 필수입니다(재시작해도 로그인이 유지되도록).")
SECRET = (os.getenv("TOKEN_SECRET") or "").encode() or secrets.token_bytes(32)
TOKEN_TTL = 60 * 60 * 24 * 30
AVATAR_MAX_CHARS = 1_500_000   # data URL 문자열 최대 길이

repo = make_repo()
app = FastAPI(title="Renpy Online")

# 웹 게임/공식 홈페이지(브라우저)에서 이 API 를 부를 수 있게 허용. 추가 도메인은 CORS_ORIGINS 환경변수(쉼표 구분)로.
_ORIGINS = ["https://xn--oi2brkg57a6hbwa498o.kro.kr", "https://renpyonline.com", "https://www.renpyonline.com", "https://yoonkkakka.github.io",
            "http://localhost:8080", "http://127.0.0.1:8080"]
_ORIGINS += [o.strip() for o in (os.getenv("CORS_ORIGINS") or "").split(",") if o.strip()]
app.add_middleware(CORSMiddleware, allow_origins=_ORIGINS, allow_methods=["GET", "POST", "PUT", "OPTIONS"],
                   allow_headers=["Authorization", "Content-Type"], max_age=600)

_REG_LOG: dict[str, list[float]] = {}
REG_LIMIT, REG_WINDOW = 5, 3600      # IP 당 1시간에 5번까지 가입 시도


def client_ip(req: Request) -> str:
    fwd = req.headers.get("x-forwarded-for", "")
    return (fwd.split(",")[0].strip() if fwd else (req.client.host if req.client else "?"))


@app.get("/health")
def health():
    return {"ok": True}


class ApiError(Exception):
    def __init__(self, msg: str):
        self.msg = msg


@app.exception_handler(ApiError)
async def _api_error(_: Request, e: ApiError):
    return JSONResponse({"ok": False, "error": e.msg})


# ── 인증 ─────────────────────────────────────────────────────
def hash_pw(pw: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    h = hashlib.scrypt(pw.encode(), salt=salt, n=2**14, r=8, p=1)
    return salt.hex() + "$" + h.hex()


def check_pw(pw: str, stored: str) -> bool:
    if "$" not in stored:
        return False
    salt, h = stored.split("$")
    return hmac.compare_digest(hashlib.scrypt(pw.encode(), salt=bytes.fromhex(salt), n=2**14, r=8, p=1).hex(), h)


def make_token(pid: str) -> str:
    body = f"{pid}.{int(time.time()) + TOKEN_TTL}"
    sig = hmac.new(SECRET, body.encode(), hashlib.sha256).hexdigest()
    return f"{body}.{sig}"


def current_player(authorization: str = Header(default="")) -> dict:
    token = authorization.removeprefix("Bearer ").strip()
    try:
        pid, exp, sig = token.rsplit(".", 2)
        good = hmac.new(SECRET, f"{pid}.{exp}".encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, good) or int(exp) < time.time():
            raise ValueError
    except ValueError:
        raise ApiError("로그인이 필요합니다.")
    p = repo.get_by_id(pid)
    if not p:
        raise ApiError("계정을 찾을 수 없습니다.")
    return p


# ── 도우미 ───────────────────────────────────────────────────
def add_exp(p: dict, amount: int) -> int:
    """경험치를 더하고 레벨업 처리. 오른 레벨 수를 반환."""
    if p["level"] >= R.MAX_LEVEL:
        return 0
    p["exp"] += int(amount)
    ups = 0
    while p["level"] < R.MAX_LEVEL and p["exp"] >= R.exp_to_next(p["level"]):
        p["exp"] -= R.exp_to_next(p["level"])
        p["level"] += 1
        ups += 1
    if p["level"] >= R.MAX_LEVEL:
        p["exp"] = 0
    return ups


def today_kst() -> str:
    return time.strftime("%Y-%m-%d", time.gmtime(time.time() + R.KST_OFFSET))


def yesterday_kst() -> str:
    return time.strftime("%Y-%m-%d", time.gmtime(time.time() + R.KST_OFFSET - 86400))


def get_extra(p: dict) -> dict:
    """p["extra"] 를 기본값으로 채우고, 날짜가 바뀌었으면 일일 미션을 초기화한다."""
    e = p.get("extra") or {}
    e.setdefault("pvp", {})
    pv = e["pvp"]
    pv.setdefault("rating", R.PVP_START_RATING)
    pv.setdefault("wins", 0)
    pv.setdefault("losses", 0)
    pv.setdefault("coins", 0)
    pv.setdefault("log", [])
    e.setdefault("checkin", {"last": "", "streak": 0})
    e.setdefault("awake", {k: 0 for k in R.BODY_IDS})
    e.setdefault("crystals", 0)
    d = e.get("daily")
    if not d or d.get("date") != today_kst():
        d = {"date": today_kst(), "prog": {m["id"]: 0 for m in R.DAILY_MISSIONS}, "claimed": [], "bonus": False}
    e["daily"] = d
    p["extra"] = e
    return e


def bump(p: dict, mission: str, n: int = 1) -> None:
    e = get_extra(p)
    e["daily"]["prog"][mission] = e["daily"]["prog"].get(mission, 0) + n


def all_players() -> list[dict]:
    return [r for r in repo.list_all() if not r["username"].startswith("__")]


def full_body(p: dict) -> dict:
    return {k: int((p.get("body") or {}).get(k, 0)) for k in R.BODY_IDS}


def view(p: dict) -> dict:
    lv = p["level"]
    body = full_body(p)
    e = get_extra(p)
    pv = e["pvp"]
    d = e["daily"]
    claimable = sum(1 for m in R.DAILY_MISSIONS if d["prog"].get(m["id"], 0) >= m["need"] and m["id"] not in d["claimed"])
    return {
        "pvp": {"rating": pv["rating"], "tier": R.pvp_tier(pv["rating"]), "wins": pv["wins"],
                "losses": pv["losses"], "coins": pv["coins"]},
        "awake": {k: int(e["awake"].get(k, 0)) for k in R.BODY_IDS}, "crystals": e["crystals"],
        "awake_unlocked": R.awake_unlocked(body), "daily_claimable": claimable, "checkin_ready": e["checkin"]["last"] != today_kst(),
        "username": p["username"], "level": lv, "exp": p["exp"], "exp_next": R.exp_to_next(lv),
        "gold": p["gold"], "stones": p["stones"], "body": body, "body_cap": R.body_cap(lv),
        "stats": R.compute_stats(lv, body, e["awake"], R.heroine_bonus(e, p.get("clears") or {})), "has_avatar": bool(p.get("avatar_data")),
        "boost_left": max(0, int(p.get("boost_until", 0) - time.time())),
        "clears": p.get("clears") or {}, "hunt": p.get("hunt"),
    }


def save(p: dict, *fields: str) -> None:
    repo.update(p["id"], {f: p[f] for f in fields})


# ── 계정 ─────────────────────────────────────────────────────
class Cred(BaseModel):
    username: str
    password: str


@app.post("/api/register")
def register(c: Cred, req: Request):
    ip = client_ip(req)
    now = time.time()
    hist = [t for t in _REG_LOG.get(ip, []) if now - t < REG_WINDOW]
    if len(hist) >= REG_LIMIT:
        raise ApiError("가입 시도가 너무 많아요. 잠시 후 다시 시도해 주세요.")
    hist.append(now)
    _REG_LOG[ip] = hist
    name = c.username.strip()
    if name.startswith("__") or not (2 <= len(name) <= 16) or not name.replace("_", "").isalnum():
        raise ApiError("아이디는 2~16자의 한글/영문/숫자/_ 만 가능합니다.")
    if len(c.password) < 6 or len(c.password) > 64:
        raise ApiError("비밀번호는 6자 이상 64자 이하여야 합니다.")
    with LOCK:
        if repo.get_by_username(name):
            raise ApiError("이미 사용 중인 아이디입니다.")
        p = repo.create({
            "username": name, "password_hash": hash_pw(c.password), "level": 1, "exp": 0,
            "gold": 100, "stones": 3, "body": {k: 0 for k in R.BODY_IDS}, "avatar_data": None,
            "hunt": None, "boost_until": 0, "clears": {}, "extra": {},
        })
    return {"ok": True, "token": make_token(p["id"]), "player": view(p)}


@app.post("/api/login")
def login(c: Cred):
    p = repo.get_by_username(c.username.strip())
    if not p or not check_pw(c.password, p["password_hash"]):
        raise ApiError("아이디 또는 비밀번호가 올바르지 않습니다.")
    return {"ok": True, "token": make_token(p["id"]), "player": view(p)}


@app.get("/api/meta")
def meta():
    return {
        "ok": True, "dev": DEV, "max_level": R.MAX_LEVEL, "skills": R.SKILLS, "guard": R.GUARD,
        "body_parts": R.BODY_PARTS, "zones": R.HUNT_ZONES, "time_limit": R.BATTLE_TIME_LIMIT,
        "combo": {"window": R.COMBO_WINDOW, "step": R.COMBO_STEP, "max": R.COMBO_MAX},
        "pvp": {"time_limit": R.PVP_TIME_LIMIT, "coin_per_stone": R.PVP_COIN_PER_STONE},
        "missions": R.DAILY_MISSIONS,
        "awake": {"max": R.AWAKE_MAX, "eq": R.AWAKE_EQ,
                  "costs": [dict(zip(("gold", "crystals"), R.awake_cost(a))) for a in range(R.AWAKE_MAX)]},
        "approaches": [{"id": k, **{x: v[x] for x in ("name", "desc")}} for k, v in R.APPROACHES.items()],
        "bosses": [{**R.boss_stats(b["id"]), "min_level": b["min_level"], "bg": b["bg"],
                    "sprite": b["sprite"], "rewards": R.boss_rewards(b["id"])} for b in R.BOSSES],
    }


@app.get("/api/me")
def me(p: dict = Depends(current_player)):
    return {"ok": True, "player": view(p)}


# ── 전신 일러스트(data URL 코드로 DB 컬럼에 저장, Storage 미사용) ──
class Avatar(BaseModel):
    data: str


@app.put("/api/avatar")
def put_avatar(a: Avatar, p: dict = Depends(current_player)):
    d = a.data
    if not d.startswith("data:image/") or ";base64," not in d:
        raise ApiError("이미지 데이터 형식이 올바르지 않습니다.")
    if len(d) > AVATAR_MAX_CHARS:
        raise ApiError("이미지가 너무 큽니다.")
    try:
        base64.b64decode(d.split(";base64,", 1)[1], validate=True)
    except Exception:
        raise ApiError("이미지 데이터가 손상되었습니다.")
    with LOCK:
        p["avatar_data"] = d
        save(p, "avatar_data")
    return {"ok": True}


@app.get("/api/avatar")
def get_avatar(p: dict = Depends(current_player)):
    return {"ok": True, "data": p.get("avatar_data")}


# ── 신체 강화 ────────────────────────────────────────────────
class Part(BaseModel):
    part: str


@app.post("/api/body/upgrade")
def body_upgrade(b: Part, p: dict = Depends(current_player)):
    if b.part not in R.BODY_IDS:
        raise ApiError("알 수 없는 신체 부위입니다.")
    with LOCK:
        p = repo.get_by_id(p["id"])
        body = full_body(p)
        cur = body[b.part]
        if cur >= R.body_cap(p["level"]):
            raise ApiError(f"현재 레벨에서는 {R.body_cap(p['level'])}단계까지만 강화할 수 있습니다.")
        gold, stones = R.body_cost(cur)
        if p["gold"] < gold or p["stones"] < stones:
            raise ApiError("골드 또는 강화석이 부족합니다.")
        p["gold"] -= gold
        p["stones"] -= stones
        cap = R.body_cap(p["level"])
        jackpot = cur + 2 <= cap and secrets.randbelow(1000) < int(R.ENHANCE_JACKPOT_CHANCE * 1000)
        body[b.part] = cur + (2 if jackpot else 1)
        p["body"] = body
        bump(p, "body")
        save(p, "gold", "stones", "body", "extra")
    return {"ok": True, "jackpot": jackpot, "player": view(p)}


# ── 필드 보스 ────────────────────────────────────────────────
BATTLES: dict[str, dict] = {}


class BossReq(BaseModel):
    boss_id: int
    approach: str = "direct"


class Finish(BaseModel):
    battle_id: str
    result: str  # "win" | "lose"


@app.post("/api/battle/start")
def battle_start(r: BossReq, p: dict = Depends(current_player)):
    b = R.BOSS_BY_ID.get(r.boss_id)
    if not b:
        raise ApiError("존재하지 않는 보스입니다.")
    if p["level"] < b["min_level"]:
        raise ApiError(f"Lv.{b['min_level']} 이상만 입장할 수 있습니다.")
    _e = get_extra(p)
    stats = R.compute_stats(p["level"], full_body(p), _e["awake"], R.heroine_bonus(_e, p.get("clears") or {}))
    ap = R.APPROACHES.get(r.approach)
    if not ap:
        raise ApiError("알 수 없는 접근 방식입니다.")
    mod = {"hp": ap["hp"], "atk": ap["atk"]}
    outcome = None
    if r.approach == "talk":
        outcome = "success" if secrets.randbelow(2) == 0 else "fail"
        mod = {"hp": ap["hp"], "atk": ap["atk"], **ap[outcome]}
    boss = R.boss_stats(r.boss_id)
    boss["hp"] = int(boss["hp"] * mod["hp"])
    boss["atk"] = round(boss["atk"] * mod["atk"], 1)
    bid = uuid.uuid4().hex
    now = time.time()
    for k in [k for k, v in BATTLES.items() if now - v["t0"] > 900]:
        del BATTLES[k]
    BATTLES[bid] = {"pid": p["id"], "boss": r.boss_id, "t0": now, "stats": stats, "level": p["level"],
                    "boss_stats": boss, "reward_mult": ap["reward"] * (1.0), "approach": r.approach}
    if r.approach == "taunt":
        BATTLES[bid]["reward_mult"] = ap["reward"]
    return {"ok": True, "battle_id": bid, "stats": stats, "boss": boss,
            "approach": {"id": r.approach, "name": ap["name"], "outcome": outcome}}


def roll_loot(rw: dict, boss_id: int) -> dict:
    total = sum(x["weight"] for x in R.LOOT_TABLE)
    r = secrets.randbelow(total)
    for row in R.LOOT_TABLE:
        if r < row["weight"]:
            break
        r -= row["weight"]
    mult = row["mult"]
    return {
        "rarity": row["rarity"], "mult": mult,
        "gold": int(rw["gold"] * 0.5 * mult),
        "stones": (1 + boss_id // 4) * (mult - 1) if mult > 1 else 0,
        "boost_seconds": 3600 if row["rarity"] == "전설" else 0,
    }


@app.post("/api/battle/finish")
def battle_finish(f: Finish, p: dict = Depends(current_player)):
    with LOCK:
        bt = BATTLES.pop(f.battle_id, None)
        if not bt or bt["pid"] != p["id"]:
            raise ApiError("유효하지 않은 전투입니다.")
        if f.result != "win":
            return {"ok": True, "won": False, "player": view(p)}
        elapsed = time.time() - bt["t0"]
        boss = bt["boss_stats"]
        # 서버가 잰 경과 시간 안에 이론상 낼 수 있는 최대 피해가 보스 체력에 못 미치면 위조로 간주
        if R.max_possible_damage(bt["stats"], bt["level"], elapsed + 1.5) < boss["hp"]:
            raise ApiError("전투 기록이 검증에 실패했습니다.")
        p = repo.get_by_id(p["id"])
        rw = R.boss_rewards(bt["boss"])
        rm = bt["reward_mult"]
        rw = {"exp": int(rw["exp"] * rm), "gold": int(rw["gold"] * rm), "stones": rw["stones"]}
        boost = time.time() < p.get("boost_until", 0)
        exp = int(rw["exp"] * (R.BOOST_MULT if boost else 1))
        ups = add_exp(p, exp)
        p["gold"] += rw["gold"]
        p["stones"] += rw["stones"]
        loot = roll_loot(rw, bt["boss"])
        crystals = R.crystal_drop_boss(bt["boss"]) + (2 if loot["rarity"] == "전설" else 0)
        get_extra(p)["crystals"] += crystals
        p["gold"] += loot["gold"]
        p["stones"] += loot["stones"]
        p["boost_until"] = max(time.time(), p.get("boost_until", 0)) + R.BOOST_SECONDS + loot["boost_seconds"]
        bump(p, "boss")
        drop = None
        if secrets.randbelow(1000) < int(R.TROPHY_DROP_CHANCE * 1000):
            drop = f"trophy_{bt['boss']}"
            _e = get_extra(p)
            _e.setdefault("inventory", {})
            _e["inventory"][drop] = _e["inventory"].get(drop, 0) + 1
        clears = dict(p.get("clears") or {})
        clears[str(bt["boss"])] = clears.get(str(bt["boss"]), 0) + 1
        p["clears"] = clears
        save(p, "level", "exp", "gold", "stones", "boost_until", "clears", "extra")
    return {"ok": True, "won": True, "level_ups": ups, "rewards": {**rw, "exp": exp, "crystals": crystals}, "loot": loot,
            "approach": bt["approach"], "drop": ({"id": drop, "name": R.ITEMS[drop]["name"]} if drop else None),
            "player": view(p)}


# ── 자동 사냥 센터 ───────────────────────────────────────────
class ZoneReq(BaseModel):
    zone_id: int


def hunt_preview(p: dict) -> dict | None:
    h = p.get("hunt")
    if not h:
        return None
    end = time.time()
    minutes = min(R.HUNT_MAX_MINUTES, max(0.0, (end - h["started"]) / 60))
    rt = R.hunt_rates(h["zone"])
    boost_min = min(minutes, max(0.0, (min(end, p.get("boost_until", 0)) - h["started"]) / 60))
    exp = rt["exp_per_min"] * (minutes + boost_min * (R.BOOST_MULT - 1))
    return {
        "zone": h["zone"], "minutes": round(minutes, 1), "exp": int(exp),
        "gold": int(rt["gold_per_min"] * minutes), "stones": int(minutes // 10) * rt["stone_per_10min"],
        "full": minutes >= R.HUNT_MAX_MINUTES,
    }


@app.get("/api/hunt")
def hunt_status(p: dict = Depends(current_player)):
    return {"ok": True, "hunt": hunt_preview(p), "max_minutes": R.HUNT_MAX_MINUTES,
            "boost_left": max(0, int(p.get("boost_until", 0) - time.time()))}


@app.post("/api/hunt/start")
def hunt_start(z: ZoneReq, p: dict = Depends(current_player)):
    zone = R.HUNT_ZONE_BY_ID.get(z.zone_id)
    if not zone:
        raise ApiError("존재하지 않는 사냥 지역입니다.")
    if p["level"] < zone["min_level"]:
        raise ApiError(f"Lv.{zone['min_level']} 이상만 입장할 수 있습니다.")
    with LOCK:
        p = repo.get_by_id(p["id"])
        if p.get("hunt"):
            raise ApiError("이미 자동 사냥 중입니다. 먼저 수령해 주세요.")
        p["hunt"] = {"zone": z.zone_id, "started": time.time()}
        save(p, "hunt")
    return {"ok": True, "hunt": hunt_preview(p)}


@app.post("/api/hunt/claim")
def hunt_claim(p: dict = Depends(current_player)):
    with LOCK:
        p = repo.get_by_id(p["id"])
        pv = hunt_preview(p)
        if not pv:
            raise ApiError("진행 중인 자동 사냥이 없습니다.")
        ups = add_exp(p, pv["exp"])
        p["gold"] += pv["gold"]
        p["stones"] += pv["stones"]
        p["hunt"] = None
        bump(p, "hunt")
        save(p, "level", "exp", "gold", "stones", "hunt", "extra")
    return {"ok": True, "got": pv, "level_ups": ups, "player": view(p)}


# ── PVP 아레나 (비동기: 상대의 스탯 스냅샷과 실시간 교전, 승패는 서버가 검증) ──
PVP_BATTLES: dict[str, dict] = {}


def make_bot(me: dict, tier: str, idx: int) -> dict:
    t = R.BOT_TIERS[tier]
    lv = max(1, min(R.MAX_LEVEL, me["level"] + t["dl"]))
    bl = max(0, int(R.body_cap(lv) * t["body"]))
    my_r = get_extra(me)["pvp"]["rating"]
    return {
        "id": f"bot:{tier}:{idx}", "name": R.BOT_NAMES[idx % len(R.BOT_NAMES)], "level": lv,
        "rating": max(0, my_r + t["dr"]), "bot": True, "tier": tier, "eff": t["eff"], "reward": t["reward"],
        "sprite": R.BOT_SPRITES[idx % len(R.BOT_SPRITES)], "body": {k: bl for k in R.BODY_IDS},
    }


def real_opp(row: dict) -> dict:
    ex = get_extra(row)
    return {
        "id": row["id"], "name": row["username"], "level": row["level"], "rating": ex["pvp"]["rating"],
        "bot": False, "tier": None, "eff": 0.8, "reward": 1.0, "sprite": 0, "body": full_body(row),
        "awake": ex["awake"],
    }


def opp_public(o: dict) -> dict:
    return {"id": o["id"], "name": o["name"], "level": o["level"], "rating": o["rating"],
            "rating_tier": R.pvp_tier(o["rating"]), "bot": o["bot"], "sprite": o["sprite"],
            "difficulty": {"easy": "쉬움", "normal": "보통", "hard": "어려움"}.get(o["tier"], "유저")}


def level_ok(my: int, other: int) -> bool:
    """실제 유저끼리는 레벨이 비슷해야 매칭된다(±30%, 최소 ±10)."""
    return abs(my - other) <= max(10, int(my * 0.3))


@app.get("/api/pvp/opponents")
def pvp_opponents(p: dict = Depends(current_player)):
    my_r = get_extra(p)["pvp"]["rating"]
    others = [r for r in all_players() if r["id"] != p["id"] and level_ok(p["level"], r["level"])]
    others.sort(key=lambda r: abs(get_extra(r)["pvp"]["rating"] - my_r))
    opps = [real_opp(r) for r in others[:3]]
    tiers = ["easy", "normal", "hard", "normal", "easy"]
    seed = sum(ord(c) for c in p["id"]) + int(time.time() // 600)   # 10분마다 봇 이름이 바뀜
    i = 0
    while len(opps) < 5:
        opps.append(make_bot(p, tiers[i % len(tiers)], (seed + i * 3) % 10))
        i += 1
    return {"ok": True, "opponents": [opp_public(o) for o in opps]}


@app.get("/api/pvp/avatar")
def pvp_avatar(target: str, p: dict = Depends(current_player)):
    if target.startswith("bot:"):
        return {"ok": True, "data": None}
    row = repo.get_by_id(target)
    return {"ok": True, "data": (row or {}).get("avatar_data")}


class PvpStart(BaseModel):
    target: str


class PvpFinish(BaseModel):
    battle_id: str
    result: str


@app.post("/api/pvp/start")
def pvp_start(r: PvpStart, p: dict = Depends(current_player)):
    if r.target.startswith("bot:"):
        try:
            _, tier, idx = r.target.split(":")
            opp = make_bot(p, tier, int(idx))
        except Exception:
            raise ApiError("잘못된 상대입니다.")
    else:
        row = repo.get_by_id(r.target)
        if not row or row["id"] == p["id"] or not level_ok(p["level"], row["level"]):
            raise ApiError("잘못된 상대입니다.")
        opp = real_opp(row)
    _e = get_extra(p)
    my_stats = R.pvp_stats(p["level"], full_body(p), _e["awake"], R.heroine_bonus(_e, p.get("clears") or {}))
    opp_stats = R.pvp_stats(opp["level"], opp["body"], opp.get("awake"))
    bid = uuid.uuid4().hex
    now = time.time()
    for k in [k for k, v in PVP_BATTLES.items() if now - v["t0"] > 900]:
        del PVP_BATTLES[k]
    PVP_BATTLES[bid] = {"pid": p["id"], "opp": opp, "my": my_stats, "opp_stats": opp_stats,
                        "t0": now, "level": p["level"]}
    return {"ok": True, "battle_id": bid, "stats": my_stats,
            "opp": {**opp_public(opp), "stats": opp_stats, "eff": opp["eff"]}}


@app.post("/api/pvp/finish")
def pvp_finish(f: PvpFinish, p: dict = Depends(current_player)):
    with LOCK:
        bt = PVP_BATTLES.pop(f.battle_id, None)
        if not bt or bt["pid"] != p["id"]:
            raise ApiError("유효하지 않은 대전입니다.")
        won = f.result == "win"
        opp = bt["opp"]
        if won:
            elapsed = time.time() - bt["t0"]
            mit = R.pvp_mitigation(opp["level"], bt["opp_stats"]["def"])
            best = R.max_possible_damage(bt["my"], bt["level"], elapsed + 1.5) * mit
            if elapsed < 3 or best < bt["opp_stats"]["hp"] * 0.98:
                raise ApiError("전투 기록이 검증에 실패했습니다.")
        p = repo.get_by_id(p["id"])
        e = get_extra(p)
        pv = e["pvp"]
        old_rating = pv["rating"]
        delta = R.elo_delta(old_rating, opp["rating"], won)
        pv["rating"] = max(0, old_rating + delta)
        pv["wins" if won else "losses"] += 1
        coin_bonus = 2 if (won and opp["rating"] - old_rating >= 100) else 0
        rw = R.pvp_rewards(opp["level"], won, opp["reward"], coin_bonus)
        p["gold"] += rw["gold"]
        pv["coins"] += rw["coins"]
        if won and p["level"] >= 100:
            e["crystals"] += 1
            rw["crystals"] = 1
        bump(p, "pvp")
        save(p, "gold", "extra")
        if not opp["bot"]:  # 방어 기록 남기기(방어자의 레이팅은 변하지 않는다)
            drow = repo.get_by_id(opp["id"])
            if drow:
                dex = get_extra(drow)
                dex["pvp"]["log"] = ([{"t": int(time.time()), "who": p["username"], "won": not won}] + dex["pvp"]["log"])[:10]
                repo.update(drow["id"], {"extra": dex})
    return {"ok": True, "won": won, "delta": delta, "rating": pv["rating"], "tier": R.pvp_tier(pv["rating"]),
            "rewards": rw, "player": view(p)}


@app.get("/api/pvp/log")
def pvp_log(p: dict = Depends(current_player)):
    return {"ok": True, "log": get_extra(p)["pvp"]["log"]}


class ExchangeReq(BaseModel):
    stones: int


@app.post("/api/pvp/exchange")
def pvp_exchange(r: ExchangeReq, p: dict = Depends(current_player)):
    if r.stones < 1 or r.stones > 1000:
        raise ApiError("교환 수량이 올바르지 않습니다.")
    with LOCK:
        p = repo.get_by_id(p["id"])
        e = get_extra(p)
        cost = r.stones * R.PVP_COIN_PER_STONE
        if e["pvp"]["coins"] < cost:
            raise ApiError("PVP 코인이 부족합니다.")
        e["pvp"]["coins"] -= cost
        p["stones"] += r.stones
        save(p, "stones", "extra")
    return {"ok": True, "player": view(p)}


# ── 일일 미션 / 출석 / 랭킹 ─────────────────────────────────
def daily_view(p: dict) -> dict:
    d = get_extra(p)["daily"]
    ms = []
    for m in R.DAILY_MISSIONS:
        g, st = R.daily_reward(m, p["level"])
        prog = d["prog"].get(m["id"], 0)
        ms.append({"id": m["id"], "name": m["name"], "need": m["need"], "prog": min(prog, m["need"]),
                   "done": prog >= m["need"], "claimed": m["id"] in d["claimed"], "gold": g, "stones": st})
    return {"missions": ms, "all_claimed": all(m["claimed"] for m in ms), "bonus_claimed": d["bonus"],
            "bonus": R.DAILY_ALL_BONUS}


@app.get("/api/daily")
def daily_get(p: dict = Depends(current_player)):
    ck = get_extra(p)["checkin"]
    if ck["last"] == today_kst():
        streak, nxt = ck["streak"], ck["streak"]
    elif ck["last"] == yesterday_kst():
        streak, nxt = ck["streak"], ck["streak"] + 1
    else:
        streak, nxt = 0, 1
    return {"ok": True, **daily_view(p), "checkin": {
        "ready": ck["last"] != today_kst(), "streak": streak, "preview": R.checkin_reward(max(1, nxt), p["level"])}}


class ClaimReq(BaseModel):
    id: str


@app.post("/api/daily/claim")
def daily_claim(c: ClaimReq, p: dict = Depends(current_player)):
    with LOCK:
        p = repo.get_by_id(p["id"])
        d = get_extra(p)["daily"]
        if c.id == "bonus":
            if d["bonus"] or not all(m["id"] in d["claimed"] for m in R.DAILY_MISSIONS):
                raise ApiError("모든 미션 보상을 받은 뒤에 받을 수 있습니다.")
            d["bonus"] = True
            p["stones"] += R.DAILY_ALL_BONUS["stones"]
            p["boost_until"] = max(time.time(), p.get("boost_until", 0)) + R.DAILY_ALL_BONUS["boost_seconds"]
            get_extra(p)["crystals"] += 1
            got = {"gold": 0, "stones": R.DAILY_ALL_BONUS["stones"], "crystals": 1}
            save(p, "stones", "boost_until", "extra")
        else:
            m = next((m for m in R.DAILY_MISSIONS if m["id"] == c.id), None)
            if not m:
                raise ApiError("존재하지 않는 미션입니다.")
            if d["prog"].get(m["id"], 0) < m["need"]:
                raise ApiError("아직 완료하지 못한 미션입니다.")
            if m["id"] in d["claimed"]:
                raise ApiError("이미 받은 보상입니다.")
            g, st = R.daily_reward(m, p["level"])
            d["claimed"].append(m["id"])
            p["gold"] += g
            p["stones"] += st
            got = {"gold": g, "stones": st}
            save(p, "gold", "stones", "extra")
    return {"ok": True, "got": got, "player": view(p), **daily_view(p)}


@app.post("/api/checkin")
def checkin(p: dict = Depends(current_player)):
    with LOCK:
        p = repo.get_by_id(p["id"])
        ck = get_extra(p)["checkin"]
        if ck["last"] == today_kst():
            raise ApiError("오늘은 이미 출석했습니다.")
        ck["streak"] = ck["streak"] + 1 if ck["last"] == yesterday_kst() else 1
        ck["last"] = today_kst()
        rw = R.checkin_reward(ck["streak"], p["level"])
        p["gold"] += rw["gold"]
        p["stones"] += rw["stones"]
        if rw["boost_seconds"]:
            p["boost_until"] = max(time.time(), p.get("boost_until", 0)) + rw["boost_seconds"]
        save(p, "gold", "stones", "boost_until", "extra")
    return {"ok": True, "reward": rw, "streak": ck["streak"], "player": view(p)}


@app.get("/api/ranking")
def ranking(p: dict = Depends(current_player)):
    rows = all_players()
    by_level = sorted(rows, key=lambda r: (-r["level"], -r.get("exp", 0), r["username"]))
    by_pvp = sorted(rows, key=lambda r: (-get_extra(r)["pvp"]["rating"], r["username"]))
    lvl = [{"name": r["username"], "level": r["level"]} for r in by_level[:10]]
    pvp = [{"name": r["username"], "rating": get_extra(r)["pvp"]["rating"],
            "tier": R.pvp_tier(get_extra(r)["pvp"]["rating"])} for r in by_pvp[:10]]
    my_lvl = next((i + 1 for i, r in enumerate(by_level) if r["id"] == p["id"]), None)
    my_pvp = next((i + 1 for i, r in enumerate(by_pvp) if r["id"] == p["id"]), None)
    return {"ok": True, "level": lvl, "pvp": pvp, "my_level_rank": my_lvl, "my_pvp_rank": my_pvp, "total": len(rows)}


# ── 각성 ─────────────────────────────────────────────────────
@app.post("/api/awake/upgrade")
def awake_upgrade(b: Part, p: dict = Depends(current_player)):
    if b.part not in R.BODY_IDS:
        raise ApiError("알 수 없는 신체 부위입니다.")
    with LOCK:
        p = repo.get_by_id(p["id"])
        if not R.awake_unlocked(full_body(p)):
            raise ApiError(f"신체 6부위를 모두 {R.BODY_MAX}단계로 만들면 각성이 열립니다.")
        e = get_extra(p)
        cur = int(e["awake"].get(b.part, 0))
        if cur >= R.AWAKE_MAX:
            raise ApiError("이미 최대 각성입니다.")
        gold, crystals = R.awake_cost(cur)
        if p["gold"] < gold or e["crystals"] < crystals:
            raise ApiError("골드 또는 각성 결정이 부족합니다.")
        p["gold"] -= gold
        e["crystals"] -= crystals
        e["awake"][b.part] = cur + 1
        save(p, "gold", "extra")
    return {"ok": True, "player": view(p)}


# ── 개발용 (DEV_MODE=1 일 때만) ──────────────────────────────
class LevelReq(BaseModel):
    level: int


@app.post("/api/dev/setlevel")
def dev_setlevel(r: LevelReq, p: dict = Depends(current_player)):
    if not DEV:
        raise ApiError("개발 모드가 아닙니다.")
    with LOCK:
        p["level"] = max(1, min(R.MAX_LEVEL, r.level))
        p["exp"] = 0
        p["gold"] += 10_000_000
        p["stones"] += 10_000
        get_extra(p)["crystals"] += 100
        save(p, "level", "exp", "gold", "stones", "extra")
    return {"ok": True, "player": view(p)}


# ── 확장 API (인벤토리/히로인/경매장) ──────────────────────────
import ext  # noqa: E402  (main 의 정의가 끝난 뒤에 가져와야 순환 참조가 안 생긴다)

app.include_router(ext.router)
