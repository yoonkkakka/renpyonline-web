-- Supabase SQL Editor 에서 실행하세요.
-- 캐릭터 전신 일러스트는 Storage 가 아니라 avatar_data(text)에 data URL 코드로 저장합니다.
create table if not exists public.players (
    id            uuid primary key default gen_random_uuid(),
    username      text unique not null,
    password_hash text not null,
    level         int  not null default 1 check (level between 1 and 200),
    exp           bigint not null default 0,
    gold          bigint not null default 0,
    stones        bigint not null default 0,
    body          jsonb  not null default '{}'::jsonb,   -- {"muscle":0,"heart":0,...}
    avatar_data   text,                                  -- "data:image/png;base64,...."
    hunt          jsonb,                                 -- {"zone":1,"started":epoch}
    boost_until   double precision not null default 0,
    clears        jsonb  not null default '{}'::jsonb,   -- {"1":3,"2":1}
    created_at    timestamptz not null default now()
);

-- 서버(FastAPI)만 service_role 키로 접근합니다. 클라이언트 직접 접근은 막습니다.
alter table public.players enable row level security;

-- PVP / 일일 미션 / 출석 상태 (기존 DB 는 migrations/001_extra.sql 실행)
alter table public.players add column if not exists extra jsonb not null default '{}'::jsonb;
