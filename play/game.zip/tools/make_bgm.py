"""BGM 3곡을 직접 합성한다(마을 / 이야기 / 전투). 결과: game/audio/*.wav (루프 재생용, 32kHz 모노).

악기: 삼각파/사인파/펄스파 + ADSR, 간단한 드럼(킥/스네어/하이햇). 곡 끝의 여운은 처음으로 접어 넣어 끊김 없이 반복된다.
"""
import math
from pathlib import Path

import numpy as np
from scipy.io import wavfile
from scipy.signal import lfilter

SR = 32000
OUT = Path(__file__).resolve().parent.parent / "game" / "audio"
OUT.mkdir(parents=True, exist_ok=True)

NOTE = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


def hz(name):
    """'C#5', 'Bb3' 같은 이름 -> 주파수."""
    n = NOTE[name[0]]
    i = 1
    if name[i] == "#":
        n += 1
        i += 1
    elif name[i] == "b":
        n -= 1
        i += 1
    octave = int(name[i:])
    midi = 12 * (octave + 1) + n
    return 440.0 * 2 ** ((midi - 69) / 12)


def env(n, a=0.005, d=0.1, s=0.6, r=0.1):
    e = np.ones(n)
    na, nd, nr = int(a * SR), int(d * SR), int(r * SR)
    na, nd, nr = min(na, n), min(nd, max(0, n - na)), min(nr, n)
    if na:
        e[:na] = np.linspace(0, 1, na)
    if nd:
        e[na:na + nd] = np.linspace(1, s, nd)
    e[na + nd:] = s
    if nr:
        e[-nr:] *= np.linspace(1, 0, nr)
    return e


def wave(kind, f, n):
    t = np.arange(n) / SR
    ph = (t * f) % 1.0
    if kind == "sine":
        return np.sin(2 * np.pi * ph)
    if kind == "tri":
        return 4 * np.abs(ph - 0.5) - 1
    if kind == "pulse":
        return np.where(ph < 0.28, 1.0, -1.0)
    if kind == "bell":   # 오르골/마림바 느낌: 기본음 + 배음, 빠르게 감쇠
        return np.sin(2 * np.pi * ph) + 0.22 * np.sin(4 * np.pi * ph) + 0.06 * np.sin(6 * np.pi * ph)
    raise ValueError(kind)


class Track:
    def __init__(self, bpm, bars, beats_per_bar=4):
        self.spb = 60.0 / bpm                      # 1박 길이(초)
        self.total = bars * beats_per_bar * self.spb
        self.tail = 3.0                            # 루프 이음새용 여운
        self.buf = np.zeros(int((self.total + self.tail) * SR))
        self.bpm = bpm

    def add(self, start_beat, dur_beat, freq, vol, kind="tri", a=0.005, d=0.1, s=0.6, r=0.12):
        st = int(start_beat * self.spb * SR)
        n = int(dur_beat * self.spb * SR)
        if st >= len(self.buf):
            return
        n = min(n + int(r * SR), len(self.buf) - st)
        if n <= 0:
            return
        self.buf[st:st + n] += vol * wave(kind, freq, n) * env(n, a, d, s, r)

    def noise(self, start_beat, dur, vol, hp=0.0):
        st = int(start_beat * self.spb * SR)
        n = int(dur * SR)
        n = min(n, len(self.buf) - st)
        if n <= 0:
            return
        x = np.random.default_rng(int(start_beat * 1000) % 99991).uniform(-1, 1, n)
        if hp:
            x = x - np.convolve(x, np.ones(int(hp)) / int(hp), mode="same")   # 간단 하이패스
        self.buf[st:st + n] += vol * x * np.exp(-np.linspace(0, 7, n))

    def kick(self, start_beat, vol=0.5):
        st = int(start_beat * self.spb * SR)
        n = min(int(0.22 * SR), len(self.buf) - st)
        if n <= 0:
            return
        t = np.arange(n) / SR
        f = 45 + 95 * np.exp(-t * 28)
        self.buf[st:st + n] += vol * np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 14)

    def snare(self, start_beat, vol=0.32):
        self.noise(start_beat, 0.14, vol * 0.7, hp=6)
        self.add(start_beat, 0.15 / self.spb, 190, vol * 0.5, "sine", a=0.001, d=0.05, s=0.0, r=0.02)

    def hat(self, start_beat, vol=0.10):
        self.noise(start_beat, 0.04, vol * 0.5, hp=3)

    def render(self, name, gain=0.85, lowpass=4200):
        n = int(self.total * SR)
        loop = self.buf[:n].copy()
        tail = self.buf[n:]
        loop[:len(tail)] += tail                    # 여운을 처음에 접어 넣기 -> 끊김 없는 루프
        a = 1 - math.exp(-2 * math.pi * lowpass / SR)   # 1차 로우패스: 날카로운 고음/노이즈를 부드럽게
        loop = lfilter([a], [1, -(1 - a)], loop)
        loop = np.tanh(loop * 1.2)                  # 부드러운 리미터
        fade = np.linspace(0, 1, 160)               # 5ms 페이드: 이음새의 잡음(클릭) 방지
        loop[:160] *= fade
        loop[-160:] *= fade[::-1]
        loop *= gain / max(1e-9, np.abs(loop).max())
        wavfile.write(OUT / f"{name}.wav", SR, (loop * 32767).astype(np.int16))
        print(f"{name}: {self.total:.1f}s, peak {np.abs(loop).max():.2f}, rms {np.sqrt((loop ** 2).mean()):.3f}")


def chord(root, kind):
    base = {"maj": (0, 4, 7), "min": (0, 3, 7), "maj7": (0, 4, 7, 11), "min7": (0, 3, 7, 10)}[kind]
    m = 12 * (int(root[-1]) + 1) + NOTE[root[0]] + (1 if "#" in root else -1 if "b" in root[1:2] else 0)
    return [440.0 * 2 ** ((m + i - 69) / 12) for i in base]


# ═════════════ 1) 마을: 밝고 통통한 C장조 ═════════════
def town():
    T = Track(bpm=112, bars=16)
    prog = [("C", "maj"), ("A", "min"), ("F", "maj"), ("G", "maj")]
    roots = {"C": "C3", "A": "A2", "F": "F2", "G": "G2"}
    for bar in range(16):
        r, k = prog[bar % 4]
        b0 = bar * 4
        ch = chord(r + "4", k)
        for f in ch:                                             # 패드
            T.add(b0, 4, f / 2, 0.05, "sine", a=0.12, d=0.3, s=0.7, r=0.4)
        bf = hz(roots[r])
        for beat, mult in ((0, 1), (1.5, 1), (2, 1.5), (3, 1)):    # 통통 튀는 베이스
            T.add(b0 + beat, 0.9, bf * (2 if beat == 3 else 1) * (1 if mult == 1 else 1), 0.16, "tri", a=0.004, d=0.12, s=0.5, r=0.08)
        pat = [0, 1, 2, 1, 2, 1, 0, 1]                           # 8분음표 아르페지오
        for i, idx in enumerate(pat):
            T.add(b0 + i * 0.5, 0.5, ch[idx % len(ch)] * 2, 0.05, "tri", a=0.003, d=0.06, s=0.3, r=0.05)
        T.kick(b0, 0.28)
        T.kick(b0 + 2, 0.24)
        T.snare(b0 + 1, 0.12)
        T.snare(b0 + 3, 0.12)
        for i in range(8):
            T.hat(b0 + i * 0.5, 0.05 if i % 2 else 0.07)

    A = [("E5", 0, 2), ("G5", 2, 2), ("C6", 4, 3), ("G5", 7, 1),
         ("E5", 8, 2), ("A5", 10, 2), ("C6", 12, 2), ("B5", 14, 1), ("A5", 15, 1),
         ("A5", 16, 2), ("C6", 18, 2), ("F5", 20, 2), ("A5", 22, 2),
         ("G5", 24, 2), ("B5", 26, 2), ("D6", 28, 3), ("B5", 31, 1)]
    B = [("C6", 0, 3), ("B5", 3, 1), ("G5", 4, 2), ("E5", 6, 2),
         ("A5", 8, 3), ("G5", 11, 1), ("E5", 12, 2), ("C5", 14, 2),
         ("F5", 16, 2), ("A5", 18, 2), ("C6", 20, 2), ("A5", 22, 2),
         ("D6", 24, 2), ("B5", 26, 2), ("G5", 28, 4)]
    for phrase_i, phrase in enumerate([A, A, B, A]):
        for name, pos, ln in phrase:
            beat = phrase_i * 16 + pos * 0.5
            T.add(beat, ln * 0.5, hz(name), 0.11, "bell", a=0.004, d=0.35, s=0.15, r=0.25)
    T.render("bgm_town", lowpass=4200)


# ═════════════ 2) 이야기: 잔잔한 오르골 (F장조) ═════════════
def story():
    T = Track(bpm=84, bars=16)
    prog = [("F", "maj7"), ("D", "min7"), ("Bb", "maj7"), ("C", "maj")]
    for bar in range(16):
        r, k = prog[bar % 4]
        b0 = bar * 4
        ch = chord(r + "3", k)
        for f in ch:
            T.add(b0, 4, f, 0.045, "sine", a=0.35, d=0.6, s=0.7, r=0.8)
        T.add(b0, 3.6, ch[0] / 2, 0.10, "sine", a=0.01, d=0.4, s=0.6, r=0.3)
        pat = [0, 2, 1, 3, 2, 1, 2, 0]
        for i, idx in enumerate(pat):
            T.add(b0 + i * 0.5, 0.5, ch[idx % len(ch)] * 4, 0.07, "bell", a=0.003, d=0.4, s=0.1, r=0.3)
    mel = [("A5", 0, 3), ("G5", 3, 1), ("F5", 4, 4), ("D5", 8, 3), ("F5", 11, 1), ("A5", 12, 4),
           ("Bb5", 16, 3), ("A5", 19, 1), ("G5", 20, 4), ("E5", 24, 4), ("G5", 28, 4)]
    for rep in range(2):
        for name, pos, ln in mel:
            T.add(rep * 32 + pos, ln, hz(name), 0.10, "bell", a=0.01, d=0.5, s=0.2, r=0.4)
    T.render("bgm_story", gain=0.75, lowpass=3200)


# ═════════════ 3) 전투: 빠르고 신나는 A단조 ═════════════
def battle():
    T = Track(bpm=156, bars=16)
    prog = [("A", "min"), ("F", "maj"), ("C", "maj"), ("G", "maj")]
    roots = {"A": "A2", "F": "F2", "C": "C3", "G": "G2"}
    for bar in range(16):
        r, k = prog[bar % 4]
        b0 = bar * 4
        ch = chord(r + "4", k)
        bf = hz(roots[r])
        for i in range(8):                                        # 달리는 8분음표 베이스
            T.add(b0 + i * 0.5, 0.45, bf * (2 if i % 4 == 3 else 1), 0.15, "pulse", a=0.003, d=0.08, s=0.4, r=0.04)
        for i in range(16):                                       # 16분음표 아르페지오
            T.add(b0 + i * 0.25, 0.25, ch[[0, 1, 2, 1][i % 4]] * 2, 0.04, "tri", a=0.002, d=0.04, s=0.2, r=0.03)
        for beat in range(4):
            T.kick(b0 + beat, 0.42)
        T.snare(b0 + 1, 0.30)
        T.snare(b0 + 3, 0.30)
        for i in range(8):
            T.hat(b0 + i * 0.5, 0.09)
        if bar % 4 == 3:
            for j in range(4):                                    # 4마디마다 스네어 필인
                T.snare(b0 + 3 + j * 0.25, 0.20)
    lead_a = [("A5", 0, 3), ("E5", 3, 1), ("C5", 4, 2), ("E5", 6, 2),
              ("F5", 8, 3), ("C5", 11, 1), ("A4", 12, 2), ("C5", 14, 2),
              ("E5", 16, 2), ("G5", 18, 2), ("C6", 20, 4),
              ("B5", 24, 2), ("D6", 26, 2), ("B5", 28, 2), ("G5", 30, 2)]
    lead_b = [("E6", 0, 2), ("C6", 2, 2), ("A5", 4, 4),
              ("F6", 8, 2), ("C6", 10, 2), ("A5", 12, 4),
              ("G6", 16, 2), ("E6", 18, 2), ("C6", 20, 4),
              ("D6", 24, 2), ("B5", 26, 2), ("G5", 28, 2), ("D6", 30, 2)]
    for phrase_i, phrase in enumerate([lead_a, lead_a, lead_b, lead_a]):
        for name, pos, ln in phrase:
            T.add(phrase_i * 16 + pos * 0.5, ln * 0.5, hz(name), 0.085, "pulse", a=0.004, d=0.1, s=0.55, r=0.06)
    T.render("bgm_battle", gain=0.85, lowpass=4600)


if __name__ == "__main__":
    town()
    story()
    battle()
