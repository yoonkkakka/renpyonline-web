-- Supabase SQL Editor 에서 한 번 실행하세요. (PVP / 일일 미션 / 출석 저장용)
alter table public.players add column if not exists extra jsonb not null default '{}'::jsonb;
