﻿# TODO: Translation updated at 2026-09-28 18:01

translate schinese strings:

    # game/rpg/raid.rpy:152
    old "전투 불능..."
    new "战斗不能…"

