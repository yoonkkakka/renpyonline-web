﻿# TODO: Translation updated at 2026-09-28 16:13

translate schinese strings:

    # game/rpg/web_login.rpy:46
    old "아이디 저장"
    new "记住账号"

    # game/rpg/web_login.rpy:46
    old "회원가입 (공식 홈페이지)"
    new "注册（前往官方网站）"

    # game/rpg/web_login.rpy:46
    old "폰은 가로 화면으로 돌리면 더 잘 보여요"
    new "手机横屏观看效果更佳"

    # game/rpg/web_login.rpy:100
    old "로그인에 실패했어요."
    new "登录失败了。"

