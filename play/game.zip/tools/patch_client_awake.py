"""각성 UI / 스토리 대치 연동 클라이언트 패치 (일회성)."""
from pathlib import Path

root = Path(__file__).resolve().parent.parent / "game"


def patch(path, pairs):
    s = path.read_text(encoding="utf-8")
    for old, new in pairs:
        assert old in s, (path.name, old[:70])
        s = s.replace(old, new, 1)
    path.write_text(s, encoding="utf-8")


# ── battle.rpy: 접근 방식 전달 ──
patch(root / "rpg" / "battle.rpy", [
    ('''            self.id = res["battle_id"]
            self.st = res["stats"]
            self.boss = res["boss"]''', '''            self.id = res["battle_id"]
            self.st = res["stats"]
            self.boss = res["boss"]
            self.approach = res.get("approach") or {"id": "direct", "name": "정면 돌파", "outcome": None}'''),
    ('''    def start_battle(boss_id):
        global B
        res = safe(api, "POST", "/api/battle/start", {"boss_id": boss_id})''', '''    def start_battle(boss_id, approach="direct"):
        global B
        res = safe(api, "POST", "/api/battle/start", {"boss_id": boss_id, "approach": approach})'''),
])

# ── fun_api.rpy: 각성 ──
with (root / "rpg" / "fun_api.rpy").open("a", encoding="utf-8") as f:
    f.write('''
    def awake_cost(a):
        c = G.meta["awake"]["costs"][a]
        return c["gold"], c["crystals"]

    def upgrade_awake(part):
        if safe(api, "POST", "/api/awake/upgrade", {"part": part}):
            renpy.notify("각성 성공!")
''')

# 미션 보상 알림에 각성 결정 포함
patch(root / "rpg" / "fun_api.rpy", [
    ('''            renpy.notify("보상: 골드 %s, 강화석 %s" % (fmt(g["gold"]), fmt(g["stones"])))''',
     '''            extra = (", 각성 결정 %d" % g["crystals"]) if g.get("crystals") else ""
            renpy.notify("보상: 골드 %s, 강화석 %s%s" % (fmt(g["gold"]), fmt(g["stones"]), extra))'''),
])

# ── screens.rpy ──
p = root / "rpg" / "screens.rpy"
s = p.read_text(encoding="utf-8")

# 상단 바: 각성 결정
old = '''            text ("강화석 %s" % fmt(p["stones"])) style "rp_text" size 30 color "#b6a2ff"'''
assert old in s
s = s.replace(old, old + '''
            if p["awake_unlocked"] or p["crystals"]:
                text ("각성 결정 %d" % p["crystals"]) style "rp_text" size 30 color "#ff9de2"''', 1)

# 캐릭터 화면: 신체 강화 / 각성 탭
a = s.index("    frame:\n        style \"rp_panel\"\n        xpos 660\n        ypos 110")
b = s.index("    frame:\n        style \"rp_panel\"\n        xpos 1390")
new_mid = '''    frame:
        style "rp_panel"
        xpos 660
        ypos 110
        xsize 700
        ysize 830
        vbox:
            spacing 10
            hbox:
                spacing 12
                textbutton "신체 강화" style "rp_button" xsize 200 text_size 30 selected (tab == "body") action SetScreenVariable("tab", "body")
                textbutton ("각성" if p["awake_unlocked"] else "각성 (잠김)") style "rp_button" xsize 200 text_size 30 selected (tab == "awake") action SetScreenVariable("tab", "awake")
            if tab == "body":
                text ("현재 레벨 한도: %d단계 (레벨 4당 1단계)" % p["body_cap"]) style "rp_text" size 22 color "#9aa6c0"
                for part in G.meta["body_parts"]:
                    $ lvl = p["body"][part["id"]]
                    $ g, s = body_cost(lvl)
                    $ can = lvl < p["body_cap"] and p["gold"] >= g and p["stones"] >= s
                    frame:
                        style "rp_panel"
                        background Solid("#16213dd0")
                        xfill True
                        padding (16, 8)
                        hbox:
                            spacing 12
                            vbox:
                                xsize 400
                                text ("%s  %d단계" % (part["name"], lvl)) style "rp_text" size 30 color "#ffe9a8"
                                text part["desc"] style "rp_text" size 20 color "#b8c4e0"
                            vbox:
                                xsize 220
                                yalign 0.5
                                if lvl >= p["body_cap"]:
                                    textbutton "한도 도달" style "rp_button" xfill True text_size 24 sensitive False action NullAction()
                                else:
                                    textbutton ("강화 %s G + %d석" % (fmt(g), s)) style "rp_button" xfill True text_size 21 sensitive can action Function(upgrade_part, part["id"])
                text "강화할 때마다 12% 확률로 대성공(2단계 상승)!" style "rp_text" size 20 color "#ffb347"
            else:
                if not p["awake_unlocked"]:
                    $ done = len([1 for k in p["body"] if p["body"][k] >= 50])
                    text "각성 잠김" style "rp_text" size 40 color "#ff9d9d"
                    text ("신체 6부위를 모두 50단계로 만들면 열립니다.\\n현재 %d / 6 부위 완료" % done) style "rp_text" size 28
                    text "각성하면 부위마다 +3단계 상당의 능력치를 추가로 얻고,\\n치명타/쿨타임/회피 상한도 늘어납니다." style "rp_text" size 22 color "#b8c4e0"
                else:
                    text ("각성 결정  %d" % p["crystals"]) style "rp_text" size 30 color "#ff9de2"
                    text "고레벨 보스(10번~), PVP 승리, 전설 상자, 일일 올클리어로 얻습니다." style "rp_text" size 20 color "#9aa6c0"
                    for part in G.meta["body_parts"]:
                        $ a = p["awake"][part["id"]]
                        frame:
                            style "rp_panel"
                            background Solid("#2a2350d0")
                            xfill True
                            padding (16, 8)
                            hbox:
                                spacing 12
                                vbox:
                                    xsize 400
                                    text ("%s  각성 %d / %d" % (part["name"], a, G.meta["awake"]["max"])) style "rp_text" size 30 color "#ffe9a8"
                                    text ("신체 +%d단계 상당" % (a * G.meta["awake"]["eq"])) style "rp_text" size 20 color "#b8c4e0"
                                vbox:
                                    xsize 220
                                    yalign 0.5
                                    if a >= G.meta["awake"]["max"]:
                                        textbutton "최대 각성" style "rp_button" xfill True text_size 24 sensitive False action NullAction()
                                    else:
                                        $ ag, ac = awake_cost(a)
                                        textbutton ("각성 %s G + 결정 %d" % (fmt(ag), ac)) style "rp_button" xfill True text_size 20 sensitive (p["gold"] >= ag and p["crystals"] >= ac) action Function(upgrade_awake, part["id"])

'''
s = s[:a] + new_mid + s[b:]
s = s.replace("screen character_screen():\n    $ p = G.player", "screen character_screen():\n    default tab = \"body\"\n    $ p = G.player", 1)

# 보스 결과: 결정 / 접근 방식
old = '''                text ("강화석 +%d" % rw["stones"]) style "rp_text" size 36 xalign 0.5 color "#b6a2ff"'''
assert old in s
s = s.replace(old, old + '''
                if rw.get("crystals"):
                    text ("각성 결정 +%d" % rw["crystals"]) style "rp_text" size 36 xalign 0.5 color "#ff9de2"''', 1)
p.write_text(s, encoding="utf-8")

# PVP 결과: 결정
patch(root / "rpg" / "screens_fun.rpy", [
    ('''                text ("PVP 코인 +%d" % rw["coins"]) style "rp_text" size 32 xalign 0.5 color "#7fe3ff"''',
     '''                text ("PVP 코인 +%d" % rw["coins"]) style "rp_text" size 32 xalign 0.5 color "#7fe3ff"
                if rw.get("crystals"):
                    text ("각성 결정 +%d" % rw["crystals"]) style "rp_text" size 32 xalign 0.5 color "#ff9de2"'''),
])

# ── script.rpy: 스토리 대치 흐름 ──
patch(root / "script.rpy", [
    ('''label boss_fight(boss_id):
    $ started = start_battle(boss_id)
    if not started:
        return
    call screen battle_screen
    $ outcome = _return
    $ fin = finish_battle(outcome)
    call screen battle_result(outcome, fin)
    return''', '''label boss_fight(boss_id):
    $ first_clear = story_first(boss_id)
    call boss_story(boss_id)
    $ started = start_battle(boss_id, story_approach)
    if not started:
        return
    if B.approach["id"] == "talk":
        $ story_reaction(boss_id, B.approach["outcome"])
    call screen battle_screen
    $ outcome = _return
    $ fin = finish_battle(outcome)
    call screen battle_result(outcome, fin)
    if outcome == "win" and fin and first_clear:
        call boss_epilogue(boss_id)
    return'''),
])
print("patched")
