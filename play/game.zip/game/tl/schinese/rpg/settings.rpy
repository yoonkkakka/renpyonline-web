﻿# TODO: Translation updated at 2026-09-28 16:13

translate schinese strings:

    # game/rpg/settings.rpy:29
    old "켜짐"
    new "开启"

    # game/rpg/settings.rpy:29
    old "꺼짐"
    new "关闭"

    # game/rpg/settings.rpy:58
    old "렌파이 온라인 v%s"
    new "렌파이 온라인 v%s"

    # game/rpg/settings.rpy:59
    old "닫기 (Esc)"
    new "关闭（Esc）"

    # game/rpg/settings.rpy:65
    old "소리"
    new "声音"

    # game/rpg/settings.rpy:66
    old "배경음"
    new "背景音乐"

    # game/rpg/settings.rpy:67
    old "효과음"
    new "音效"

    # game/rpg/settings.rpy:68
    old "전체 음소거"
    new "全部静音"

    # game/rpg/settings.rpy:69
    old "화면"
    new "画面"

    # game/rpg/settings.rpy:72
    old "창 모드"
    new "窗口模式"

    # game/rpg/settings.rpy:79
    old "스토리 대사"
    new "剧情对话"

    # game/rpg/settings.rpy:80
    old "대사 속도"
    new "文字速度"

    # game/rpg/settings.rpy:81
    old "조작법"
    new "操作方法"

    # game/rpg/settings.rpy:82
    old "1~8 스킬  /  Space 방어 자세"
    new "1~8 技能  /  空格键 防御姿态"

    # game/rpg/settings.rpy:83
    old "Esc 설정 (전투 중에는 도망)"
    new "Esc 打开设置（战斗中为逃跑）"

    # game/rpg/settings.rpy:84
    old "스킬을 2초 안에 이어 쓰면 콤보로 피해 최대 +20%!"
    new "2秒内连续使用技能可通过连击最多提升20%伤害！"

    # game/rpg/settings.rpy:88
    old "전투 효과"
    new "战斗效果"

    # game/rpg/settings.rpy:89
    old "화면 흔들림"
    new "画面震动"

    # game/rpg/settings.rpy:89
    old "맞을 때 캐릭터가 부르르 떨려요"
    new "受击时角色会震动抖动"

    # game/rpg/settings.rpy:90
    old "피해 숫자"
    new "伤害数字"

    # game/rpg/settings.rpy:90
    old "떠오르는 데미지/회복 숫자"
    new "浮现的伤害／恢复数字"

    # game/rpg/settings.rpy:91
    old "전투 기록"
    new "战斗记录"

    # game/rpg/settings.rpy:91
    old "오른쪽 아래 전투 로그"
    new "右下角的战斗日志"

    # game/rpg/settings.rpy:92
    old "유혈 표현"
    new "流血效果"

    # game/rpg/settings.rpy:92
    old "맞을 때 피가 튀는 연출"
    new "受击时溅血的效果"

    # game/rpg/settings.rpy:93
    old "거친 대사"
    new "粗口台词"

    # game/rpg/settings.rpy:93
    old "보스 외침과 대사에 거친 말투"
    new "首领呐喊与台词使用粗俗语气"

    # game/rpg/settings.rpy:94
    old "계정"
    new "账户"

    # game/rpg/settings.rpy:98
    old "아직 로그인하지 않았어요"
    new "尚未登录"

    # game/rpg/settings.rpy:109
    old "게임 종료"
    new "退出游戏"

