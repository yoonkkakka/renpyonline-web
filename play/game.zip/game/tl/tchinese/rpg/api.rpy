﻿# TODO: Translation updated at 2026-09-28 16:26

translate tchinese strings:

    # game/rpg/api.rpy:51
    old "서버에 연결할 수 없어요. 잠시 후 다시 시도해 주세요."
    new "無法連線伺服器。請稍後再試。"

    # game/rpg/api.rpy:53
    old "알 수 없는 오류"
    new "未知錯誤"

    # game/rpg/api.rpy:104
    old "아이디와 비밀번호를 입력하세요."
    new "請輸入賬號和密碼。"

    # game/rpg/api.rpy:156
    old "이미지"
    new "圖片"

    # game/rpg/api.rpy:156
    old "모든 파일"
    new "所有檔案"

    # game/rpg/api.rpy:157
    old "전신 일러스트 선택"
    new "選擇全身插畫"

    # game/rpg/api.rpy:187
    old "이미지를 충분히 줄일 수 없습니다. 더 작은 이미지를 사용하세요."
    new "無法將圖片縮小到足夠小。請使用更小的圖片。"

    # game/rpg/api.rpy:191
    old "이 기기에서는 일러스트 등록을 지원하지 않아요. PC에서 등록하면 여기서도 보여요!"
    new "這臺裝置不支援插畫上傳。請在PC上註冊後，這裡也會顯示！"

    # game/rpg/api.rpy:202
    old "이미지를 읽을 수 없습니다."
    new "無法讀取圖片。"

    # game/rpg/api.rpy:206
    old "전신 일러스트가 등록되었습니다."
    new "全身插畫已註冊。"

    # game/rpg/api.rpy:215
    old "대성공!! 2단계 상승!"
    new "大成功!! 提升2個階段!"

    # game/rpg/api.rpy:215
    old "강화 성공!"
    new "強化成功!"

    # game/rpg/api.rpy:232
    old "수령: 경험치 %s, 골드 %s, 강화석 %s"
    new "領取：經驗值 %s，金幣 %s，強化石 %s"

    # game/rpg/api.rpy:234
    old " (레벨 +%d!)"
    new "（等級 +%d！）"

