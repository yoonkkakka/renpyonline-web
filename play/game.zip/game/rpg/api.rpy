# 서버(FastAPI) 통신 + 전역 상태 + 일러스트 업로드(data URL 코드로 DB 저장)

define config.rollback_enabled = False
define config.has_autosave = False
define config.autosave_on_quit = False
define config.window_title = "렌파이 온라인"
define config.default_music_volume = 0.7
define config.default_sfx_volume = 0.8
default persistent.last_user = ""
default persistent.save_id = True
default persistent.opt_shake = True
default persistent.opt_floaters = True
default persistent.opt_log = True
default persistent.opt_blood = True
default persistent.opt_rude = True

init -10 python:
    import time
    import math
    import os
    import base64
    import random
    import tempfile

    # 로컬 개발: "http://127.0.0.1:8000" / 배포(Render): "https://<서비스이름>.onrender.com"
    SERVER_URL = "https://renpy-online-api.onrender.com"
    SIGNUP_URL = "https://renpyonline.koreaachive.workers.dev/"   # 회원가입은 공식 홈페이지에서

    class ApiFail(Exception):
        pass

    class _G(object):
        token = None
        player = None
        meta = None
        avatar = None    # im.Data (업로드한 전신 일러스트)
        hunt = None
        hunt_boost = 0

    G = _G()

    def api(method, path, body=None):
        headers = {}
        if G.token:
            headers["Authorization"] = "Bearer " + G.token
        headers["X-Lang"] = _preferences.language or "ko"
        try:
            # renpy.fetch 는 내부적으로 스레드를 쓰고, 라벨 안에서 호출하면 기다리는 동안에도 화면(로딩 하트)을 계속 그린다.
            res = renpy.fetch(SERVER_URL + path, method=method, json=body,
                              headers=headers, timeout=60, result="json")
        except Exception:
            raise ApiFail(_("서버에 연결할 수 없어요. 잠시 후 다시 시도해 주세요."))
        if not res.get("ok"):
            raise ApiFail(res.get("error", _("알 수 없는 오류")))
        if "player" in res:
            G.player = res["player"]
        return res

    def safe(fn, *args, **kw):
        """ApiFail 을 알림으로 바꿔 보여주고 None 반환."""
        try:
            return fn(*args, **kw)
        except ApiFail as e:
            renpy.notify(str(e))
            return None

    def fmt(n):
        return "{:,}".format(int(n))

    def boss_meta(boss_id):
        return [b for b in G.meta["bosses"] if b["id"] == boss_id][0]

    def skill_list():
        return G.meta["skills"]

    # ── 로그인 ────────────────────────────────────────────────
    def load_meta():
        G.meta = api("GET", "/api/meta")

    def after_login(res):
        G.token = res["token"]
        G.avatar = None
        if G.player["has_avatar"]:
            load_avatar()

    def run_bg(fn, *args):
        """라벨 안에서 호출하면 renpy.fetch 가 기다리는 동안 화면을 계속 그리므로 그냥 실행하면 된다."""
        return fn(*args)

    def _login_worker(user, pw, register):
        if G.meta is None:
            load_meta()
        path = "/api/register" if register else "/api/login"
        res = api("POST", path, {"username": user, "password": pw})
        after_login(res)
        return res

    G.last_err = ""

    def do_login(user, pw, register):
        """서버 메타 로드(콜드 스타트 포함) + 로그인/가입. 성공 시 True."""
        G.last_err = ""
        user = user.strip()
        if not user or not pw:
            G.last_err = _("아이디와 비밀번호를 입력하세요.")
            renpy.notify(G.last_err)
            return False
        try:
            run_bg(_login_worker, user, pw, register)
        except ApiFail as e:
            G.last_err = str(e)
            renpy.notify(G.last_err)
            return False
        persistent.last_user = user if persistent.save_id else ""
        return True

    def logout():
        G.token = None
        G.player = None
        G.avatar = None
        return True

    # ── 전신 일러스트 ────────────────────────────────────────
    def load_avatar():
        res = api("GET", "/api/avatar")
        data = res.get("data")
        if data:
            raw = base64.b64decode(data.split(";base64,", 1)[1])
            G.avatar = im.Data(raw, "avatar.png")

    def avatar_disp(w, h):
        return Transform(G.avatar or "images/placeholder.png", fit="contain", xysize=(w, h))

    def pick_image_file():
        """윈도우 '열기' 대화상자. 취소하면 None."""
        if not renpy.windows:
            return None
        import ctypes
        from ctypes import wintypes

        class OFN(ctypes.Structure):
            _fields_ = [
                ("lStructSize", wintypes.DWORD), ("hwndOwner", ctypes.c_void_p),
                ("hInstance", ctypes.c_void_p), ("lpstrFilter", ctypes.c_void_p),
                ("lpstrCustomFilter", ctypes.c_void_p), ("nMaxCustFilter", wintypes.DWORD),
                ("nFilterIndex", wintypes.DWORD), ("lpstrFile", ctypes.c_void_p),
                ("nMaxFile", wintypes.DWORD), ("lpstrFileTitle", ctypes.c_void_p),
                ("nMaxFileTitle", wintypes.DWORD), ("lpstrInitialDir", ctypes.c_void_p),
                ("lpstrTitle", ctypes.c_void_p), ("Flags", wintypes.DWORD),
                ("nFileOffset", wintypes.WORD), ("nFileExtension", wintypes.WORD),
                ("lpstrDefExt", ctypes.c_void_p), ("lCustData", ctypes.c_void_p),
                ("lpfnHook", ctypes.c_void_p), ("lpTemplateName", ctypes.c_void_p),
                ("pvReserved", ctypes.c_void_p), ("dwReserved", wintypes.DWORD),
                ("FlagsEx", wintypes.DWORD),
            ]

        filt = ctypes.create_unicode_buffer(_("이미지") + "\0*.png;*.jpg;*.jpeg;*.webp;*.bmp\0" + _("모든 파일") + "\0*.*\0")
        title = ctypes.create_unicode_buffer(_("전신 일러스트 선택"))
        buf = ctypes.create_unicode_buffer(1024)
        ofn = OFN()
        ofn.lStructSize = ctypes.sizeof(OFN)
        ofn.lpstrFilter = ctypes.addressof(filt)
        ofn.lpstrFile = ctypes.addressof(buf)
        ofn.nMaxFile = 1024
        ofn.lpstrTitle = ctypes.addressof(title)
        ofn.Flags = 0x00081000 | 0x8   # FILEMUSTEXIST | EXPLORER | NOCHANGEDIR
        if ctypes.windll.comdlg32.GetOpenFileNameW(ctypes.byref(ofn)):
            return buf.value
        return None

    def pick_save_file(default_name, title):
        """윈도우 '다른 이름으로 저장' 대화상자. 취소하면 None."""
        if not renpy.windows:
            return None
        import ctypes
        from ctypes import wintypes

        class OFN(ctypes.Structure):
            _fields_ = [
                ("lStructSize", wintypes.DWORD), ("hwndOwner", ctypes.c_void_p),
                ("hInstance", ctypes.c_void_p), ("lpstrFilter", ctypes.c_void_p),
                ("lpstrCustomFilter", ctypes.c_void_p), ("nMaxCustFilter", wintypes.DWORD),
                ("nFilterIndex", wintypes.DWORD), ("lpstrFile", ctypes.c_void_p),
                ("nMaxFile", wintypes.DWORD), ("lpstrFileTitle", ctypes.c_void_p),
                ("nMaxFileTitle", wintypes.DWORD), ("lpstrInitialDir", ctypes.c_void_p),
                ("lpstrTitle", ctypes.c_void_p), ("Flags", wintypes.DWORD),
                ("nFileOffset", wintypes.WORD), ("nFileExtension", wintypes.WORD),
                ("lpstrDefExt", ctypes.c_void_p), ("lCustData", ctypes.c_void_p),
                ("lpfnHook", ctypes.c_void_p), ("lpTemplateName", ctypes.c_void_p),
                ("pvReserved", ctypes.c_void_p), ("dwReserved", wintypes.DWORD),
                ("FlagsEx", wintypes.DWORD),
            ]

        filt = ctypes.create_unicode_buffer(_("PNG 이미지") + "\0*.png\0" + _("모든 파일") + "\0*.*\0")
        title_buf = ctypes.create_unicode_buffer(title)
        buf = ctypes.create_unicode_buffer(1024)
        buf.value = default_name
        ext = ctypes.create_unicode_buffer("png")
        ofn = OFN()
        ofn.lStructSize = ctypes.sizeof(OFN)
        ofn.lpstrFilter = ctypes.addressof(filt)
        ofn.lpstrFile = ctypes.addressof(buf)
        ofn.nMaxFile = 1024
        ofn.lpstrTitle = ctypes.addressof(title_buf)
        ofn.lpstrDefExt = ctypes.addressof(ext)
        ofn.Flags = 0x00080000 | 0x00000002 | 0x8   # EXPLORER | OVERWRITEPROMPT | NOCHANGEDIR
        if ctypes.windll.comdlg32.GetSaveFileNameW(ctypes.byref(ofn)):
            return buf.value
        return None

    def encode_illustration(path, max_chars=1300000):
        """이미지를 축소해 PNG(알파 유지) -> data URL 코드로 변환. 너무 크면 더 줄인다."""
        import pygame_sdl2
        src = pygame_sdl2.image.load(path)
        w, h = src.get_size()
        tmp = os.path.join(tempfile.gettempdir(), "seoul_avatar_tmp.png")
        scale = min(1.0, 1100.0 / h)
        for _i in range(8):
            tw, th = max(1, int(w * scale)), max(1, int(h * scale))
            surf = pygame_sdl2.transform.smoothscale(src, (tw, th)) if scale < 1.0 else src
            pygame_sdl2.image.save(surf, tmp)
            with open(tmp, "rb") as f:
                raw = f.read()
            code = "data:image/png;base64," + base64.b64encode(raw).decode("ascii")
            if len(code) <= max_chars:
                return code
            scale *= 0.8
        raise ApiFail(_("이미지를 충분히 줄일 수 없습니다. 더 작은 이미지를 사용하세요."))

    def _guess_bg_color(surf):
        """네 모서리 중 가장 흔한 색을 배경색으로 추정한다."""
        w, h = surf.get_size()
        cols = [tuple(surf.get_at(p))[:3] for p in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1))]
        return max(set(cols), key=cols.count)

    def encode_field_sprite(path, max_chars=1300000):
        """유저가 올린 필드 캐릭터 시트: 모서리 색을 배경으로 보고 투명 PNG로 만든 뒤 data URL로 인코딩."""
        import pygame_sdl2
        src = pygame_sdl2.image.load(path)
        try:
            bg = _guess_bg_color(src)
            src.set_colorkey(bg)
            src = src.convert_alpha()
        except Exception:
            pass
        w, h = src.get_size()
        tmp = os.path.join(tempfile.gettempdir(), "field_sprite_tmp.png")
        scale = min(1.0, 1400.0 / max(w, h))
        for _i in range(8):
            tw, th = max(1, int(w * scale)), max(1, int(h * scale))
            surf = pygame_sdl2.transform.smoothscale(src, (tw, th)) if scale < 1.0 else src
            pygame_sdl2.image.save(surf, tmp)
            with open(tmp, "rb") as f:
                raw = f.read()
            code = "data:image/png;base64," + base64.b64encode(raw).decode("ascii")
            if len(code) <= max_chars:
                return code
            scale *= 0.8
        raise ApiFail(_("이미지를 충분히 줄일 수 없습니다. 더 작은 이미지를 사용하세요."))

    def upload_avatar():
        if not renpy.windows:
            renpy.notify(_("이 기기에서는 일러스트 등록을 지원하지 않아요. PC에서 등록하면 여기서도 보여요!"))
            return None
        path = pick_image_file()
        if not path:
            return None
        try:
            code = encode_illustration(path)
        except ApiFail as e:
            renpy.notify(str(e))
            return None
        except Exception:
            renpy.notify(_("이미지를 읽을 수 없습니다."))
            return None
        if safe(api, "PUT", "/api/avatar", {"data": code}):
            load_avatar()
            renpy.notify(_("전신 일러스트가 등록되었습니다."))

    # ── 신체 강화 ────────────────────────────────────────────
    def body_cost(part_level):
        return int(50 * (part_level + 1) ** 1.6), 1 + part_level // 4

    def upgrade_part(part):
        res = safe(api, "POST", "/api/body/upgrade", {"part": part})
        if res:
            renpy.notify(_("대성공!! 2단계 상승!") if res.get("jackpot") else _("강화 성공!"))

    # ── 자동 사냥 ────────────────────────────────────────────
    def refresh_hunt():
        res = safe(api, "GET", "/api/hunt")
        if res:
            G.hunt = res["hunt"]
            G.hunt_boost = res["boost_left"]

    def hunt_start(zone_id):
        if safe(api, "POST", "/api/hunt/start", {"zone_id": zone_id}):
            refresh_hunt()

    def hunt_claim():
        res = safe(api, "POST", "/api/hunt/claim")
        if res:
            g = res["got"]
            msg = _("수령: 경험치 %s, 골드 %s, 강화석 %s") % (fmt(g["exp"]), fmt(g["gold"]), fmt(g["stones"]))
            if res["level_ups"]:
                msg += _(" (레벨 +%d!)") % res["level_ups"]
            renpy.notify(msg)
            refresh_hunt()

    def dev_level(lv):
        safe(api, "POST", "/api/dev/setlevel", {"level": lv})

    def fmt_time(sec):
        sec = max(0, int(sec))
        return "%02d:%02d" % (sec // 60, sec % 60)


init -8 python:
    def bgm(name, fadein=1.0):
        """배경음 재생. 같은 곡이면 이어서 재생한다."""
        renpy.music.play("audio/bgm_%s.wav" % name, channel="music", loop=True, fadein=fadein, if_changed=True)
