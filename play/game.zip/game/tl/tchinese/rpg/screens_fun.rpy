﻿# TODO: Translation updated at 2026-09-28 16:26

translate tchinese strings:

    # game/rpg/screens_fun.rpy:21
    old "레이팅  %d"
    new "評分  %d"

    # game/rpg/screens_fun.rpy:22
    old "%d승  %d패"
    new "%d勝  %d負"

    # game/rpg/screens_fun.rpy:27
    old "PVP 코인  %d"
    new "PVP幣  %d"

    # game/rpg/screens_fun.rpy:28
    old "코인 %d개  >  강화석 1개"
    new "%d枚幣  >  1個強化石"

    # game/rpg/screens_fun.rpy:35
    old "상대는 실시간으로 움직이는 AI예요.\n이기면 레이팅, 코인, 골드를 얻고\n져도 골드와 코인을 조금 받아요.\n\n스킬을 이어 쓰면 콤보로 피해가 늘고,\n기절하면 잠깐 조작할 수 없어요."
    new "對手是實時行動的AI。\n獲勝可獲得評分、代幣與金幣，\n落敗也能獲得少量金幣與代幣。\n\n連續使用技能可透過連擊提升傷害，\n眩暈時會暫時無法操作。"

    # game/rpg/screens_fun.rpy:36
    old "상대 새로고침"
    new "重新整理對手"

    # game/rpg/screens_fun.rpy:47
    old "도전 상대"
    new "挑戰物件"

    # game/rpg/screens_fun.rpy:66
    old "어려움"
    new "困難"

    # game/rpg/screens_fun.rpy:66
    old "쉬움"
    new "簡單"

    # game/rpg/screens_fun.rpy:67
    old "도전 >"
    new "挑戰 >"

    # game/rpg/screens_fun.rpy:78
    old "방어 기록"
    new "防守記錄"

    # game/rpg/screens_fun.rpy:80
    old "아직 도전받은 기록이 없어요."
    new "還沒有被挑戰的記錄。"

    # game/rpg/screens_fun.rpy:82
    old "%s 님의 도전  %s\n%s"
    new "%s 的挑戰  %s\n%s"

    # game/rpg/screens_fun.rpy:82
    old "방어 성공"
    new "防守成功"

    # game/rpg/screens_fun.rpy:82
    old "방어 실패"
    new "防守失敗"

    # game/rpg/screens_fun.rpy:172
    old "항복 (Esc)"
    new "投降（Esc）"

    # game/rpg/screens_fun.rpy:234
    old "결과를 서버에 반영하지 못했어요."
    new "無法將結果同步到伺服器。"

    # game/rpg/screens_fun.rpy:241
    old "레이팅  %+d   (%d  %s)"
    new "評分  %+d   (%d  %s)"

    # game/rpg/screens_fun.rpy:247
    old "PVP 코인 +%d"
    new "PVP幣 +%d"

    # game/rpg/screens_fun.rpy:271
    old "일일 미션"
    new "每日任務"

    # game/rpg/screens_fun.rpy:272
    old "매일 오전 0시(KST)에 초기화돼요."
    new "每天凌晨0點（KST）重置。"

    # game/rpg/screens_fun.rpy:285
    old "%d / %d   보상: 골드 %s, 강화석 %d"
    new "%d / %d   獎勵：金幣 %s，強化石 %d"

    # game/rpg/screens_fun.rpy:286
    old "수령 완료"
    new "已領取"

    # game/rpg/screens_fun.rpy:286
    old "보상 받기"
    new "領取獎勵"

    # game/rpg/screens_fun.rpy:303
    old "올 클리어 보너스"
    new "全部完成獎勵"

    # game/rpg/screens_fun.rpy:304
    old "강화석 +%d, 각성 결정 +1, 경험치 부스트 %d분"
    new "強化石 +%d，覺醒結晶 +1，經驗加成 %d分鐘"

    # game/rpg/screens_fun.rpy:305
    old "보너스 받기"
    new "領取獎勵"

    # game/rpg/screens_fun.rpy:322
    old "출석 체크"
    new "簽到"

    # game/rpg/screens_fun.rpy:324
    old "연속 출석  %d일"
    new "連續簽到  %d天"

    # game/rpg/screens_fun.rpy:337
    old "%d일"
    new "%d天"

    # game/rpg/screens_fun.rpy:338
    old "완료"
    new "完成"

    # game/rpg/screens_fun.rpy:338
    old "대박"
    new "超值"

    # game/rpg/screens_fun.rpy:341
    old "오늘의 보상 (%d일차)"
    new "今日獎勵（第%d天）"

    # game/rpg/screens_fun.rpy:342
    old "골드 %s\n강화석 %d%s"
    new "金幣 %s\n強化石 %d%s"

    # game/rpg/screens_fun.rpy:342
    old "\n경험치 부스트 1시간"
    new "\n經驗加成1小時"

    # game/rpg/screens_fun.rpy:343
    old "출석하기"
    new "簽到"

    # game/rpg/screens_fun.rpy:345
    old "오늘은 이미 출석했어요.\n내일 또 만나요!"
    new "今天已經簽到過了。\n明天再見！"

    # game/rpg/screens_fun.rpy:346
    old "7일째는 강화석과 경험치 부스트가 듬뿍!\n하루를 거르면 처음부터 다시 시작해요."
    new "第7天可獲得大量強化石與經驗加成！\n中斷一天將從頭開始。"

    # game/rpg/screens_fun.rpy:364
    old "레벨 랭킹"
    new "等級排行"

    # game/rpg/screens_fun.rpy:366
    old "%2d위   %s   Lv.%d"
    new "第%2d名   %s   Lv.%d"

    # game/rpg/screens_fun.rpy:368
    old "내 순위: %s위 / %d명"
    new "我的排名：第%s名 / 共%d人"

    # game/rpg/screens_fun.rpy:378
    old "PVP 랭킹"
    new "PVP排行"

    # game/rpg/screens_fun.rpy:380
    old "%2d위   %s   %s  %d"
    new "第%2d名   %s   %s  %d"

