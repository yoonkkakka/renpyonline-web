# 히로인 / 가방/상점 / 경매장 화면 (귀여운 모바일 스타일)

# ── 히로인 ───────────────────────────────────────────────────
screen heroine_screen():
    default sel = 0
    $ hs = G.heroines
    $ h = hs[sel]
    add "images/bg/t09.webp"
    add Solid("#3a1d5ab8")
    use topbar
    frame:
        style "rp_panel"
        xpos 40
        ypos 128
        xsize 520
        ysize 790
        padding (24, 16)
        vbox:
            spacing 12
            text "히로인" style "rp_text" size 44 color "#fff1a8"
            for i, hh in enumerate(hs):
                button:
                    style "rp_card_btn"
                    xfill True
                    ysize 160
                    padding (16, 8)
                    selected (i == sel)
                    action SetScreenVariable("sel", i)
                    hbox:
                        spacing 16
                        yalign 0.5
                        add "images/boss/s%02d.png" % hh["sprite"] fit "contain" xysize (120, 140) matrixcolor (IdentityMatrix() if hh["unlocked"] else BrightnessMatrix(-0.7))
                        vbox:
                            yalign 0.5
                            spacing 6
                            text hh["name"] style "rp_text" size 30 color ("#ffe9a8" if hh["unlocked"] else "#b9b1d8")
                            if hh["unlocked"]:
                                text ("호감도 %d / 100" % hh["aff"]) style "rp_text" size 22
                                bar value StaticValue(hh["aff"], 100) xsize 260 ysize 16 left_bar pill("#ff8fd0") right_bar pill("track") thumb None
                            else:
                                text "잠김" style "rp_text" size 24 color "#ffb0b0"
    frame:
        style "rp_panel"
        xpos 580
        ypos 128
        xsize 1300
        ysize 905
        padding (30, 18)
        add "images/boss/s%02d.png" % h["sprite"] fit "contain" xysize (520, 740) xpos 0 ypos 0 matrixcolor (IdentityMatrix() if h["unlocked"] else BrightnessMatrix(-0.75))
        vbox:
            xpos 560
            spacing 8
            text h["name"] style "rp_text" size 56 color "#fff3a8" outlines [(8, "#6a3aa8", 0, 3)]
            text h["desc"] style "rp_text" size 24 color "#f0e8ff"
            if not h["unlocked"]:
                null height 20
                text ("필드 보스  %s 을(를) 쓰러뜨리면 만날 수 있어요." % [b["name"] for b in G.meta["bosses"] if b["id"] == h["boss_id"]][0]) style "rp_text" size 30 color "#ffd6ec"
            else:
                text ("호감도  %d / 100" % h["aff"]) style "rp_text" size 32 color "#ffc0e6"
                bar value StaticValue(h["aff"], 100) xsize 640 ysize 24 left_bar pill("#ff8fd0") right_bar pill("track") thumb None
                text ("호감도 보너스: %s +%.1f%%  (최대 +%.1f%%)" % (h["bonus_text"], h["bonus_now"], h["bonus_max"])) style "rp_text" size 26 color "#b6ffca"
                null height 6
                hbox:
                    spacing 16
                    textbutton ("대화하기  (오늘 %d회 남음)" % h["talks_left"]):
                        style "rp_btn_pink"
                        xsize 500
                        text_size 30
                        sensitive h["talks_left"] > 0
                        action Return(("talk", h["id"]))
                text ("선물하기  (%s 를 좋아해요 / 가방/상점에서 구매)" % h["likes_name"]) style "rp_text" size 28 color "#fff1a8"
                hbox:
                    spacing 10
                    for g in G.gifts:
                        textbutton ("%s x%d" % (g["name"], g["qty"])):
                            style ("rp_btn_yellow" if g["id"] == h["likes"] else "rp_button")
                            xsize 208
                            text_size 21
                            sensitive g["qty"] > 0
                            action Return(("gift", h["id"], g["id"]))
                text "이벤트" style "rp_text" size 30 color "#fff1a8"
                for evn in h["events"]:
                    textbutton (("%s   (호감도 %d)  " % (evn["title"], evn["aff"])) + ("완료" if evn["done"] else ("보기 >" if evn["ready"] else "잠김"))):
                        style ("rp_btn_mint" if evn["ready"] else "rp_button")
                        xsize 640
                        text_size 22
                        sensitive evn["ready"]
                        action Return(("event", h["id"], evn["idx"]))
    use back_button

# ── 가방 / 상점 ──────────────────────────────────────────────
screen bag_screen():
    $ items = G.inv["items"]
    add "images/bg/t08.webp"
    add Solid("#2a1d5ab0")
    use topbar
    frame:
        style "rp_panel"
        xpos 40
        ypos 128
        xsize 920
        ysize 880
        padding (26, 20)
        vbox:
            spacing 10
            text "가방" style "rp_text" size 44 color "#fff1a8"
            if not items:
                text "가방이 비어 있어요.\n보스를 잡으면 트로피가 나오고,\n히로인 이벤트로 기념품을 얻을 수 있어요." style "rp_text" size 26 color "#dcd4ff"
            viewport:
                ysize 760
                mousewheel True
                draggable True
                scrollbars "vertical"
                vbox:
                    spacing 10
                    for it in items:
                        frame:
                            background Frame("gui/rp/card.png", 30, 30, 30, 30)
                            xfill True
                            padding (20, 10)
                            hbox:
                                spacing 16
                                vbox:
                                    xsize 520
                                    yalign 0.5
                                    text ("%s  x%d" % (it["name"], it["qty"])) style "rp_text" size 30 color "#ffe9a8"
                                    text it["desc"] style "rp_text" size 20 color "#dcd4ff"
                                if it["sell"]:
                                    textbutton ("상점에 판매\n%s G" % fmt(it["sell"])) style "rp_btn_orange" xsize 190 text_size 22 action Function(sell_item, it["id"], 1)
                                if it["kind"] == "potion":
                                    textbutton "사용" style "rp_btn_mint" xsize 190 text_size 26 action Function(use_item, it["id"])
    frame:
        style "rp_panel"
        xpos 980
        ypos 128
        xsize 900
        ysize 560
        padding (26, 20)
        vbox:
            spacing 10
            text "상점" style "rp_text" size 44 color "#fff1a8"
            for sh in G.inv["shop"]:
                frame:
                    background Frame("gui/rp/card_blue.png", 30, 30, 30, 30)
                    xfill True
                    padding (20, 8)
                    hbox:
                        spacing 16
                        vbox:
                            xsize 480
                            yalign 0.5
                            text sh["name"] style "rp_text" size 28 color "#ffffff"
                            text sh["desc"] style "rp_text" size 19 color "#e6f0ff"
                        textbutton ("%s G" % fmt(sh["price"])) style "rp_btn_mint" xsize 170 text_size 24 sensitive G.player["gold"] >= sh["price"] action Function(shop_buy, sh["id"], 1)
                        textbutton "x5" style "rp_button" xsize 100 text_size 24 sensitive G.player["gold"] >= sh["price"] * 5 action Function(shop_buy, sh["id"], 5)
    frame:
        style "rp_panel"
        xpos 980
        ypos 704
        xsize 900
        ysize 304
        padding (26, 16)
        vbox:
            spacing 4
            text "우편함" style "rp_text" size 34 color "#fff1a8"
            if not G.inv["mail"]:
                text "받은 소식이 없어요." style "rp_text" size 22 color "#dcd4ff"
            for m in G.inv["mail"][:5]:
                text ("%s  %s" % (time_ago(m["t"]), m["text"])) style "rp_text" size 20 color "#f0e8ff"
    use back_button

# ── 경매장 ───────────────────────────────────────────────────
screen auction_screen():
    default tab = "browse"
    default s_item = None
    default s_qty = 1
    default s_price = 0
    default s_buy = False
    default s_hours = 12
    $ p = G.player
    $ ls = G.auction["listings"]
    $ inv_sell = [it for it in G.inv["items"] if it["kind"] in ("trophy", "memento")]
    add "images/bg/t02.webp"
    add Solid("#2a1d5ab8")
    use topbar
    hbox:
        xpos 40
        ypos 122
        spacing 14
        textbutton "구매" style "rp_button" xsize 200 text_size 30 selected (tab == "browse") action SetScreenVariable("tab", "browse")
        textbutton "판매하기" style "rp_button" xsize 200 text_size 30 selected (tab == "sell") action SetScreenVariable("tab", "sell")
        textbutton "내 경매" style "rp_button" xsize 200 text_size 30 selected (tab == "mine") action SetScreenVariable("tab", "mine")
        textbutton "새로고침" style "rp_btn_mint" xsize 200 text_size 30 action Function(refresh_auction)
    text ("골드로만 거래해요. 낙찰 수수료 %d%%" % G.auction["fee"]) style "rp_text" size 22 color "#ffe1f3" xalign 1.0 xoffset -50 ypos 150

    frame:
        style "rp_panel"
        xpos 40
        ypos 222
        xsize 1840
        ysize 790
        padding (26, 18)
        if tab == "browse":
            viewport:
                mousewheel True
                draggable True
                scrollbars "vertical"
                vbox:
                    spacing 10
                    for L in ls:
                        if not L["mine"]:
                            frame:
                                background Frame("gui/rp/card_purple.png" if L["leading"] else "gui/rp/card.png", 30, 30, 30, 30)
                                xfill True
                                padding (20, 8)
                                hbox:
                                    spacing 16
                                    vbox:
                                        xsize 560
                                        yalign 0.5
                                        text ("%s  x%d" % (L["name"], L["qty"])) style "rp_text" size 30 color "#ffe9a8"
                                        text ("판매자 %s   남은 시간 %s%s" % (L["seller"], fmt_left(L["left"]), "   (내가 최고 입찰!)" if L["leading"] else "")) style "rp_text" size 20 color "#dcd4ff"
                                    vbox:
                                        xsize 300
                                        yalign 0.5
                                        text ("현재가 %s G" % fmt(L["current"])) style "rp_text" size 26 color "#ffe27a"
                                        text ("기본가 %s G" % fmt(L["base"])) style "rp_text" size 18 color "#c9c0ea"
                                    textbutton ("입찰 %s G" % fmt(L["next_bid"])):
                                        style "rp_btn_pink"
                                        xsize 260
                                        text_size 24
                                        yalign 0.5
                                        sensitive (p["gold"] >= L["next_bid"] and not L["leading"])
                                        action Function(auction_bid, L["id"], L["next_bid"])
                                    if L["buyout"]:
                                        textbutton ("즉시 구매 %s G" % fmt(L["buyout"])):
                                            style "rp_btn_mint"
                                            xsize 300
                                            text_size 22
                                            yalign 0.5
                                            sensitive p["gold"] >= L["buyout"]
                                            action Function(auction_buyout, L["id"])
                    if not ls:
                        text "지금 열려 있는 경매가 없어요." style "rp_text" size 28
        elif tab == "sell":
            hbox:
                spacing 30
                vbox:
                    xsize 820
                    spacing 8
                    text "판매할 아이템 (트로피 / 기념품)" style "rp_text" size 34 color "#fff1a8"
                    if not inv_sell:
                        text "올릴 수 있는 아이템이 없어요." style "rp_text" size 24 color "#dcd4ff"
                    viewport:
                        ysize 620
                        mousewheel True
                        draggable True
                        scrollbars "vertical"
                        vbox:
                            spacing 8
                            for it in inv_sell:
                                textbutton ("%s  x%d   (기본가 %s G)" % (it["name"], it["qty"], fmt(it["price"]))):
                                    style "rp_card_btn"
                                    xfill True
                                    text_size 26
                                    text_xalign 0.0
                                    selected (s_item == it["id"])
                                    action [SetScreenVariable("s_item", it["id"]), SetScreenVariable("s_qty", 1), SetScreenVariable("s_price", int(it["price"] * 0.9)), SetScreenVariable("s_buy", False)]
                vbox:
                    xsize 900
                    spacing 12
                    if s_item is None:
                        text "왼쪽에서 아이템을 골라 주세요." style "rp_text" size 28 color "#dcd4ff"
                    else:
                        $ base_it = [i for i in inv_sell if i["id"] == s_item]
                        if base_it:
                            $ bi = base_it[0]
                            text bi["name"] style "rp_text" size 40 color "#ffe9a8"
                            hbox:
                                spacing 12
                                text ("수량 %d" % s_qty) style "rp_text" size 28 yalign 0.5
                                textbutton "-" style "rp_button" xsize 80 text_size 30 action SetScreenVariable("s_qty", max(1, s_qty - 1))
                                textbutton "+" style "rp_button" xsize 80 text_size 30 action SetScreenVariable("s_qty", min(bi["qty"], s_qty + 1))
                            text ("시작가  %s G   (기본가 %s G)" % (fmt(s_price), fmt(bi["price"] * s_qty))) style "rp_text" size 30 color "#ffe27a"
                            hbox:
                                spacing 10
                                textbutton "-10%" style "rp_button" xsize 130 text_size 24 action SetScreenVariable("s_price", max(1, int(s_price * 0.9)))
                                textbutton "+10%" style "rp_button" xsize 130 text_size 24 action SetScreenVariable("s_price", int(s_price * 1.1) + 1)
                                textbutton "x2" style "rp_button" xsize 110 text_size 24 action SetScreenVariable("s_price", s_price * 2)
                                textbutton "/2" style "rp_button" xsize 110 text_size 24 action SetScreenVariable("s_price", max(1, s_price // 2))
                                textbutton "기본가" style "rp_btn_mint" xsize 150 text_size 24 action SetScreenVariable("s_price", bi["price"] * s_qty)
                            textbutton ("즉시 구매가: 시작가의 160%  (%s G)" % fmt(int(s_price * 1.6)) if s_buy else "즉시 구매가: 없음"):
                                style ("rp_btn_yellow" if s_buy else "rp_button")
                                xsize 620
                                text_size 26
                                action ToggleScreenVariable("s_buy")
                            hbox:
                                spacing 10
                                text "기간" style "rp_text" size 28 yalign 0.5
                                for hh in G.auction["hours"]:
                                    textbutton ("%d시간" % hh) style "rp_button" xsize 140 text_size 26 selected (s_hours == hh) action SetScreenVariable("s_hours", hh)
                            text "시작가가 기본가의 약 130% 이하인데 입찰이 없으면\n경매 상인이 시작가에 사 줘요." style "rp_text" size 20 color "#dcd4ff"
                            textbutton "경매에 올리기" style "rp_btn_pink" xsize 520 text_size 36 action [Function(auction_create_api, s_item, s_qty, s_price, (int(s_price * 1.6) if s_buy else 0), s_hours), SetScreenVariable("s_item", None), SetScreenVariable("tab", "mine")]
        else:
            viewport:
                mousewheel True
                draggable True
                scrollbars "vertical"
                vbox:
                    spacing 10
                    $ mine = [L for L in ls if L["mine"]]
                    text ("내가 올린 경매  %d / %d" % (len(mine), G.auction["max_listings"])) style "rp_text" size 34 color "#fff1a8"
                    if not mine:
                        text "올린 경매가 없어요. '판매하기' 탭에서 올려 보세요!" style "rp_text" size 26 color "#dcd4ff"
                    for L in mine:
                        frame:
                            background Frame("gui/rp/card.png", 30, 30, 30, 30)
                            xfill True
                            padding (20, 8)
                            hbox:
                                spacing 16
                                vbox:
                                    xsize 760
                                    yalign 0.5
                                    text ("%s  x%d" % (L["name"], L["qty"])) style "rp_text" size 30 color "#ffe9a8"
                                    text ("현재가 %s G   %s   남은 시간 %s" % (fmt(L["current"]), ("최고 입찰자 " + L["bidder"]) if L["bidder"] else "아직 입찰 없음", fmt_left(L["left"]))) style "rp_text" size 20 color "#dcd4ff"
                                textbutton "취소" style "rp_btn_orange" xsize 200 text_size 26 yalign 0.5 sensitive (not L["bidder"]) action Function(auction_cancel, L["id"])
    use back_button
