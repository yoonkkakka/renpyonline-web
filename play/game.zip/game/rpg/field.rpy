# 실시간 오픈필드: 조이스틱/키보드 이동, PK, 자동사냥(몬스터), 채팅 (PC 빌드 전용)

init -5 python:
    import math as _fmath
    import pygame_sdl2 as _pg

    FIELD_SPEED = 260.0          # 초당 이동 픽셀(서버 클램프 700보다 넉넉히 낮게)
    FIELD_HUNT_RANGE = 130.0     # 자동사냥 공격 사거리(px)
    FIELD_MAP_W = 6000
    FIELD_MAP_H = 6000
    FIELD_JOY_BASE = (150, 0)    # y는 화면 실행 시 화면 높이로 보정
    FIELD_JOY_RADIUS = 90

    _DIR_ORDER = ["e", "se", "s", "sw", "w", "nw", "n", "ne"]
    _FIELD_GRID = {"nw": (0, 0), "n": (1, 0), "ne": (2, 0), "w": (0, 1), "s": (1, 1), "e": (2, 1),
                   "sw": (0, 2), "se": (2, 2)}
    FIELD_SPRITE_CACHE = {}   # pid -> im.Data(업로드한 시트) 또는 False(없음, 기본 텍스쳐)
    FIELD_OPERATOR_USERNAME = "윤현"   # 이 계정만 운영자 전용 텍스쳐를 쓴다. 나머지는 일반 기본 텍스쳐.

    def field_default_prefix(name):
        return "char" if name == FIELD_OPERATOR_USERNAME else "char_default"

    def field_sprite_frame(sheet, direction, name=""):
        """sheet 가 없으면(None/False) 기본 텍스쳐(운영자 계정만 전용, 나머지는 공용), 있으면 업로드한 3x3 시트에서 잘라 쓴다."""
        if not sheet:
            return "images/field/%s_%s.png" % (field_default_prefix(name), direction)
        cx, cy = _FIELD_GRID.get(direction, (1, 1))
        return Transform(sheet, crop=(cx / 3.0, cy / 3.0, 1.0 / 3.0, 1.0 / 3.0))

    def has_field_sprite():
        res = safe(api, "GET", "/api/field/sprite")
        return bool(res and res.get("data"))

    def upload_field_sprite():
        if not renpy.windows:
            renpy.notify(_("이 기기에서는 이미지 업로드를 지원하지 않아요."))
            return False
        path = pick_image_file()
        if not path:
            return False
        try:
            code = encode_field_sprite(path, max_chars=1300000)
        except ApiFail as e:
            renpy.notify(str(e))
            return False
        except Exception:
            renpy.notify(_("이미지를 읽을 수 없습니다."))
            return False
        if safe(api, "PUT", "/api/field/sprite", {"data": code}):
            renpy.notify(_("필드 캐릭터 이미지가 등록되었어요!"))
            return True
        return False

    def download_default_field_texture():
        """운영자가 올린 원본 참고 이미지 대신, 실제 게임에서 쓰는 기본 8방향 텍스쳐를 플레이어가 내 PC에 저장할 수 있게 한다."""
        if not renpy.windows:
            renpy.notify(_("이 기기에서는 다운로드를 지원하지 않아요."))
            return
        dest = pick_save_file("field_texture.png", _("기본 필드 텍스쳐 저장"))
        if not dest:
            return
        import shutil
        sheet_name = "char_sheet_default.png" if G.player["username"] == FIELD_OPERATOR_USERNAME else "char_sheet_generic.png"
        src = os.path.join(config.gamedir, "images", "field", sheet_name)
        try:
            shutil.copyfile(src, dest)
            renpy.notify(_("기본 텍스쳐를 저장했어요!"))
        except Exception:
            renpy.notify(_("저장에 실패했어요."))

    def field_upload_and_continue():
        ok = upload_field_sprite()
        if ok:
            FIELD_SPRITE_CACHE.clear()   # 방금 올린 내 캐시도 새로 받아오게
            return "uploaded"
        return None

    def fetch_field_sprite(pid):
        """다른 플레이어의 업로드 스프라이트를 1회 조회해서 캐시(반복 조회 방지)."""
        if pid in FIELD_SPRITE_CACHE:
            return FIELD_SPRITE_CACHE[pid]
        res = safe(api, "GET", "/api/field/sprite?target=" + pid)
        data = res.get("data") if res else None
        if data:
            raw = base64.b64decode(data.split(";base64,", 1)[1])
            FIELD_SPRITE_CACHE[pid] = im.Data(raw, pid + "_field.png")
        else:
            FIELD_SPRITE_CACHE[pid] = False
        return FIELD_SPRITE_CACHE[pid]

    def _snap_dir(vx, vy):
        if abs(vx) < 1e-3 and abs(vy) < 1e-3:
            return None
        ang = _fmath.atan2(vy, vx)   # 화면 좌표: y 아래로 증가
        idx = int(((ang + _fmath.pi / 8) % (2 * _fmath.pi)) / (_fmath.pi / 4))
        return _DIR_ORDER[idx % 8]

    class FieldState(object):
        def __init__(self):
            self.fs = None
            self.channel = None
            self.me = None
            self.x = FIELD_MAP_W / 2
            self.y = FIELD_MAP_H / 2
            self.facing = "s"
            self.hp = 1
            self.hp_max = 1
            self.karma = 0
            self.players = {}     # pid -> dict
            self.monsters = {}    # id -> dict
            self.chat = []
            self.joy_vec = (0.0, 0.0)
            self.joy_engaged = False
            self.joy_press_started_inside = False
            self.last_sent = (None, None, None)
            self.connected = False
            self.error = None
            self.dead_until = 0.0
            self.auto_hunt = False
            self.last_auto_attack = 0.0

        def connect(self):
            import time as _t
            host, port, use_tls = FIELD_HOST, FIELD_PORT, FIELD_TLS
            self.fs = FieldSocket()
            try:
                self.fs.connect(host, port, "/ws/field?token=" + G.token, use_tls, timeout=20)
            except Exception as e:
                self.error = str(e)
                return False
            # 웰컴 메시지 대기(최대 5초)
            t0 = _t.time()
            while _t.time() - t0 < 5.0:
                for m in self.fs.poll():
                    if m.get("t") == "welcome":
                        self._apply_welcome(m)
                        self.connected = True
                        return True
                    if m.get("t") == "_closed":
                        self.error = "서버 연결이 끊어졌어요."
                        return False
                renpy.pause(0.05, hard=True)
            self.error = "서버 응답이 없어요."
            return False

        def _apply_welcome(self, m):
            self.channel = m["channel"]
            self.me = m["me"]
            self.players = {p["pid"]: p for p in m["players"]}
            self.monsters = {mo["id"]: mo for mo in m["monsters"]}
            self.chat = m["chat"]
            mine = self.players.get(self.me)
            if mine:
                self.x, self.y, self.facing = mine["x"], mine["y"], mine["facing"]
                self.hp, self.hp_max, self.karma = mine["hp"], mine["hp_max"], mine["karma"]
            self.chat.append({"name": _("시스템"), "text": _("캐릭터는 또 다른 나입니다."), "t": time.time()})

        def poll_net(self):
            if not self.fs:
                return
            for m in self.fs.poll():
                t = m.get("t")
                if t == "_closed":
                    self.connected = False
                elif t == "join":
                    pl = m["player"]
                    self.players[pl["pid"]] = pl
                elif t == "leave":
                    self.players.pop(m.get("pid"), None)
                elif t == "move":
                    pl = self.players.get(m["pid"])
                    if pl:
                        pl["x"], pl["y"], pl["facing"] = m["x"], m["y"], m["facing"]
                elif t == "hit":
                    tgt = self.players.get(m["target"])
                    if tgt:
                        tgt["hp"] = m["hp"]
                    if m["target"] == self.me:
                        self.hp = m["hp"]
                        if m.get("dead"):
                            self.karma = self.karma  # 내가 죽은 쪽이면 karma 변화 없음
                            self.hp = self.hp_max
                            self.x, self.y = m.get("respawn_x", self.x), m.get("respawn_y", self.y)
                            self.dead_until = time.time() + 1.5
                            renpy.notify(_("당했어요... 마을 인근에서 부활했어요."))
                    if m["attacker"] == self.me and m.get("dead"):
                        self.karma = m["killer_karma"]
                        renpy.notify(_("상대를 쓰러뜨렸어요! (카르마 %d)") % self.karma)
                elif t == "monster_spawn":
                    mo = m["monster"]
                    self.monsters[mo["id"]] = mo
                elif t == "monster_hit":
                    mo = self.monsters.get(m["id"])
                    if mo:
                        mo["hp"] = m["hp"]
                        mo["alive"] = not m.get("dead", False)
                    if m.get("dead") and m.get("by") == self.me:
                        rw = m["reward"]
                        renpy.notify(_("몬스터 처치! 경험치 +%s, 골드 +%s") % (fmt(rw["exp"]), fmt(rw["gold"])))
                elif t == "chat":
                    self.chat.append({"name": m["name"], "text": m["text"], "t": m["t"]})
                    self.chat = self.chat[-40:]

        def send(self, obj):
            if self.fs and self.connected:
                self.fs.send_json(obj)

        # ── 입력(조이스틱 + WASD/화살표, 매 틱 폴링) ──────────
        def read_input(self, base_pos):
            pressed = _pg.mouse.get_pressed()
            mpos = renpy.get_mouse_pos()   # 버추얼(가상) 해상도 좌표 — pygame 물리 좌표와 다름
            if mpos is None:
                mx, my = base_pos
            else:
                mx, my = mpos
            bx, by = base_pos
            if pressed[0]:
                dist0 = ((mx - bx) ** 2 + (my - by) ** 2) ** 0.5
                if not self.joy_engaged and dist0 <= FIELD_JOY_RADIUS * 1.6:
                    self.joy_engaged = True
                if self.joy_engaged:
                    dx, dy = mx - bx, my - by
                    dist = max(1.0, (dx * dx + dy * dy) ** 0.5)
                    clamp = min(dist, FIELD_JOY_RADIUS)
                    nx, ny = dx / dist, dy / dist
                    self.joy_vec = (nx * (clamp / FIELD_JOY_RADIUS), ny * (clamp / FIELD_JOY_RADIUS))
            else:
                self.joy_engaged = False
                self.joy_vec = (0.0, 0.0)

            keys = _pg.key.get_pressed()
            kx = (1 if keys[_pg.K_d] or keys[_pg.K_RIGHT] else 0) - (1 if keys[_pg.K_a] or keys[_pg.K_LEFT] else 0)
            ky = (1 if keys[_pg.K_s] or keys[_pg.K_DOWN] else 0) - (1 if keys[_pg.K_w] or keys[_pg.K_UP] else 0)
            if kx or ky:
                n = (kx * kx + ky * ky) ** 0.5
                return (kx / n, ky / n)
            return self.joy_vec

        def _auto_hunt_step(self):
            """가장 가까운 살아있는 몬스터를 향해 이동, 사거리 안이면 자동 공격(레벨업 가능)."""
            target, best_d = None, 1e18
            for mo in self.monsters.values():
                if not mo["alive"]:
                    continue
                d = ((mo["x"] - self.x) ** 2 + (mo["y"] - self.y) ** 2) ** 0.5
                if d < best_d:
                    best_d, target = d, mo
            if not target:
                return (0.0, 0.0)
            if best_d <= FIELD_HUNT_RANGE:
                now = time.time()
                if now - self.last_auto_attack >= 1.0:
                    self.last_auto_attack = now
                    self.hit_monster(target["id"], field_my_hunt_dmg(G.player["stats"]))
                return (0.0, 0.0)
            dx, dy = target["x"] - self.x, target["y"] - self.y
            n = max(1.0, (dx * dx + dy * dy) ** 0.5)
            return (dx / n, dy / n)

        def tick(self, base_pos, dt):
            self.poll_net()
            if time.time() < self.dead_until:
                return
            vx, vy = self._auto_hunt_step() if self.auto_hunt else self.read_input(base_pos)
            if vx or vy:
                self.x = max(0, min(FIELD_MAP_W, self.x + vx * FIELD_SPEED * dt))
                self.y = max(0, min(FIELD_MAP_H, self.y + vy * FIELD_SPEED * dt))
                d = _snap_dir(vx, vy)
                if d:
                    self.facing = d
                key = (round(self.x, 1), round(self.y, 1), self.facing)
                if key != self.last_sent:
                    self.last_sent = key
                    self.send({"t": "move", "x": self.x, "y": self.y, "facing": self.facing})

        def attack(self, target_pid):
            self.send({"t": "attack", "target": target_pid})

        def hit_monster(self, mid, dmg):
            self.send({"t": "monster", "id": mid, "damage": dmg})

        def say(self, text):
            text = text.strip()
            if text:
                self.send({"t": "chat", "text": text})

        def report(self, target_pid, message):
            self.send({"t": "report", "target": target_pid, "message": message})

        def leave(self):
            if self.fs:
                self.fs.close()
            self.connected = False

    FIELD = None

    def field_connect():
        global FIELD
        import re as _re
        m = _re.match(r"https?://([^/:]+)(:(\d+))?", SERVER_URL)
        host = m.group(1)
        tls = SERVER_URL.startswith("https")
        port = int(m.group(3)) if m.group(3) else (443 if tls else 80)
        global FIELD_HOST, FIELD_PORT, FIELD_TLS
        FIELD_HOST, FIELD_PORT, FIELD_TLS = host, port, tls
        FIELD = FieldState()
        ok = FIELD.connect()
        if not ok:
            renpy.notify(FIELD.error or _("필드 서버에 연결할 수 없어요."))
        return ok

    def field_tick():
        if FIELD is None or not FIELD.connected:
            return "disconnected"
        base = (150, config.screen_height - 150)
        FIELD.tick(base, 0.05)
        return None

    def field_my_hunt_dmg(stats):
        """대략적인 1회 타격 데미지(스킬 없이 필드에서 바로 때리는 간이 공격)."""
        return int(stats["atk"] * random.uniform(0.9, 1.1))

    def field_toggle_auto_hunt():
        FIELD.auto_hunt = not FIELD.auto_hunt
        renpy.notify(_("자동사냥 시작!") if FIELD.auto_hunt else _("자동사냥 정지"))

    def field_hit_monster(mid):
        dmg = field_my_hunt_dmg(G.player["stats"])
        FIELD.hit_monster(mid, dmg)

    def field_send_chat_var(text):
        FIELD.say(text)
