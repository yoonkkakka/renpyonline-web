﻿# TODO: Translation updated at 2026-09-28 16:26

translate tchinese strings:

    # game/rpg/heroine_story.rpy:5
    old "오늘도 왔군요. ...딱히 기다린 건 아니에요."
    new "今天又來了呢。……我才沒有特意等你。"

    # game/rpg/heroine_story.rpy:5
    old "왕관이 무겁다고 한 적은 없어요. 가끔 어깨가 뻐근할 뿐이에요."
    new "我從沒說過王冠很重，只是肩膀偶爾會有點酸而已。"

    # game/rpg/heroine_story.rpy:5
    old "한강 바람이 좋네요. 같이 걸어도 나쁘지 않겠어요."
    new "漢江的風真舒服。一起散散步也不錯呢。"

    # game/rpg/heroine_story.rpy:5
    old "당신이 옆에 있으면 조용해도 괜찮아요."
    new "只要你在身邊，安靜也沒關係。"

    # game/rpg/heroine_story.rpy:5
    old "오늘은 기분이 좋아요! ...표정이 풀렸다고요? 착각이에요."
    new "今天心情很好！……你說我表情變柔和了？你看錯了。"

    # game/rpg/heroine_story.rpy:5
    old "다음엔 어디로 가죠? 아, 아니, 그냥 물어본 거예요."
    new "下次要去哪裡呢？啊，不，只是隨口問問而已。"

    # game/rpg/heroine_story.rpy:5
    old "...책 냄새가 나네요. 오늘은 어떤 이야기를 가져왔나요?"
    new "……有股書的味道呢。今天帶來了什麼故事？"

    # game/rpg/heroine_story.rpy:5
    old "밤은 길어요. 그래서 이야기가 필요하죠."
    new "夜很長，所以才需要故事啊。"

    # game/rpg/heroine_story.rpy:5
    old "별이 오늘따라 잘 보여요. 당신이 온 날은 늘 그래요."
    new "今天的星星特別清楚。你來的日子總是這樣。"

    # game/rpg/heroine_story.rpy:5
    old "소원이 있냐고요? 비밀이에요. 아직은요."
    new "問我有沒有心願？這是秘密，現在還不能說。"

    # game/rpg/heroine_story.rpy:5
    old "후후, 오늘은 마법이 잘 돼요. 기분 탓만은 아닐 거예요."
    new "呵呵，今天魔法特別順手，應該不只是心理作用。"

    # game/rpg/heroine_story.rpy:5
    old "조금만 더 곁에 있어 줄래요? 차가 식기 전까지만."
    new "能再多陪我一會兒嗎？就到茶涼之前。"

    # game/rpg/heroine_story.rpy:5
    old "어서 와요! 오늘 하늘은 정말 맑아요."
    new "歡迎回來！今天的天空真的很晴朗。"

    # game/rpg/heroine_story.rpy:5
    old "떠나는 것만 좋아했는데, 돌아올 곳이 생기니 이상해요."
    new "以前只喜歡離開，現在有了想回來的地方，感覺好奇怪。"

    # game/rpg/heroine_story.rpy:5
    old "디저트 냄새가 나는데요? ...아니에요, 기대 안 했어요!"
    new "聞到甜點的味道了？……才沒有，我才沒有期待呢！"

    # game/rpg/heroine_story.rpy:5
    old "다음엔 같이 비행기 구경 갈래요? 관제탑도 보여 줄게요."
    new "下次要不要一起去看飛機？我還可以帶你參觀管制塔。"

    # game/rpg/heroine_story.rpy:5
    old "오늘은 왠지 콧노래가 나와요. 당신 덕분이겠죠?"
    new "今天不知怎麼就哼起了歌，應該是託你的福吧？"

    # game/rpg/heroine_story.rpy:5
    old "지도에 없는 곳도 같이 가 보고 싶어요."
    new "就算是地圖上沒有的地方，也想和你一起去看看。"

    # game/rpg/heroine_story.rpy:5
    old "앗, 와 줬어요! 오늘 연습 엄청 열심히 했어요!"
    new "啊，你來了！今天我超級努力地練習了呢！"

    # game/rpg/heroine_story.rpy:5
    old "무대는 무섭지 않은데, 당신 앞에서는 조금 떨려요."
    new "站上舞臺並不害怕，但在你面前卻會有點緊張。"

    # game/rpg/heroine_story.rpy:5
    old "팬 서비스예요! ...라고 말하면 서운해요?"
    new "這是粉絲福利哦！……這麼說你會失落嗎？"

    # game/rpg/heroine_story.rpy:5
    old "노래 들어 줄래요? 오직 한 명만을 위한 무대예요."
    new "願意聽我唱歌嗎？這是隻為你一個人準備的舞臺。"

    # game/rpg/heroine_story.rpy:5
    old "오늘은 안무가 한 번에 됐어요! 칭찬해 줘요!"
    new "今天的舞步一次就成功了！快誇誇我！"

    # game/rpg/heroine_story.rpy:5
    old "힘든 날에도 웃을 수 있는 건 당신 덕분이에요."
    new "就算是辛苦的日子也能笑出來，都是託你的福。"

    # game/rpg/heroine_story.rpy:28
    old "꽃...? 나한테? ...고마워요. 진심으로 기뻐요."
    new "花……？給我的？……謝謝你，我真心覺得很開心。"

    # game/rpg/heroine_story.rpy:28
    old "이런 걸 다 챙겨 오다니, 의외로 세심하네요."
    new "居然還特意帶來這個，沒想到你挺細心的呢。"

    # game/rpg/heroine_story.rpy:28
    old "이 책... 제가 찾던 거예요! 어떻게 알았어요?"
    new "這本書……正是我一直在找的！你怎麼知道的？"

    # game/rpg/heroine_story.rpy:28
    old "고마워요. 조용한 밤에 잘 어울릴 것 같아요."
    new "謝謝你，感覺很適合安靜的夜晚。"

    # game/rpg/heroine_story.rpy:28
    old "와, 달콤해! 비행 전에 딱이에요. 고마워요!"
    new "哇，好甜！正好適合飛行前吃，謝謝你！"

    # game/rpg/heroine_story.rpy:28
    old "선물이에요? 소중하게 간직할게요."
    new "是禮物嗎？我會好好珍藏的。"

    # game/rpg/heroine_story.rpy:28
    old "우와, 제가 제일 좋아하는 맛이에요! 감동이에요!"
    new "哇，是我最喜歡的味道！好感動！"

    # game/rpg/heroine_story.rpy:28
    old "고마워요! 연습실에 놓아 둘게요."
    new "謝謝你！我會放在練習室裡的。"

    # game/rpg/heroine_story.rpy:35
    old "노을 진 옥상, 여왕이 왕관을 만지작거린다."
    new "夕陽西下的天台上，女王輕輕摩挲著王冠。"

    # game/rpg/heroine_story.rpy:35
    old "이 왕관, 사실 엄청 무거워요."
    new "這頂王冠，其實真的很重。"

    # game/rpg/heroine_story.rpy:35
    old "잠깐 내려놓고 쉬어요. 아무도 안 보니까."
    new "先放下來休息一下吧，反正沒人在看。"

    # game/rpg/heroine_story.rpy:35
    old "...그래도 될까요? 정말 아무도 안 보죠?"
    new "……真的可以嗎？真的沒人在看吧？"

    # game/rpg/heroine_story.rpy:35
    old "여왕은 처음으로 소리 내어 웃었다."
    new "女王第一次放聲笑了出來。"

    # game/rpg/heroine_story.rpy:35
    old "한강 둔치, 저녁 바람이 불어온다."
    new "漢江邊的河畔，傍晚的風吹了過來。"

    # game/rpg/heroine_story.rpy:35
    old "서울이 이렇게 반짝이는 줄 몰랐어요. 항상 위에서만 내려다봤거든요."
    new "沒想到首爾竟然這麼閃耀，我以前總是從高處俯瞰而已。"

    # game/rpg/heroine_story.rpy:35
    old "이제는 같은 높이에서 볼 수 있잖아요."
    new "現在可以站在同樣的高度一起看了呀。"

    # game/rpg/heroine_story.rpy:35
    old "네. 그게... 생각보다 훨씬 좋네요."
    new "是啊……這感覺，比想象中好太多了。"

    # game/rpg/heroine_story.rpy:35
    old "둘은 말없이 오래도록 강을 바라보았다."
    new "兩人久久無言，靜靜望著江水。"

    # game/rpg/heroine_story.rpy:35
    old "여왕이 왕관을 조심스럽게 내려놓는다."
    new "女王小心翼翼地摘下了王冠。"

    # game/rpg/heroine_story.rpy:35
    old "이제 저는 여왕이 아니라, 그냥 한 사람으로 서 있고 싶어요."
    new "現在的我，不想再當女王，只想以一個普通人的身份站在這裡。"

    # game/rpg/heroine_story.rpy:35
    old "그래도 제 눈엔 언제나 특별해요."
    new "但在我眼中，你始終都很特別。"

    # game/rpg/heroine_story.rpy:35
    old "...바보. 그런 말은 반칙이에요."
    new "……笨蛋，這種話太犯規了。"

    # game/rpg/heroine_story.rpy:35
    old "밤하늘 아래, 여왕의 뺨이 살짝 붉어졌다."
    new "夜空下，女王的臉頰微微泛紅。"

    # game/rpg/heroine_story.rpy:35
    old "밤의 도서관, 촛불 하나만 켜져 있다."
    new "夜晚的圖書館裡，只點著一支蠟燭。"

    # game/rpg/heroine_story.rpy:35
    old "여기는 제가 제일 좋아하는 곳이에요. 조용하고, 이야기가 많아서요."
    new "這裡是我最喜歡的地方，安靜，而且藏著很多故事。"

    # game/rpg/heroine_story.rpy:35
    old "그럼 같이 읽을까요?"
    new "那要不要一起讀呢？"

    # game/rpg/heroine_story.rpy:35
    old "...좋아요. 대신 넘기는 건 제가 할게요."
    new "……好啊，不過翻頁的事交給我吧。"

    # game/rpg/heroine_story.rpy:35
    old "페이지 넘기는 소리가 밤을 채웠다."
    new "翻頁的聲音填滿了整個夜晚。"

    # game/rpg/heroine_story.rpy:35
    old "별빛 산책로, 하늘이 유난히 맑다."
    new "星光小徑上，今晚的天空格外清澈。"

    # game/rpg/heroine_story.rpy:35
    old "저 별들, 사실 전부 이름을 붙여 줬어요."
    new "那些星星，其實我都給它們起了名字。"

    # game/rpg/heroine_story.rpy:35
    old "저건 뭐라고 불러요?"
    new "那顆星星叫什麼名字？"

    # game/rpg/heroine_story.rpy:35
    old "저건... 당신 별이에요. 방금 정했어요."
    new "那顆……是你的星星，我剛剛才決定的。"

    # game/rpg/heroine_story.rpy:35
    old "마녀는 부끄러운 듯 모자를 눌러썼다."
    new "女巫像是有些害羞，把帽子壓得更低了。"

    # game/rpg/heroine_story.rpy:35
    old "마녀가 작은 병을 건넨다. 안에는 별빛이 반짝인다."
    new "女巫遞來一個小瓶子，裡面閃爍著星光。"

    # game/rpg/heroine_story.rpy:35
    old "제 마지막 소원이에요. 당신이 늘 웃을 수 있기를."
    new "這是我最後的心願，希望你能一直笑下去。"

    # game/rpg/heroine_story.rpy:35
    old "그 소원은 이미 이루어졌어요. 당신이 옆에 있으니까."
    new "那個心願早就實現了，因為你就在我身邊。"

    # game/rpg/heroine_story.rpy:35
    old "...정말, 못 당하겠네요."
    new "……真是的，拿你沒辦法呢。"

    # game/rpg/heroine_story.rpy:35
    old "병 속의 별빛이 조용히 깜박였다."
    new "瓶中的星光靜靜地閃爍著。"

    # game/rpg/heroine_story.rpy:35
    old "활주로 끝, 붉은 노을이 비행기를 물들인다."
    new "跑道的盡頭，紅色的晚霞染紅了飛機。"

    # game/rpg/heroine_story.rpy:35
    old "저 비행기, 어디든 갈 수 있어요. 그런데 오늘은 안 타고 싶네요."
    new "那架飛機，可以飛去任何地方。可是今天卻不太想搭乘呢。"

    # game/rpg/heroine_story.rpy:35
    old "왜요?"
    new "為什麼？"

    # game/rpg/heroine_story.rpy:35
    old "여기 있는 게 더 좋아서요. ...이유는 비밀!"
    new "因為待在這裡更好啊。……理由是秘密！"

    # game/rpg/heroine_story.rpy:35
    old "이륙녀는 웃으며 하늘을 올려다보았다."
    new "起飛女笑著仰望天空。"

    # game/rpg/heroine_story.rpy:35
    old "여행 계획표가 책상 위에 펼쳐져 있다."
    new "旅行計劃表攤開在桌子上。"

    # game/rpg/heroine_story.rpy:35
    old "가고 싶은 곳을 적어 봤어요. 전부 같이 가는 걸로요."
    new "我把想去的地方都寫下來了，全部都要一起去哦。"

    # game/rpg/heroine_story.rpy:35
    old "전부요? 시간이 꽤 걸리겠는데요."
    new "全部嗎？那可要花不少時間呢。"

    # game/rpg/heroine_story.rpy:35
    old "그러니까 오래오래 함께 있어야죠!"
    new "所以才要長長久久地在一起呀！"

    # game/rpg/heroine_story.rpy:35
    old "계획표에는 끝이 없는 목록이 이어졌다."
    new "計劃表上列出了一份沒有盡頭的清單。"

    # game/rpg/heroine_story.rpy:35
    old "관제탑 아래, 바람이 불어온다."
    new "管制塔下，風輕輕吹過。"

    # game/rpg/heroine_story.rpy:35
    old "이제 떠나는 것보다 돌아오는 게 더 좋아졌어요."
    new "現在比起離開，我更喜歡歸來的感覺了。"

    # game/rpg/heroine_story.rpy:35
    old "돌아올 곳이 여기라서요?"
    new "因為要回來的地方是這裡嗎？"

    # game/rpg/heroine_story.rpy:35
    old "네. 당신이 있는 곳이라서요."
    new "是的，因為這裡有你在。"

    # game/rpg/heroine_story.rpy:35
    old "멀리서 비행기 한 대가 노을 속으로 사라졌다."
    new "遠處一架飛機漸漸消失在晚霞之中。"

    # game/rpg/heroine_story.rpy:35
    old "연습실, 거울 앞에서 아이돌이 땀을 닦는다."
    new "練習室裡，偶像在鏡子前擦著汗水。"

    # game/rpg/heroine_story.rpy:35
    old "아직 동작이 딱딱하죠? 조금만 봐 줄래요?"
    new "動作還有點僵硬吧？能再幫我看看嗎？"

    # game/rpg/heroine_story.rpy:35
    old "충분히 좋아요. 연습하는 모습이 제일 멋있어요."
    new "已經很棒了，你練習時的樣子最迷人了。"

    # game/rpg/heroine_story.rpy:35
    old "치, 그런 말을 들으면 더 열심히 하게 되잖아요."
    new "哼，聽到這種話會讓人更想加把勁的啦。"

    # game/rpg/heroine_story.rpy:35
    old "음악이 다시 시작되고, 아이돌은 활짝 웃었다."
    new "音樂再次響起，偶像露出了燦爛的笑容。"

    # game/rpg/heroine_story.rpy:35
    old "비 오는 날, 텅 빈 무대 위."
    new "下雨天，空蕩蕩的舞臺上。"

    # game/rpg/heroine_story.rpy:35
    old "관객이 없어도 노래는 하고 싶었어요. 그런데 오늘은 당신이 있네요."
    new "就算沒有觀眾也想唱歌，不過今天有你在呢。"

    # game/rpg/heroine_story.rpy:35
    old "제일 앞자리에서 볼게요."
    new "我會坐在最前排看你的。"

    # game/rpg/heroine_story.rpy:35
    old "그럼 오늘은 당신만을 위한 콘서트예요!"
    new "那今天就是專屬於你一個人的演唱會！"

    # game/rpg/heroine_story.rpy:35
    old "빗소리가 반주가 되어 무대를 채웠다."
    new "雨聲化作伴奏，填滿了整個舞臺。"

    # game/rpg/heroine_story.rpy:35
    old "조명이 꺼진 무대, 스포트라이트 하나만 남았다."
    new "燈光熄滅的舞臺上，只剩下一束聚光燈。"

    # game/rpg/heroine_story.rpy:35
    old "제 무대의 단 한 명의 관객, 당신이에요."
    new "我舞臺上唯一的觀眾，就是你。"

    # game/rpg/heroine_story.rpy:35
    old "앞으로도 계속 지켜볼게요. 가장 앞에서."
    new "以後我也會一直在最前排看著你的。"

    # game/rpg/heroine_story.rpy:35
    old "약속이에요. 다음 무대도, 그다음 무대도!"
    new "說好了，下一場舞臺，還有下下場也是！"

    # game/rpg/heroine_story.rpy:35
    old "박수 소리는 단 한 사람의 것이었지만, 세상에서 가장 컸다."
    new "掌聲雖然只來自一個人，卻是世界上最響亮的。"

    # game/rpg/heroine_story.rpy:107
    old "젠장, 신참 주제에 꽤 하는데?"
    new "該死，一個新人還挺有兩下子？"

    # game/rpg/heroine_story.rpy:107
    old "내 왕관에 손대지 마, 이 자식아!"
    new "別碰我的王冠，你這傢伙！"

    # game/rpg/heroine_story.rpy:107
    old "크윽... 이 도시는 내 거라고!"
    new "唔……這座城市是我的！"

    # game/rpg/heroine_story.rpy:107
    old "신참치고는 꽤 하는군요."
    new "以新人來說，你還挺厲害的呢。"

    # game/rpg/heroine_story.rpy:107
    old "제 왕관에 손대지 마세요!"
    new "請不要碰我的王冠！"

    # game/rpg/heroine_story.rpy:107
    old "이 도시는 제 것이에요..."
    new "這座城市是屬於我的……"

    # game/rpg/heroine_story.rpy:107
    old "치직... 빌어먹을 시민이 감히!"
    new "滋滋……該死的市民竟敢！"

    # game/rpg/heroine_story.rpy:107
    old "진압 실패라니, 이게 무슨 오류야!"
    new "鎮壓失敗？這算什麼錯誤！"

    # game/rpg/heroine_story.rpy:107
    old "시스템... 꺼지지 마... 젠장!"
    new "系統……別關機……可惡！"

    # game/rpg/heroine_story.rpy:107
    old "치직... 시민의 저항 확인."
    new "滋滋……確認市民抵抗行為。"

    # game/rpg/heroine_story.rpy:107
    old "진압 실패. 재계산 중."
    new "鎮壓失敗，正在重新計算。"

    # game/rpg/heroine_story.rpy:107
    old "시스템 이상... 종료 위험."
    new "系統異常……存在關機風險。"

    # game/rpg/heroine_story.rpy:107
    old "죽고 나서도 화가 나는 건 처음이다!"
    new "死了以後還會這麼憤怒，這還是第一次！"

    # game/rpg/heroine_story.rpy:107
    old "이 원한을 받아라, 애송이!"
    new "接下這份怨念吧，小子！"

    # game/rpg/heroine_story.rpy:107
    old "크아악... 아직 끝나지 않았다!"
    new "啊啊啊……還沒有結束！"

    # game/rpg/heroine_story.rpy:107
    old "오랜만에 피가 끓는구나."
    new "好久沒有這樣熱血沸騰了。"

    # game/rpg/heroine_story.rpy:107
    old "이 원한을 받아 보아라."
    new "接下這份怨念吧。"

    # game/rpg/heroine_story.rpy:107
    old "아직... 끝나지 않았다."
    new "還……沒有結束。"

    # game/rpg/heroine_story.rpy:107
    old "꺼져, 귀찮게 굴지 말라고!"
    new "滾開，別來煩我！"

    # game/rpg/heroine_story.rpy:107
    old "내 밤을 망치다니, 각오해!"
    new "竟敢毀了我的夜晚，做好覺悟吧！"

    # game/rpg/heroine_story.rpy:107
    old "이 저주... 네놈도 못 피해..."
    new "這詛咒……你也逃不掉的……"

    # game/rpg/heroine_story.rpy:107
    old "밤을 방해하지 마세요."
    new "請不要打擾我的夜晚。"

    # game/rpg/heroine_story.rpy:107
    old "제 밤을 망치다니, 각오하세요."
    new "竟敢毀了我的夜晚，請做好覺悟。"

    # game/rpg/heroine_story.rpy:107
    old "이 저주... 당신도 피할 수 없어요."
    new "這詛咒……你也無法逃脫。"

    # game/rpg/heroine_story.rpy:107
    old "어이, 제법이네. 그래도 봐주진 않아!"
    new "喂，還挺有兩下子嘛，不過我可不會手下留情！"

    # game/rpg/heroine_story.rpy:107
    old "시끄러워, 총알이나 받아!"
    new "吵死了，吃我一發子彈！"

    # game/rpg/heroine_story.rpy:107
    old "젠장, 오늘 재수 없게 걸렸네!"
    new "該死，今天真是倒黴透了！"

    # game/rpg/heroine_story.rpy:107
    old "제법이네. 하지만 봐주진 않아!"
    new "還挺有兩下子嘛，不過我不會手下留情！"

    # game/rpg/heroine_story.rpy:107
    old "총알이나 받아!"
    new "吃我一發子彈！"

    # game/rpg/heroine_story.rpy:107
    old "오늘은 운이 없네..."
    new "今天運氣真差……"

    # game/rpg/heroine_story.rpy:107
    old "야근에 시달리는데 너까지 귀찮게 굴어!"
    new "加班已經夠煩了，你還來添亂！"

    # game/rpg/heroine_story.rpy:107
    old "마감이 코앞인데 이게 뭐 하는 짓이야!"
    new "截止日期都火燒眉毛了，你在搞什麼！"

    # game/rpg/heroine_story.rpy:107
    old "아, 진짜 다 때려치우고 싶다고!"
    new "啊，真的好想把這一切都甩掉不幹了！"

    # game/rpg/heroine_story.rpy:107
    old "야근 중인데 방해하지 마세요!"
    new "我正在加班，請不要打擾我！"

    # game/rpg/heroine_story.rpy:107
    old "마감이 코앞이라고요!"
    new "截止日期都快到了啊！"

    # game/rpg/heroine_story.rpy:107
    old "다 그만두고 싶어요..."
    new "真想把這一切都放棄……"

    # game/rpg/heroine_story.rpy:107
    old "길이 막혀서 짜증 난다고!"
    new "堵車堵得我心煩意亂！"

    # game/rpg/heroine_story.rpy:107
    old "비켜, 내 길을 막지 마!"
    new "讓開，別擋我的路！"

    # game/rpg/heroine_story.rpy:107
    old "젠장, 뚫려 버리다니!"
    new "可惡，居然被打通了！"

    # game/rpg/heroine_story.rpy:107
    old "길이 막혀서 답답하군."
    new "堵車真是讓人心煩。"

    # game/rpg/heroine_story.rpy:107
    old "제 길을 막지 마세요!"
    new "請不要擋住我的路！"

    # game/rpg/heroine_story.rpy:107
    old "뚫려 버렸군..."
    new "被打通了呢……"

    # game/rpg/heroine_story.rpy:107
    old "쿵!! (거대한 발이 땅을 뒤흔든다)"
    new "咚！！（巨大的腳重重踏在地面上）"

    # game/rpg/heroine_story.rpy:107
    old "쿠웅!! (분노한 눈빛이 번쩍인다)"
    new "轟隆！！（憤怒的眼神閃爍著光芒）"

    # game/rpg/heroine_story.rpy:107
    old "쿵... (왕관이 삐뚤어졌다)"
    new "咚……（王冠歪掉了）"

    # game/rpg/heroine_story.rpy:107
    old "쿵! (발을 구른다)"
    new "咚！（跺了跺腳）"

    # game/rpg/heroine_story.rpy:107
    old "쿠웅! (눈을 부릅뜬다)"
    new "轟隆！（瞪大了雙眼）"

    # game/rpg/heroine_story.rpy:107
    old "이륙 방해하지 마, 젠장!"
    new "別妨礙我起飛，可惡！"

    # game/rpg/heroine_story.rpy:107
    old "강제 착륙이라니 웃기지 마!"
    new "強制降落？開什麼玩笑！"

    # game/rpg/heroine_story.rpy:107
    old "추락이라니... 말도 안 돼!"
    new "居然要墜機……太荒唐了！"

    # game/rpg/heroine_story.rpy:107
    old "이륙을 방해하지 마세요."
    new "請不要妨礙我起飛。"

    # game/rpg/heroine_story.rpy:107
    old "강제 착륙은 곤란해요."
    new "強制降落的話我會很困擾的。"

    # game/rpg/heroine_story.rpy:107
    old "추락하다니... 말도 안 돼요."
    new "居然要墜機……太不像話了。"

    # game/rpg/heroine_story.rpy:107
    old "기밀 구역에 함부로 발을 들이다니!"
    new "竟敢擅自闖入機密區域！"

    # game/rpg/heroine_story.rpy:107
    old "보고서에 네 이름을 올려 주지!"
    new "我會把你的名字寫進報告裡！"

    # game/rpg/heroine_story.rpy:107
    old "크윽... 작전 실패라니, 빌어먹을!"
    new "唔……行動失敗，該死！"

    # game/rpg/heroine_story.rpy:107
    old "기밀 구역 침입 확인."
    new "確認有人闖入機密區域。"

    # game/rpg/heroine_story.rpy:107
    old "보고서에 이름을 올리겠습니다."
    new "我會將您的名字記入報告。"

    # game/rpg/heroine_story.rpy:107
    old "작전 실패라니..."
    new "行動竟然失敗了……"

    # game/rpg/heroine_story.rpy:107
    old "방화벽을 뚫어? 꽤 성가시네!"
    new "居然突破了防火牆？真是麻煩！"

    # game/rpg/heroine_story.rpy:107
    old "네 데이터 전부 지워 버릴 거야!"
    new "我要把你的資料全部刪除！"

    # game/rpg/heroine_story.rpy:107
    old "젠장, 시스템이 다운돼 간다!"
    new "可惡，系統要崩潰了！"

    # game/rpg/heroine_story.rpy:107
    old "방화벽을 뚫다니, 성가시네요."
    new "竟然突破了防火牆，真是麻煩呢。"

    # game/rpg/heroine_story.rpy:107
    old "데이터를 지워 버릴 거예요."
    new "我會把資料全部刪除的。"

    # game/rpg/heroine_story.rpy:107
    old "시스템이 다운돼 가요..."
    new "系統正在崩潰……"

    # game/rpg/heroine_story.rpy:107
    old "파도에 휩쓸려 사라져라!"
    new "被巨浪吞沒，消失吧！"

    # game/rpg/heroine_story.rpy:107
    old "감히 바다를 얕보다니, 미친 놈!"
    new "竟敢小看大海，瘋子！"

    # game/rpg/heroine_story.rpy:107
    old "크아아... 바다가 울고 있다!"
    new "哦啊啊……大海在哭泣！"

    # game/rpg/heroine_story.rpy:107
    old "파도에 휩쓸려라!"
    new "被海浪吞沒吧！"

    # game/rpg/heroine_story.rpy:107
    old "바다를 얕보지 마라."
    new "不要小看大海。"

    # game/rpg/heroine_story.rpy:107
    old "바다가... 울고 있다."
    new "大海……在哭泣。"

    # game/rpg/heroine_story.rpy:107
    old "거짓말쟁이, 다 똑같아!"
    new "騙子，你們都一個樣！"

    # game/rpg/heroine_story.rpy:107
    old "우산으로 꿰뚫어 주마!"
    new "我要用這把傘刺穿你！"

    # game/rpg/heroine_story.rpy:107
    old "비가... 그치지 않아, 젠장..."
    new "雨……停不下來，該死……"

    # game/rpg/heroine_story.rpy:107
    old "거짓말쟁이는 싫어요."
    new "我討厭說謊的人。"

    # game/rpg/heroine_story.rpy:107
    old "우산으로 찔러 드릴게요."
    new "我會用傘刺向您的。"

    # game/rpg/heroine_story.rpy:107
    old "비가... 그치지 않아요..."
    new "雨……一直停不下來……"

    # game/rpg/heroine_story.rpy:107
    old "어디서 감히 내 무대를 망쳐!"
    new "你算哪根蔥，敢毀了我的舞臺！"

    # game/rpg/heroine_story.rpy:107
    old "앙코르는 없어, 꺼져!"
    new "沒有安可，滾開！"

    # game/rpg/heroine_story.rpy:107
    old "무대가... 무너지고 있어, 젠장!"
    new "舞臺……要塌了，可惡！"

    # game/rpg/heroine_story.rpy:107
    old "제 무대를 망치지 마세요!"
    new "請不要毀了我的舞臺！"

    # game/rpg/heroine_story.rpy:107
    old "앙코르는 없어요!"
    new "沒有安可環節！"

    # game/rpg/heroine_story.rpy:107
    old "무대가... 무너지고 있어요."
    new "舞臺……正在崩塌。"

    # game/rpg/heroine_story.rpy:107
    old "전 편대, 저놈을 갈겨 버려!"
    new "全編隊，把那傢伙打下去！"

    # game/rpg/heroine_story.rpy:107
    old "하늘에서 벗어날 수 있을 것 같아?"
    new "你以為能從天空中逃出去嗎？"

    # game/rpg/heroine_story.rpy:107
    old "관제 불능이라니, 빌어먹을!"
    new "居然失去管制能力，該死！"

    # game/rpg/heroine_story.rpy:107
    old "전 편대, 사격 개시!"
    new "全編隊，開始射擊！"

    # game/rpg/heroine_story.rpy:107
    old "하늘에서 벗어날 수 없어요."
    new "您無法逃離這片天空。"

    # game/rpg/heroine_story.rpy:107
    old "관제 불능... 큰일이에요."
    new "管制失靈……這下麻煩了。"

    # game/rpg/heroine_story.rpy:107
    old "종말 앞에서 까불지 마라, 벌레 같은 놈!"
    new "在終結面前別得意忘形，你這隻蟲子！"

    # game/rpg/heroine_story.rpy:107
    old "모든 걸 부숴 주마, 전부 다!"
    new "我要把一切都摧毀，全部都要！"

    # game/rpg/heroine_story.rpy:107
    old "이럴 수는 없다... 내가 지다니, 크아악!"
    new "這不可能……我居然會輸，啊啊啊！"

    # game/rpg/heroine_story.rpy:107
    old "종말 앞에서 물러서라."
    new "在終結面前，退下吧。"

    # game/rpg/heroine_story.rpy:107
    old "모든 것을 부숴 주마."
    new "我會將一切盡數摧毀。"

    # game/rpg/heroine_story.rpy:107
    old "이럴 수는 없다... 내가 지다니."
    new "這不可能……我竟然會輸。"

    # game/rpg/heroine_story.rpy:143
    old "또 왔냐? 이번엔 왕관째로 부숴 주지."
    new "又來了？這次連王冠一起砸碎給你看。"

    # game/rpg/heroine_story.rpy:143
    old "...젠장. 왕관은 가져가. 이 도시... 부탁한다."
    new "……可惡。王冠拿去吧，這座城市……就拜託你了。"

    # game/rpg/heroine_story.rpy:143
    old "재침입이다. 이번엔 뼈까지 갈아 버리겠다."
    new "再次入侵？這次連骨頭都給你磨碎。"

    # game/rpg/heroine_story.rpy:143
    old "치직... 빌어먹을... 시민들은... 무사..하길..."
    new "滋滋……該死……願市民們……都能平安……"

    # game/rpg/heroine_story.rpy:143
    old "또 귀찮게 구는군. 이번엔 진짜 끝을 내주마."
    new "又來煩我了，這次真的要做個了斷。"

    # game/rpg/heroine_story.rpy:143
    old "이제야... 눈을 감는구나. 지독한 밤이었다..."
    new "終於……可以閉上眼了。這真是漫長難熬的一夜……"

    # game/rpg/heroine_story.rpy:143
    old "질리지도 않냐? 밤이 무서운 줄 알게 해 주지."
    new "還不膩嗎？我要讓你知道夜晚有多可怕。"

    # game/rpg/heroine_story.rpy:143
    old "야경이 이렇게 예쁜 줄은... 죽을 때야 알았네."
    new "沒想到夜景這麼美……到死才發現。"

    # game/rpg/heroine_story.rpy:143
    old "야, 또 왔어? 이번엔 진짜 머리통 날려 준다."
    new "喂，又來了？這次真要把你腦袋轟飛。"

    # game/rpg/heroine_story.rpy:143
    old "쳇... 세다. 다음엔... 내가... 이... 젠장."
    new "切……真強。下次……我會……贏……可惡。"

    # game/rpg/heroine_story.rpy:143
    old "또 방해하러 왔어? 나 지금 죽을 것 같다고!"
    new "又來搗亂？我現在真的要累死了！"

    # game/rpg/heroine_story.rpy:143
    old "퇴근... 드디어 퇴근이다. 고맙다, 이 자식아."
    new "下班……終於可以下班了。謝了，你這傢伙。"

    # game/rpg/heroine_story.rpy:143
    old "또 막히러 왔냐, 이 멍청아!"
    new "又來添堵了嗎，你這個笨蛋！"

    # game/rpg/heroine_story.rpy:143
    old "뚫렸다... 크윽. 시원하네, 정말."
    new "被打通了……唔，真是痛快啊。"

    # game/rpg/heroine_story.rpy:143
    old "쿵!!! (이번엔 진짜 밟아 버리겠다는 눈빛이다)"
    new "咚！！！（這次是真心要踩扁你的眼神）"

    # game/rpg/heroine_story.rpy:143
    old "...쿵. (왕관을 남기고 조용히 사라졌다)"
    new "……咚。（留下王冠，安靜地消失了）"

    # game/rpg/heroine_story.rpy:143
    old "또 이륙 방해야? 이번엔 진짜 화났다!"
    new "又來妨礙起飛？這次是真的生氣了！"

    # game/rpg/heroine_story.rpy:143
    old "젠장... 착륙이네. 이 도시도 나쁘진 않았어."
    new "可惡……要降落了呢。這座城市，其實也不賴。"

    # game/rpg/heroine_story.rpy:143
    old "또 귀하냐. 이번엔 서류 말고 총알로 답하지."
    new "又是您啊，這次不用檔案，直接用子彈回答。"

    # game/rpg/heroine_story.rpy:143
    old "보고서엔... 이렇게 쓰겠지. '임무 실패, 좋은 상대였다'."
    new "報告上大概會這樣寫：「任務失敗，是位值得尊敬的對手」。"

    # game/rpg/heroine_story.rpy:143
    old "또 접속이냐? 이번엔 네 시스템까지 날려 주마."
    new "又來連線了？這次連你的系統一起摧毀。"

    # game/rpg/heroine_story.rpy:143
    old "로그아웃... 젠장, 자유가 이런 거였구나."
    new "登出……可惡，原來自由是這種感覺啊。"

    # game/rpg/heroine_story.rpy:143
    old "또 바다 앞에 섰냐. 이번엔 빠져 죽을 각오해라."
    new "又站到海前面了？這次做好被淹死的覺悟吧。"

    # game/rpg/heroine_story.rpy:143
    old "바다가... 잠잠해지는군. 잘 가라, 애송이."
    new "大海……漸漸平靜下來了。走好，小子。"

    # game/rpg/heroine_story.rpy:143
    old "또 왔어? 이번엔 거짓말하면 정말 죽여 버릴 거야."
    new "又來了？這次要是敢說謊，我真的會殺了你。"

    # game/rpg/heroine_story.rpy:143
    old "비가... 그쳤네. 젠장, 고맙다."
    new "雨……停了呢。可惡，謝謝你。"

    # game/rpg/heroine_story.rpy:143
    old "또 왔어? 이번 무대는 네 장례식이야!"
    new "又來了？這次的舞臺就是你的葬禮！"

    # game/rpg/heroine_story.rpy:143
    old "무대가... 끝났네. 마지막 박수, 고마워."
    new "舞臺……結束了呢。謝謝你最後的掌聲。"

    # game/rpg/heroine_story.rpy:143
    old "또 침입이냐! 전 편대, 이번엔 한 발도 남기지 마!"
    new "又來入侵了！全編隊，這次一發子彈都不要留！"

    # game/rpg/heroine_story.rpy:143
    old "관제 종료... 하늘이... 참 조용하네."
    new "管制結束……天空……好安靜啊。"

    # game/rpg/heroine_story.rpy:143
    old "벌레가 또 기어 왔구나. 이번엔 흔적도 남기지 않겠다."
    new "蟲子又爬過來了呢，這次連痕跡都不會留下。"

    # game/rpg/heroine_story.rpy:143
    old "서울이... 계속되는 건가. 네놈의 뜻이라면... 그래."
    new "首爾……還會繼續下去嗎。既然是你的意願……那就這樣吧。"

