"""앱 아이콘/시작 이미지 생성: 데스크톱 창 아이콘 + 안드로이드 적응형 아이콘 + 안드로이드 시작 화면."""
import math
import shutil
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
GAME = ROOT / "game"
SS = 4


def hexc(h, a=255):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) + (a,)


def heart_pts(cx, cy, sz):
    pts = []
    for i in range(160):
        t = i / 160 * 2 * math.pi
        x = 16 * math.sin(t) ** 3
        y = -(13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t))
        pts.append((cx + x * sz, cy + y * sz))
    return pts


def heart(size, base="#ff7fb0", dark="#d94a86", light="#ffc4dc"):
    W = size * SS
    im = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    sz = W / 36.0
    cx, cy = W / 2, W * 0.47
    d.polygon(heart_pts(cx, cy + W * 0.02, sz * 1.02), fill=hexc(dark))
    d.polygon(heart_pts(cx, cy, sz), fill=hexc(base), outline=hexc(dark), width=int(W * 0.03))
    inner = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    ImageDraw.Draw(inner).polygon(heart_pts(cx, cy - W * 0.01, sz * 0.78), fill=hexc(light, 120))
    im.alpha_composite(inner)
    g = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    ImageDraw.Draw(g).ellipse((W * 0.2, W * 0.2, W * 0.42, W * 0.36), fill=(255, 255, 255, 170))
    im.alpha_composite(g.rotate(25, resample=Image.BICUBIC, center=(W * 0.3, W * 0.28)))
    return im.resize((size, size), Image.LANCZOS)


def gradient(size):
    im = Image.new("RGB", (size, size))
    d = ImageDraw.Draw(im)
    for y in range(size):
        t = y / (size - 1)
        d.line((0, y, size, y), fill=(int(130 + 90 * t), int(95 + 40 * t), int(205 - 30 * t)))
    return im


# 데스크톱 창 아이콘
icon = gradient(256).convert("RGBA")
icon.alpha_composite(heart(200), (28, 30))
mask = Image.new("L", (256, 256), 0)
ImageDraw.Draw(mask).rounded_rectangle((0, 0, 255, 255), 56, fill=255)
icon.putalpha(mask)
icon.save(GAME / "gui" / "window_icon.png")

# 안드로이드 적응형 아이콘(전경은 중앙 66% 안전 영역 안에)
fg = Image.new("RGBA", (432, 432), (0, 0, 0, 0))
fg.alpha_composite(heart(250), (91, 96))
fg.save(GAME / "android-icon_foreground.png")
gradient(432).save(GAME / "android-icon_background.png")

# 안드로이드 시작 화면: 가로형 presplash 재사용
shutil.copy(GAME / "presplash.png", GAME / "android-presplash.png")
print("icons ok")
