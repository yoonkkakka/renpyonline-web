# 렌파이 온라인 UI (1920x1080) - 귀여운 모바일 게임 스타일
# 스타일/헬퍼는 ui_skin.rpy, 에셋은 tools/make_ui_assets.py 로 생성(game/gui/rp).

# ── 공용 조각 ────────────────────────────────────────────────
screen chip(icon, value, col="#ffffff"):
    frame:
        background Frame("gui/rp/chip.png", 30, 30, 30, 30)
        padding (16, 6, 26, 6)
        hbox:
            spacing 8
            yalign 0.5
            add icon zoom 0.85 yalign 0.5
            text value style "rp_text" size 30 color col yalign 0.5

screen topbar():
    $ p = G.player
    frame:
        style "rp_panel"
        xfill True
        ysize 108
        padding (34, 8, 34, 8)
        hbox:
            spacing 26
            yalign 0.5
            fixed:
                xysize (92, 92)
                yalign 0.5
                add "gui/rp/lv_badge.png" align (0.5, 0.5)
                vbox:
                    align (0.5, 0.5)
                    spacing -8
                    text "Lv" style "rp_text" size 18 xalign 0.5
                    text str(p["level"]) style "rp_text" size 32 xalign 0.5
            vbox:
                yalign 0.5
                spacing 2
                if p["level"] >= G.meta["max_level"]:
                    text ("%s   MAX LEVEL" % p["username"]) style "rp_text" size 26 color "#fff1a8"
                    bar value StaticValue(1, 1) xsize 400 ysize 18 left_bar pill("#ffe066") right_bar pill("track") thumb None
                else:
                    text ("%s   EXP %s / %s" % (p["username"], fmt(p["exp"]), fmt(p["exp_next"]))) style "rp_text" size 24
                    bar value StaticValue(p["exp"], p["exp_next"]) xsize 400 ysize 18 left_bar pill("#ffe066") right_bar pill("track") thumb None
            null width 10
            use chip("gui/rp/icon_coin.png", fmt(p["gold"]), "#ffe27a")
            use chip("gui/rp/icon_gem.png", fmt(p["stones"]), "#e3d0ff")
            if p["awake_unlocked"] or p["crystals"]:
                use chip("gui/rp/icon_crystal.png", str(p["crystals"]), "#ffc0ea")

screen back_button(label=None):
    if label is None:
        $ label = _("돌아가기")
    button:
        style "rp_btn_pink"
        xalign 0.0
        yalign 1.0
        xoffset 30
        yoffset -22
        xsize 270
        action Return("back")
        hbox:
            spacing 6
            xalign 0.5
            add "gui/rp/icon_back.png" zoom 0.55 yalign 0.5
            text label style "rp_button_text" size 32 yalign 0.5

screen connecting(msg=None, sub=None):
    if msg is None:
        $ msg = _("서버에 연결하는 중")
    if sub is None:
        $ sub = _("처음 접속하면 서버가 깨어나느라 최대 1분쯤 걸려요")
    zorder 100

    add "images/bg/t01.webp"
    add Solid("#5a3aa8b8")
    add "gui/rp/sparkle.png" pos (330, 210) zoom 1.3 at rp_bounce
    add "gui/rp/sparkle.png" pos (1500, 330) zoom 1.0 at rp_bounce
    add "gui/rp/sparkle.png" pos (1300, 800) zoom 1.5 at rp_bounce
    add "gui/rp/sparkle.png" pos (520, 760) zoom 0.9 at rp_bounce
    # 통통 튀는 하트 3개(시차를 두고 콩콩)
    hbox:
        align (0.5, 0.42)
        spacing 26
        add "gui/rp/heart_pink.png" at heart_jump(0.0)
        add "gui/rp/heart_yellow.png" at heart_jump(0.18)
        add "gui/rp/heart_mint.png" at heart_jump(0.36)
    $ dots = "." * (int(time.time() * 2.5) % 4)
    text (msg + dots) style "rp_text" size 54 xalign 0.5 ypos 700 text_align 0.5 outlines [(8, "#6a3aa8", 0, 3)]
    text sub style "rp_text" size 26 xalign 0.5 ypos 790 color "#ffe1f3"

# ── 로그인 ───────────────────────────────────────────────────
screen login_screen():
    default u = login_prefill if login_prefill is not None else ((persistent.last_user or "") if persistent.save_id else "")
    default p = ""
    default focus_id = (u == "")
    default uval = ScreenVariableInputValue("u", default=focus_id)
    default pval = ScreenVariableInputValue("p", default=(not focus_id))
    add "images/bg/t01.webp"
    add Solid("#4a3a9a66")
    add "gui/rp/sparkle.png" pos (330, 170) zoom 1.4 at rp_bounce
    add "gui/rp/sparkle.png" pos (1520, 260) zoom 1.0 at rp_bounce
    add "gui/rp/deco_heart.png" pos (1450, 700) zoom 1.6 at rp_bounce
    add "gui/rp/deco_heart.png" pos (380, 760) zoom 1.1 at rp_bounce
    text _("렌파이 온라인") style "rp_text" size 104 color "#fff3a8" xalign 0.5 ypos 60 outlines [(10, "#6a3aa8", 0, 4)]
    frame:
        style "rp_panel"
        xalign 0.5
        ypos 250
        xsize 780
        padding (54, 40)
        vbox:
            spacing 16
            xfill True
            text _("신체를 단련해 서울의 필드 보스를 쓰러뜨려요!") style "rp_text" size 28 xalign 0.5 color "#ffe1f3"
            null height 6
            text _("아이디") style "rp_text" size 26 color "#ffd6ec"
            button:
                style "rp_inputbox"
                action uval.Enable()
                input id "login_id" value uval length 16 style "rp_input" size 34
            text _("비밀번호") style "rp_text" size 26 color "#ffd6ec"
            button:
                style "rp_inputbox"
                action pval.Enable()
                input id "login_pw" value pval length 24 mask "*" style "rp_input" size 34
            textbutton (_("아이디 저장: 켜짐") if persistent.save_id else _("아이디 저장: 꺼짐")):
                style ("rp_btn_mint" if persistent.save_id else "rp_button")
                xalign 0.0
                text_size 26
                action ToggleField(persistent, "save_id")
            hbox:
                spacing 22
                xalign 0.5
                textbutton _("로그인") style "rp_button" xsize 320 text_size 38 action Return((u, p, False))
                textbutton _("회원가입") style "rp_btn_pink" xsize 320 text_size 38 action OpenURL(SIGNUP_URL)
            text _("회원가입은 공식 홈페이지에서 해 주세요!") style "rp_text" size 22 xalign 0.5 color "#ffe1f3"

# ── 마을(허브) ───────────────────────────────────────────────
screen hub_tile(tile, icon, label, ret, badge=False):
    button:
        xysize (350, 190)
        background Frame("gui/rp/tile_%s.png" % tile, 44, 44, 44, 54)
        hover_background Frame("gui/rp/tile_%s_hover.png" % tile, 44, 44, 44, 54)
        action Return(ret)
        vbox:
            align (0.5, 0.38)
            spacing 0
            add icon xalign 0.5 zoom 0.62
            text label style "rp_text" size 34 xalign 0.5
        if badge:
            add "gui/rp/badge_red.png" align (0.95, 0.06)
            text "!" style "rp_text" size 26 align (0.95, 0.05) xoffset -8 yoffset 2

screen hub():
    add "images/bg/t08.webp"
    add Solid("#4a3a9a44")
    use topbar
    frame:
        style "rp_panel"
        xpos 40
        ypos 132
        xsize 660
        ysize 880
        add avatar_disp(560, 800) align (0.5, 0.4)
        text (G.player["pvp"]["tier"] + "  " + str(G.player["pvp"]["rating"])) style "rp_text" size 30 color "#fff1a8" align (0.5, 1.0)
    text _("서울 마을") style "rp_text" size 64 color "#fff3a8" xpos 740 ypos 128 outlines [(8, "#6a3aa8", 0, 3)]
    if G.player["boost_left"] > 0:
        frame:
            background Frame("gui/rp/chip.png", 30, 30, 30, 30)
            padding (22, 6, 26, 8)
            xpos 1240
            ypos 148
            text (_("경험치 부스트 ON  %s") % fmt_time(G.player["boost_left"])) style "rp_text" size 26 color "#b6ffca"
    vbox:
        xpos 740
        ypos 240
        spacing 20
        hbox:
            spacing 26
            use hub_tile("pink", "gui/rp/ic_char.png", _("캐릭터 / 강화"), "char")
            use hub_tile("orange", "gui/rp/ic_boss.png", _("필드 보스"), "boss")
            use hub_tile("mint", "gui/rp/ic_hunt.png", _("자동 사냥"), "hunt")
        hbox:
            spacing 26
            use hub_tile("blue", "gui/rp/ic_pvp.png", _("PVP 아레나"), "pvp")
            use hub_tile("purple", "gui/rp/ic_mission.png", _("미션 / 출석"), "missions", badge=(G.player["daily_claimable"] > 0 or G.player["checkin_ready"]))
            use hub_tile("yellow", "gui/rp/ic_rank.png", _("랭킹"), "ranking")
        hbox:
            spacing 26
            use hub_tile("pink", "gui/rp/ic_love.png", _("히로인"), "heroine")
            use hub_tile("orange", "gui/rp/ic_auction.png", _("경매장"), "auction")
            use hub_tile("mint", "gui/rp/ic_bag.png", _("가방 / 상점"), "bag")
        hbox:
            spacing 20
            textbutton _("로그아웃") style "rp_button" xsize 250 text_size 28 action Return("logout")
            if G.meta["dev"]:
                textbutton _("[[DEV] 만렙") style "rp_btn_orange" xsize 220 text_size 24 action Function(dev_level, 200)
                textbutton "[[DEV] +10" style "rp_btn_orange" xsize 200 text_size 24 action Function(dev_level, min(200, G.player["level"] + 10))
                textbutton "[[DEV] Lv1" style "rp_btn_orange" xsize 180 text_size 24 action Function(dev_level, 1)

# ── 캐릭터 / 신체 강화 ───────────────────────────────────────
screen character_screen():
    default tab = "body"
    $ p = G.player
    $ st = p["stats"]
    add "images/bg/t08.webp"
    add Solid("#2a1d5ab0")
    use topbar
    frame:
        style "rp_panel"
        xpos 40
        ypos 128
        xsize 620
        ysize 790
        vbox:
            spacing 10
            xalign 0.5
            add avatar_disp(540, 640) xalign 0.5
            textbutton _("전신 일러스트 업로드"):
                style "rp_btn_mint"
                xsize 540
                text_size 30
                action Function(upload_avatar)
            text _("이미지는 Storage가 아닌 DB에 코드로 저장돼요") style "rp_text" size 18 color "#d9cffb" xalign 0.5

    frame:
        style "rp_panel"
        xpos 680
        ypos 128
        xsize 720
        ysize 900
        padding (26, 20)
        vbox:
            spacing 10
            hbox:
                spacing 14
                textbutton _("신체 강화") style "rp_button" xsize 210 text_size 30 selected (tab == "body") action SetScreenVariable("tab", "body")
                textbutton (_("각성") if p["awake_unlocked"] else _("각성 (잠김)")) style "rp_button" xsize 210 text_size 30 selected (tab == "awake") action SetScreenVariable("tab", "awake")
            if tab == "body":
                text (_("현재 한도: %d단계 (레벨 4당 1단계)") % p["body_cap"]) style "rp_text" size 22 color "#d9cffb"
                for part in G.meta["body_parts"]:
                    $ lvl = p["body"][part["id"]]
                    $ g, s = body_cost(lvl)
                    $ can = lvl < p["body_cap"] and p["gold"] >= g and p["stones"] >= s
                    frame:
                        background Frame("gui/rp/card.png", 30, 30, 30, 30)
                        xfill True
                        padding (18, 8)
                        hbox:
                            spacing 12
                            vbox:
                                xsize 400
                                yalign 0.5
                                text (_("%s  %d단계") % (part["name"], lvl)) style "rp_text" size 30 color "#ffe9a8"
                                text part["desc"] style "rp_text" size 20 color "#dcd4ff"
                            vbox:
                                xsize 230
                                yalign 0.5
                                if lvl >= p["body_cap"]:
                                    textbutton _("한도 도달") style "rp_button" xfill True text_size 24 sensitive False action NullAction()
                                else:
                                    textbutton (_("강화 %s G + %d석") % (fmt(g), s)) style "rp_btn_mint" xfill True text_size 22 sensitive can action Function(upgrade_part, part["id"])
                text _("강화할 때마다 12% 확률로 대성공(2단계 상승)!") style "rp_text" size 22 color "#ffd27a"
            else:
                if not p["awake_unlocked"]:
                    $ done = len([1 for k in p["body"] if p["body"][k] >= 50])
                    text _("각성 잠김") style "rp_text" size 44 color "#ffb0c8"
                    text (_("신체 6부위를 모두 50단계로 만들면 열려요.\n현재 %d / 6 부위 완료") % done) style "rp_text" size 28
                    text _("각성하면 부위마다 +3단계 상당의 능력치를 얻고,\n치명타/쿨타임/회피 상한도 늘어나요.") style "rp_text" size 22 color "#dcd4ff"
                else:
                    text (_("각성 결정  %d") % p["crystals"]) style "rp_text" size 32 color "#ffc0ea"
                    text _("10번~ 보스, PVP 승리, 전설 상자, 일일 올클리어로 얻어요.") style "rp_text" size 20 color "#dcd4ff"
                    for part in G.meta["body_parts"]:
                        $ a = p["awake"][part["id"]]
                        frame:
                            background Frame("gui/rp/card_purple.png", 30, 30, 30, 30)
                            xfill True
                            padding (18, 8)
                            hbox:
                                spacing 12
                                vbox:
                                    xsize 400
                                    yalign 0.5
                                    text (_("%s  각성 %d / %d") % (part["name"], a, G.meta["awake"]["max"])) style "rp_text" size 30 color "#ffe9a8"
                                    text (_("신체 +%d단계 상당") % (a * G.meta["awake"]["eq"])) style "rp_text" size 20 color "#f0dcff"
                                vbox:
                                    xsize 230
                                    yalign 0.5
                                    if a >= G.meta["awake"]["max"]:
                                        textbutton _("최대 각성") style "rp_button" xfill True text_size 24 sensitive False action NullAction()
                                    else:
                                        $ ag, ac = awake_cost(a)
                                        textbutton (_("각성 %s G + 결정 %d") % (fmt(ag), ac)) style "rp_btn_pink" xfill True text_size 20 sensitive (p["gold"] >= ag and p["crystals"] >= ac) action Function(upgrade_awake, part["id"])

    frame:
        style "rp_panel"
        xpos 1420
        ypos 128
        xsize 460
        ysize 900
        padding (28, 20)
        vbox:
            spacing 4
            text _("능력치") style "rp_text" size 40 color "#fff1a8"
            text (_("체력  %s") % fmt(st["hp"])) style "rp_text" size 28
            text (_("공격력  %s") % fmt(st["atk"])) style "rp_text" size 28
            text (_("방어력  %s") % fmt(st["def"])) style "rp_text" size 28
            text (_("기력  %s (+%.1f/초)") % (fmt(st["mana"]), st["mana_regen"])) style "rp_text" size 28
            text (_("치명타  %.1f%%") % (st["crit"] * 100)) style "rp_text" size 28
            text (_("쿨타임 감소  %.1f%%") % (st["cd_reduce"] * 100)) style "rp_text" size 28
            text (_("회피  %.1f%%") % (st["dodge"] * 100)) style "rp_text" size 28
            text (_("자연 회복  %.2f%%/초") % (st.get("hp_regen", 0) * 100)) style "rp_text" size 28
            null height 10
            text _("스킬") style "rp_text" size 40 color "#fff1a8"
            for sk in skill_list():
                $ ok = p["level"] >= sk["level"]
                text ("%d. %s  %s" % (sk["slot"], sk["name"], "" if ok else "(Lv.%d)" % sk["level"])) style "rp_text" size 22 color ("#ffffff" if ok else "#9a92c4")
            text _("Space. 방어 자세") style "rp_text" size 22

    use back_button

# ── 필드 보스 선택 ───────────────────────────────────────────
screen boss_select():
    $ p = G.player
    add "images/bg/t08.webp"
    add Solid("#2a1d5ab0")
    use topbar
    viewport:
        xpos 40
        ypos 128
        xsize 1850
        ysize 800
        mousewheel True
        scrollbars "vertical"
        draggable True
        vpgrid:
            cols 4
            spacing 20
            for b in G.meta["bosses"]:
                $ locked = p["level"] < b["min_level"]
                $ cl = p["clears"].get(str(b["id"]), 0)
                button:
                    background None
                    xysize (440, 260)
                    action (NullAction() if locked else Return(b["id"]))
                    add round_clip("images/bg/t%02d.webp" % b["bg"], 440, 260)
                    add "images/boss/s%02d.png" % b["sprite"] fit "contain" xysize (250, 230) xalign 0.97 yalign 1.0 matrixcolor (BrightnessMatrix(-0.6) if locked else IdentityMatrix())
                    if locked:
                        add round_shade(440, 260, "#2a1d5acc")
                    add border_img(440, 260, "gray" if locked else "pink")
                    vbox:
                        xpos 18
                        ypos 12
                        spacing 0
                        text ("%d. %s" % (b["id"], b["name"])) style "rp_text" size 30 color "#fff1a8"
                        text (_("권장 Lv.%d") % b["min_level"]) style "rp_text" size 24 color ("#ffb0b0" if locked else "#b6ffca")
                    vbox:
                        xpos 18
                        yalign 0.95
                        spacing 0
                        text (_("처치 %d회") % cl) style "rp_text" size 22
                        text ("EXP %s / %sG" % (fmt(b["rewards"]["exp"]), fmt(b["rewards"]["gold"]))) style "rp_text" size 20 color "#f0e8ff"
                    if locked:
                        text "LOCK" style "rp_text" size 50 align (0.5, 0.42) color "#ffd6ec"
    use back_button

# ── 자동 사냥 센터 ───────────────────────────────────────────
screen hunt_screen():
    $ p = G.player
    $ h = G.hunt
    timer 10.0 repeat True action Function(refresh_hunt)
    add "images/bg/hunt_center.webp"
    use topbar
    frame:
        style "rp_panel"
        xpos 40
        ypos 128
        xsize 600
        ysize 800
        padding (26, 20)
        vbox:
            spacing 10
            text _("사냥 지역 선택") style "rp_text" size 38 color "#fff1a8"
            viewport:
                ysize 680
                mousewheel True
                draggable True
                scrollbars "vertical"
                vbox:
                    spacing 10
                    for z in G.meta["zones"]:
                        $ locked = p["level"] < z["min_level"]
                        $ cur = h is not None and h["zone"] == z["id"]
                        textbutton ("%s   %s" % (z["name"], _("(사냥 중)") if cur else ("Lv.%d" % z["min_level"]))):
                            style "rp_card_btn"
                            xfill True
                            text_size 27
                            text_xalign 0.0
                            selected cur
                            sensitive (not locked and h is None)
                            action Function(hunt_start, z["id"])
    frame:
        style "rp_panel"
        xpos 1290
        ypos 128
        xsize 590
        ysize 800
        padding (28, 22)
        vbox:
            spacing 14
            text _("자동 사냥 현황") style "rp_text" size 38 color "#fff1a8"
            if h is None:
                text _("진행 중인 사냥이 없어요.\n왼쪽에서 지역을 고르면\n최대 8시간까지 자동으로 진행돼요.") style "rp_text" size 26
            else:
                $ zname = [z["name"] for z in G.meta["zones"] if z["id"] == h["zone"]][0]
                text zname style "rp_text" size 32 color "#ffe9a8"
                text (_("사냥 시간  %d시간 %d분%s") % (int(h["minutes"]) // 60, int(h["minutes"]) % 60, _("  (최대)") if h["full"] else "")) style "rp_text" size 26
                text (_("경험치 획득  %s") % fmt(h["exp"])) style "rp_text" size 26
                text (_("골드 획득  %s") % fmt(h["gold"])) style "rp_text" size 26
                text (_("강화석 획득  %s") % fmt(h["stones"])) style "rp_text" size 26
                textbutton _("수령하기") style "rp_btn_mint" xfill True text_size 36 action Function(hunt_claim)
            null height 10
            if G.hunt_boost > 0:
                text (_("경험치 부스트 ON  (%s)") % fmt_time(G.hunt_boost)) style "rp_text" size 26 color "#b6ffca"
            else:
                text _("경험치 부스트 OFF\n(필드 보스를 처치하면 30분간 +50%)") style "rp_text" size 22 color "#dcd4ff"
            textbutton _("새로고침") style "rp_button" xfill True text_size 26 action Function(refresh_hunt)
    use back_button

# ── 전투 ─────────────────────────────────────────────────────
screen skill_slot(sk, bt):
    $ locked = bt.level < sk["level"]
    $ left = bt.cd_left(sk["slot"])
    $ poor = bt.mana < sk["mana"]
    $ frac = 0.0 if sk["cd"] <= 0 else min(1.0, left / max(0.2, sk["cd"] * (1.0 - bt.st["cd_reduce"])))
    $ hh = max(1, int(128 * frac))
    button:
        background slot_bg(sk["slot"], locked)
        xysize (128, 136)
        padding (0, 0)
        action Function(bt_skill if bt is B else pb_skill, sk["slot"])
        text str(sk["slot"]) style "rp_text" size 28 color "#fff1a8" xpos 10 ypos 4
        if left <= 0:
            text sk["name"] style "rp_text" size 22 align (0.5, 0.45) text_align 0.5 xmaximum 120 color ("#c9c3e6" if locked else ("#d8d0f0" if poor else "#ffffff"))
        if not locked and sk["mana"]:
            text (_("기력 %d") % sk["mana"]) style "rp_text" size 18 xalign 0.5 ypos 92 color ("#ffc0c0" if poor else "#e6f0ff")
        if locked:
            text ("Lv.%d" % sk["level"]) style "rp_text" size 24 xalign 0.5 ypos 90 color "#ffd0d0"
        elif left > 0:
            add "gui/rp/slot_cd.png" crop (0, 128 - hh, 128, hh) ypos (128 - hh)
            text ("%.1f" % left) style "rp_text" size 34 align (0.5, 0.45)

screen guard_slot(bt):
    button:
        background "gui/rp/slot_blue.png"
        xysize (128, 136)
        padding (0, 0)
        action Function(bt_guard if bt is B else pb_guard)
        text "Space" style "rp_text" size 22 color "#fff1a8" xpos 8 ypos 6
        if bt.guard_left() <= 0:
            text _("방어\n자세") style "rp_text" size 26 align (0.5, 0.5) text_align 0.5
        if bt.guard_left() > 0:
            $ gh = max(1, int(128 * min(1.0, bt.guard_left() / bt.guard["cd"])))
            add "gui/rp/slot_cd.png" crop (0, 128 - gh, 128, gh) ypos (128 - gh)
            text ("%.1f" % bt.guard_left()) style "rp_text" size 34 align (0.5, 0.45)

screen battle_screen():
    $ now = time.time()
    $ bt = B
    $ boss = bt.boss
    timer 0.05 repeat True action Function(bt_tick)
    key "K_1" action Function(bt_skill, 1)
    key "K_2" action Function(bt_skill, 2)
    key "K_3" action Function(bt_skill, 3)
    key "K_4" action Function(bt_skill, 4)
    key "K_5" action Function(bt_skill, 5)
    key "K_6" action Function(bt_skill, 6)
    key "K_7" action Function(bt_skill, 7)
    key "K_8" action Function(bt_skill, 8)
    key "K_KP1" action Function(bt_skill, 1)
    key "K_KP2" action Function(bt_skill, 2)
    key "K_KP3" action Function(bt_skill, 3)
    key "K_KP4" action Function(bt_skill, 4)
    key "K_KP5" action Function(bt_skill, 5)
    key "K_KP6" action Function(bt_skill, 6)
    key "K_KP7" action Function(bt_skill, 7)
    key "K_KP8" action Function(bt_skill, 8)
    key "K_SPACE" action Function(bt_guard)
    key "game_menu" action Function(bt_flee)

    add bt.bg_path
    if boss["id"] == 16:
        add Solid("#60001030")
    # 보스
    add bt.sprite_path:
        fit "contain"
        xysize (860, 700)
        align (0.86, 0.60)
        xoffset (random.randint(-10, 10) if (persistent.opt_shake and now < bt.boss_hit_until) else 0)
        alpha (0.65 if now < bt.boss_hit_until else 1.0)
    # 플레이어
    add avatar_disp(520, 720):
        pos (70, 190)
        xoffset (random.randint(-8, 8) if (persistent.opt_shake and now < bt.player_hit_until) else 0)
        alpha (0.7 if bt.guarding() else 1.0)
    if bt.guarding():
        add Solid("#8fd0ff40") xysize (520, 720) pos (70, 190)
    if now < bt.player_hit_until:
        add Solid("#ff5a8a30")

    # 유혈 이펙트(설정에서 끌 수 있음)
    if persistent.opt_blood:
        for st in bt.stains:
            add "gui/rp/blood_%d.png" % st["img"] at blood_fx(st["z"], st["rot"], 0.42) pos (st["x"], st["y"])
        for bl in bt.blood:
            $ bage = now - bl["t"]
            if bage < bl["life"]:
                add "gui/rp/blood_%d.png" % bl["img"] at blood_fx(bl["z"] * (0.55 + min(bage, 0.3) * 1.6), bl["rot"], max(0.0, 1.0 - bage / bl["life"])) pos (bl["x"], bl["y"])
        if now < bt.player_hit_until:
            add "gui/rp/blood_vignette.png"
        elif bt.hp < bt.hp_max * 0.3:
            add "gui/rp/blood_vignette.png" alpha (0.55 + 0.3 * math.sin(now * 6))
    if bt.shout and now < bt.shout_until:
        frame:
            style "rp_panel"
            xalign 0.78
            ypos 250
            padding (26, 14)
            text bt.shout style "rp_text" size 34 color "#ffb0b0" outlines [(6, "#4a0a1a", 0, 2)]

    # 보스 체력 / 예고
    frame:
        style "rp_panel"
        xalign 0.5
        ypos 20
        xsize 1240
        padding (30, 14)
        vbox:
            spacing 4
            hbox:
                xfill True
                text ("Lv.%d  %s" % (boss["level"], boss["name"])) style "rp_text" size 36 color "#fff1a8"
                text ("%s / %s" % (fmt(bt.boss_hp), fmt(bt.boss_max))) style "rp_text" size 28 xalign 1.0
            bar value StaticValue(bt.boss_hp, bt.boss_max) xsize 1180 ysize 28 left_bar pill("#e0475b") right_bar pill("track") thumb None
            hbox:
                spacing 16
                if bt.next_is_heavy():
                    text _("!! 강공격 준비 !!") style "rp_text" size 24 color "#ffb0b0"
                else:
                    text (_("다음 공격: %s") % boss["attack"]) style "rp_text" size 24 color "#f0e8ff"
                bar value StaticValue(bt.charge(), 1.0) xsize 700 ysize 16 yalign 0.5 left_bar pill("#ff3030" if bt.next_is_heavy() else "#ffb84d") right_bar pill("track") thumb None
    hbox:
        xalign 1.0
        xoffset -30
        ypos 20
        use chip("gui/rp/icon_gem.png", fmt_time(bt.time_left()), "#ffffff")
    text (_("접근: %s") % bt.approach["name"]) style "rp_text" size 24 color "#f0e8ff" xalign 1.0 xoffset -34 ypos 98
    if bt.combo >= 2:
        text ("COMBO x%d   +%d%%" % (bt.combo, int(G.meta["combo"]["step"] * 100 * bt.combo))) style "rp_text" size 56 color "#fff1a8" xalign 0.5 ypos 196 outlines [(8, "#c2437a", 0, 3)]
    textbutton _("도망 (Esc)"):
        style "rp_btn_pink"
        xpos 30
        ypos 24
        text_size 24
        action Function(bt_flee)

    # 플레이어 상태
    frame:
        style "rp_panel"
        xpos 24
        yalign 1.0
        yoffset -20
        xsize 440
        padding (26, 16)
        vbox:
            spacing 4
            text (_("체력 %s / %s") % (fmt(bt.hp), fmt(bt.hp_max))) style "rp_text" size 26
            bar value StaticValue(bt.hp, bt.hp_max) xsize 386 ysize 24 left_bar pill("#47d16b") right_bar pill("track") thumb None
            text (_("기력 %d / %d") % (bt.mana, bt.st["mana"])) style "rp_text" size 24 color "#d4e4ff"
            bar value StaticValue(bt.mana, bt.st["mana"]) xsize 386 ysize 18 left_bar pill("#4d8dff") right_bar pill("track") thumb None
    # 스킬 바
    hbox:
        xpos 490
        yalign 1.0
        yoffset -20
        spacing 10
        for sk in G.meta["skills"]:
            use skill_slot(sk, bt)
        use guard_slot(bt)
    # 전투 로그
    vbox:
        xalign 1.0
        xoffset -30
        yalign 1.0
        yoffset -170
        spacing 2
        for (t, c) in (bt.log if persistent.opt_log else []):
            text t style "rp_text" size 22 color c xalign 1.0
    # 떠오르는 숫자
    for f in (bt.floaters if persistent.opt_floaters else []):
        $ age = now - f["t"]
        $ ft = f["text"]
        text ft at rp_fade(max(0.0, 1.0 - max(0.0, age - 0.5) * 2.0)):
            style "rp_text"
            size f["size"]
            color f["color"]
            bold True
            outlines [(6, "#3a2a6a", 0, 2)]
            xpos f["x"]
            ypos int(f["y"] - age * 110)

screen battle_result(outcome, fin):
    modal True
    add B.bg_path
    add Solid("#2a1d5acc")
    frame:
        style "rp_panel"
        align (0.5, 0.5)
        xsize 800
        padding (54, 40)
        vbox:
            spacing 14
            xfill True
            if outcome == "win" and fin:
                $ rw = fin["rewards"]
                text _("승리!") style "rp_text" size 96 xalign 0.5 color "#fff3a8" outlines [(10, "#c2437a", 0, 4)]
                text (_("경험치 +%s") % fmt(rw["exp"])) style "rp_text" size 36 xalign 0.5
                hbox:
                    xalign 0.5
                    spacing 10
                    add "gui/rp/icon_coin.png" yalign 0.5
                    text (_("골드 +%s") % fmt(rw["gold"])) style "rp_text" size 36 color "#ffe27a"
                hbox:
                    xalign 0.5
                    spacing 10
                    add "gui/rp/icon_gem.png" yalign 0.5
                    text (_("강화석 +%d") % rw["stones"]) style "rp_text" size 36 color "#e3d0ff"
                if rw.get("crystals"):
                    hbox:
                        xalign 0.5
                        spacing 10
                        add "gui/rp/icon_crystal.png" yalign 0.5
                        text (_("각성 결정 +%d") % rw["crystals"]) style "rp_text" size 36 color "#ffc0ea"
                if fin["level_ups"]:
                    text (_("레벨 UP!  Lv.%d") % fin["player"]["level"]) style "rp_text" size 46 xalign 0.5 color "#b6ffca"
                if fin.get("loot"):
                    $ lt = fin["loot"]
                    text (_("전리품 상자  %s") % lt["rarity"]) style "rp_text" size 42 xalign 0.5 color rarity_color(lt["rarity"])
                    if lt["gold"] or lt["stones"]:
                        text (_("보너스 골드 +%s%s") % (fmt(lt["gold"]), (_("   강화석 +%d") % lt["stones"]) if lt["stones"] else "")) style "rp_text" size 28 xalign 0.5 color rarity_color(lt["rarity"])
                    if lt["boost_seconds"]:
                        text _("전설 보너스: 경험치 부스트 +1시간!") style "rp_text" size 26 xalign 0.5 color "#ffd27a"
                text _("경험치 부스트 30분 획득 (+50%)") style "rp_text" size 24 xalign 0.5 color "#b6ffca"
            elif outcome == "win":
                text _("승리했지만 서버 검증에 실패했어요.") style "rp_text" size 34 xalign 0.5 color "#ffb0b0"
            elif outcome == "flee":
                text _("전투에서 물러났어요") style "rp_text" size 56 xalign 0.5
            else:
                text _("패배...") style "rp_text" size 90 xalign 0.5 color "#ffb0c8"
                text _("신체를 더 강화하고 다시 도전해요!") style "rp_text" size 28 xalign 0.5
            textbutton _("확인") style "rp_btn_mint" xfill True text_size 38 action Return(True)

# ── 이용 등급 안내(게임을 켤 때 로그인 창 전에 표시) ────────────────
screen rating_notice():
    zorder 150
    modal True
    timer 5.0 action Return(True)
    add Solid("#241a52")
    add "gui/rp/sparkle.png" pos (260, 150) zoom 1.2 at rp_bounce
    add "gui/rp/sparkle.png" pos (1620, 820) zoom 1.0 at rp_bounce
    text _("이용 등급 안내") style "rp_text" size 56 color "#fff3a8" xalign 0.5 ypos 70 outlines [(8, "#6a3aa8", 0, 3)]
    hbox:
        align (0.5, 0.42)
        spacing 44
        add "gui/rating/age15.png" yalign 0.5 zoom 0.55
        frame:
            background Frame("gui/rp/panel.png", 40, 40, 40, 40)
            padding (40, 34)
            vbox:
                spacing 22
                text _("15세 이용가") style "rp_text" size 40 color "#ffd9a0"
                hbox:
                    spacing 26
                    add "gui/rating/language.png" zoom 0.36
                text _("언어의 부적절성") style "rp_text" size 26 xalign 0.5 color "#f0e8ff"
    text _("이 게임에는 거친 언어가 포함되어 있어요.\n※ 원스토어 등급분류 결과에 따른 표기입니다.") style "rp_text" size 26 xalign 0.5 ypos 800 text_align 0.5 color "#dcd4ff"
    text _("화면을 누르면 넘어가요") style "rp_text" size 22 xalign 0.5 ypos 940 color "#b9b1d8"
    button:
        xfill True
        yfill True
        background None
        action Return(True)
