"""SupabaseRepo 를 `extra` 컬럼 유무와 무관하게 동작하도록 패치 (일회성).

컬럼이 없으면 `clears`(jsonb) 안의 예약 키 "__extra" 에 저장하고, 컬럼이 생기면 자동으로 컬럼을 쓴다.
"""
from pathlib import Path

p = Path(__file__).resolve().parent.parent / "server" / "store.py"
s = p.read_text(encoding="utf-8")
a = s.index("class SupabaseRepo:")
b = s.index("def make_repo")
new = '''class SupabaseRepo:
    TABLE = "players"
    LEGACY_KEY = "__extra"   # extra 컬럼이 없을 때 clears(jsonb) 안에 저장하는 예약 키

    def __init__(self, url: str, key: str) -> None:
        from supabase import create_client
        self.db = create_client(url, key)
        try:
            self._t().select("extra").limit(1).execute()
            self.has_extra = True
        except Exception:
            self.has_extra = False
        print(f"[store] players.extra 컬럼: {'사용' if self.has_extra else '없음 -> clears 에 저장(호환 모드)'}")

    def _t(self):
        return self.db.table(self.TABLE)

    def _wrap(self, row):
        """DB 행 -> 서버가 쓰는 행. 호환 모드의 예약 키를 extra 로 꺼내고 clears 를 깨끗하게 만든다."""
        if not row:
            return row
        clears = dict(row.get("clears") or {})
        legacy = clears.pop(self.LEGACY_KEY, None)
        row["clears"] = clears
        if not row.get("extra"):
            row["extra"] = legacy or {}
        return row

    def _cols(self, cols: str) -> str:
        return cols if self.has_extra else cols.replace("extra", "clears") if "extra" in cols else cols

    def _pack(self, pid, fields: dict) -> dict:
        """서버 필드 -> DB 필드. 호환 모드면 extra 를 clears 로 밀어 넣는다."""
        fields = dict(fields)
        if self.has_extra or "extra" not in fields:
            return fields
        extra = fields.pop("extra")
        if "clears" in fields:
            clears = dict(fields["clears"] or {})
        else:
            cur = self._t().select("clears").eq("id", pid).limit(1).execute().data
            clears = dict((cur[0].get("clears") if cur else None) or {})
        clears.pop(self.LEGACY_KEY, None)
        clears[self.LEGACY_KEY] = extra
        fields["clears"] = clears
        return fields

    def get_by_username(self, username: str):
        res = self._t().select("*").eq("username", username).limit(1).execute()
        return self._wrap(res.data[0]) if res.data else None

    def get_by_id(self, pid: str):
        res = self._t().select("*").eq("id", pid).limit(1).execute()
        return self._wrap(res.data[0]) if res.data else None

    def list_all(self):
        # 아바타(큰 data URL)는 제외하고 랭킹/PVP 후보에 필요한 컬럼만 가져온다.
        cols = "id,username,level,exp,body,clears" + (",extra" if self.has_extra else "")
        return [self._wrap(r) for r in self._t().select(cols).limit(1000).execute().data]

    def create(self, row: dict) -> dict:
        row = self._pack(None, row) if not self.has_extra else dict(row)
        return self._wrap(self._t().insert(row).execute().data[0])

    def update(self, pid: str, fields: dict) -> dict:
        return self._wrap(self._t().update(self._pack(pid, fields)).eq("id", pid).execute().data[0])


'''
s = s[:a] + new + s[b:]
p.write_text(s, encoding="utf-8")
print("patched")
