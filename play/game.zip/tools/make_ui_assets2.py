"""로딩/설정용 추가 에셋: 통통한 하트, 슬라이더 손잡이, 톱니바퀴 아이콘, 시작 화면(presplash)."""
import math
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "game" / "gui" / "rp"
SS = 4


def hexc(h, a=255):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) + (a,)


def heart_pts(cx, cy, sz):
    pts = []
    for i in range(160):
        t = i / 160 * 2 * math.pi
        x = 16 * math.sin(t) ** 3
        y = -(13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t))
        pts.append((cx + x * sz, cy + y * sz))
    return pts


def big_heart(size, base, dark, light):
    """광택이 있는 통통한 하트."""
    W = size * SS
    im = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    sz = W / 36.0
    cx, cy = W / 2, W * 0.47
    d.polygon(heart_pts(cx, cy + W * 0.02, sz * 1.02), fill=hexc(dark))          # 아래 그림자
    d.polygon(heart_pts(cx, cy, sz), fill=hexc(base), outline=hexc(dark), width=int(W * 0.03))
    inner = Image.new("RGBA", (W, W), (0, 0, 0, 0))                               # 안쪽 밝은 층(블렌딩)
    ImageDraw.Draw(inner).polygon(heart_pts(cx, cy - W * 0.01, sz * 0.78), fill=hexc(light, 120))
    im.alpha_composite(inner)
    g = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    ImageDraw.Draw(g).ellipse((W * 0.2, W * 0.2, W * 0.42, W * 0.36), fill=(255, 255, 255, 170))
    im.alpha_composite(g.rotate(25, resample=Image.BICUBIC, center=(W * 0.3, W * 0.28)))
    return im.resize((size, size), Image.LANCZOS)


HEARTS = {"pink": ("#ff7fb0", "#d94a86", "#ffc4dc"), "yellow": ("#ffd75e", "#d99a1a", "#fff0a8"),
          "mint": ("#66e0bc", "#2aa985", "#b6f5e2"), "blue": ("#78b4ff", "#3d77d9", "#c4dcff")}
for name, (b, dk, lt) in HEARTS.items():
    big_heart(160, b, dk, lt).save(OUT / f"heart_{name}.png")

# 슬라이더 손잡이
S = 48 * SS
im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(im)
d.ellipse((2 * SS, 5 * SS, S - 2 * SS, S - 1), fill=hexc("#a8378a", 120))          # 그림자
d.ellipse((2 * SS, 2 * SS, S - 2 * SS, S - 5 * SS), fill=hexc("#ffffff"), outline=hexc("#ff7fb0"), width=4 * SS)
d.ellipse((13 * SS, 12 * SS, S - 13 * SS, S - 16 * SS), fill=hexc("#ffb3d1"))
im.resize((48, 48), Image.LANCZOS).save(OUT / "knob.png")

# 톱니바퀴(설정) 아이콘: 원 배경 + 흰 톱니
size = 128
im = Image.new("RGBA", (size * SS, size * SS), (0, 0, 0, 0))
d = ImageDraw.Draw(im)
d.ellipse((0, 0, size * SS - 1, size * SS - 1), fill=hexc("#ffffff"))
d.ellipse((8 * SS, 8 * SS, (size - 8) * SS, (size - 8) * SS), fill=hexc("#8f68ff"))
c = 64 * SS
for i in range(8):
    a = math.radians(i * 45)
    d.line((c + 22 * SS * math.cos(a), c + 22 * SS * math.sin(a), c + 38 * SS * math.cos(a), c + 38 * SS * math.sin(a)),
           fill=hexc("#ffffff"), width=13 * SS)
d.ellipse((c - 28 * SS, c - 28 * SS, c + 28 * SS, c + 28 * SS), fill=hexc("#ffffff"))
d.ellipse((c - 13 * SS, c - 13 * SS, c + 13 * SS, c + 13 * SS), fill=hexc("#8f68ff"))
im.resize((size, size), Image.LANCZOS).save(OUT / "ic_gear.png")

# ── 시작 화면(presplash): 게임이 켜지는 동안 잠깐 보이는 정지 화면 ──
W, H = 1920, 1080
bg = Image.new("RGBA", (W, H))
px = ImageDraw.Draw(bg)
for y in range(H):
    t = y / (H - 1)
    px.line((0, y, W, y), fill=(int(120 + 100 * t), int(90 + 40 * t), int(200 - 30 * t), 255))
bg = bg.convert("RGBA")
# 반짝이 점
import random
random.seed(7)
spark = Image.new("RGBA", (W, H), (0, 0, 0, 0))
sd = ImageDraw.Draw(spark)
for _ in range(60):
    x, y, r = random.randint(0, W), random.randint(0, H), random.randint(3, 9)
    sd.ellipse((x - r, y - r, x + r, y + r), fill=(255, 255, 255, random.randint(60, 150)))
bg.alpha_composite(spark)
for i, name in enumerate(("pink", "yellow", "mint")):
    h = Image.open(OUT / f"heart_{name}.png").resize((200, 200), Image.LANCZOS)
    bg.alpha_composite(h, (W // 2 - 330 + i * 230, 380 - (30 if i == 1 else 0)))
font_path = ROOT / "game" / "SourceHanSansLite.ttf"
title = ImageFont.truetype(str(font_path), 150)
sub = ImageFont.truetype(str(font_path), 52)
td = ImageDraw.Draw(bg)
text = "렌파이 온라인"
tw = td.textlength(text, font=title)
td.text(((W - tw) / 2, 130), text, font=title, fill=hexc("#fff3a8"), stroke_width=14, stroke_fill=hexc("#6a3aa8"))
sub_t = "불러오는 중..."
sw = td.textlength(sub_t, font=sub)
td.text(((W - sw) / 2, 700), sub_t, font=sub, fill=hexc("#ffffff"), stroke_width=7, stroke_fill=hexc("#6a3aa8"))
bg.convert("RGB").save(ROOT / "game" / "presplash.png")
print("ok")
