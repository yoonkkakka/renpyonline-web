﻿# TODO: Translation updated at 2026-09-28 18:01

translate tchinese strings:

    # game/rpg/raid.rpy:152
    old "전투 불능..."
    new "戰鬥不能…"

