"""제공된 등급 표시 이미지에서 내용 정보(선정성/폭력성/공포/언어의 부적절성/범죄/사행성)와 18세 마크를
잘라 투명 PNG 로 저장한다. 바깥 흰 배경만 투명하게 만들고, 아이콘 안쪽의 흰색은 그대로 둔다."""
import glob
from pathlib import Path

import numpy as np
from PIL import Image
from scipy import ndimage as ndi

SRC = Path(r"C:/Users/yunhy/AppData/Local/Temp/claude/D--renpy-online/6b94e1dd-78f1-41a5-8d0d-b0dfb48f333d/images")
OUT = Path(__file__).resolve().parent.parent / "game" / "gui" / "rating"
OUT.mkdir(parents=True, exist_ok=True)
SCALE = 4


def cut_transparent(im):
    """가장자리와 이어진 밝은 배경만 투명 처리."""
    rgba = np.array(im.convert("RGBA"))
    light = (rgba[:, :, :3].min(axis=2) > 200) | (rgba[:, :, 3] < 30)
    lab, n = ndi.label(light)
    edge = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))) - {0}
    bg = np.isin(lab, list(edge))
    rgba[bg, 3] = 0
    return Image.fromarray(rgba)


def save_big(im, name):
    big = im.resize((im.width * SCALE, im.height * SCALE), Image.LANCZOS)
    big.save(OUT / name)
    print(name, big.size)


sheet = Image.open(SRC / "9.png").convert("RGBA")
bg = Image.new("RGBA", sheet.size, (255, 255, 255, 255))
bg.alpha_composite(sheet)
g = np.array(bg.convert("L"))
cols = np.where((g < 140).any(axis=0))[0]
segs, start, prev = [], cols[0], cols[0]
for c in cols[1:]:
    if c - prev > 12:
        segs.append((start, prev)); start = c
    prev = c
segs.append((start, prev))
names = ["sexual", "violence", "fear", "language", "drug", "crime", "gambling"]   # 왼쪽부터 순서
assert len(segs) == 7
for (x0, x1), nm in zip(segs, names):
    if nm == "drug":
        continue
    tile = bg.crop((max(0, x0 - 3), 3, min(sheet.width, x1 + 4), 100))
    save_big(cut_transparent(tile), f"{nm}.png")

age = Image.open(SRC / "10.png").convert("RGBA")
abg = Image.new("RGBA", age.size, (255, 255, 255, 255))
abg.alpha_composite(age)
save_big(cut_transparent(abg), "age18.png")
