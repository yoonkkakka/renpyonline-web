# 이용 등급 안내(청소년 이용불가)

translate schinese strings:

    old "청소년 이용불가"
    new "未成年人禁止"

    old "이 게임에는 거친 언어가 포함되어 있어요."
    new "本游戏包含粗俗语言。"
