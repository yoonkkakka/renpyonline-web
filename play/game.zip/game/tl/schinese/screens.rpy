﻿# TODO: Translation updated at 2026-09-28 16:13

translate schinese strings:

    # game/screens.rpy:246
    old "되감기"
    new "되감기"

    # game/screens.rpy:247
    old "대사록"
    new "대사록"

    # game/screens.rpy:248
    old "넘기기"
    new "넘기기"

    # game/screens.rpy:249
    old "자동진행"
    new "자동진행"

    # game/screens.rpy:250
    old "저장하기"
    new "저장하기"

    # game/screens.rpy:251
    old "Q.저장하기"
    new "Q.저장하기"

    # game/screens.rpy:252
    old "Q.불러오기"
    new "Q.불러오기"

    # game/screens.rpy:253
    old "설정"
    new "설정"

    # game/screens.rpy:299
    old "시작하기"
    new "시작하기"

    # game/screens.rpy:307
    old "불러오기"
    new "불러오기"

    # game/screens.rpy:309
    old "환경설정"
    new "환경설정"

    # game/screens.rpy:313
    old "리플레이 끝내기"
    new "리플레이 끝내기"

    # game/screens.rpy:317
    old "메인 메뉴"
    new "메인 메뉴"

    # game/screens.rpy:319
    old "버전정보"
    new "버전정보"

    # game/screens.rpy:324
    old "조작방법"
    new "조작방법"

    # game/screens.rpy:330
    old "종료하기"
    new "종료하기"

    # game/screens.rpy:474
    old "돌아가기"
    new "返回"

    # game/screens.rpy:557
    old "버전 [config.version!t]\n"
    new "버전 [config.version!t]\n"

    # game/screens.rpy:563
    old "{a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only] 으로 만들어진 게임.\n\n[renpy.license!t]"
    new "{a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only] 으로 만들어진 게임.\n\n[renpy.license!t]"

    # game/screens.rpy:598
    old "{} 페이지"
    new "{} 페이지"

    # game/screens.rpy:598
    old "자동 세이브"
    new "자동 세이브"

    # game/screens.rpy:598
    old "퀵세이브"
    new "퀵세이브"

    # game/screens.rpy:639
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"

    # game/screens.rpy:639
    old "빈 슬롯"
    new "빈 슬롯"

    # game/screens.rpy:659
    old "<"
    new "<"

    # game/screens.rpy:663
    old "{#auto_page}자동"
    new "{#auto_page}자동"

    # game/screens.rpy:666
    old "{#quick_page}퀵"
    new "{#quick_page}퀵"

    # game/screens.rpy:672
    old ">"
    new ">"

    # game/screens.rpy:677
    old "동기화 업로드"
    new "동기화 업로드"

    # game/screens.rpy:681
    old "동기화 다운로드"
    new "동기화 다운로드"

    # game/screens.rpy:740
    old "화면 모드"
    new "화면 모드"

    # game/screens.rpy:741
    old "창 화면"
    new "창 화면"

    # game/screens.rpy:742
    old "전체 화면"
    new "全屏"

    # game/screens.rpy:747
    old "읽지 않은 지문"
    new "읽지 않은 지문"

    # game/screens.rpy:748
    old "선택지 이후"
    new "선택지 이후"

    # game/screens.rpy:749
    old "화면 전환 효과"
    new "화면 전환 효과"

    # game/screens.rpy:762
    old "텍스트 속도"
    new "텍스트 속도"

    # game/screens.rpy:766
    old "자동 진행 시간"
    new "자동 진행 시간"

    # game/screens.rpy:773
    old "배경음 음량"
    new "배경음 음량"

    # game/screens.rpy:780
    old "효과음 음량"
    new "효과음 음량"

    # game/screens.rpy:786
    old "테스트"
    new "테스트"

    # game/screens.rpy:790
    old "음성 음량"
    new "음성 음량"

    # game/screens.rpy:801
    old "모두 음소거"
    new "모두 음소거"

    # game/screens.rpy:919
    old "대사가 없습니다."
    new "대사가 없습니다."

    # game/screens.rpy:986
    old "키보드"
    new "키보드"

    # game/screens.rpy:987
    old "마우스"
    new "마우스"

    # game/screens.rpy:990
    old "게임패드"
    new "게임패드"

    # game/screens.rpy:1003
    old "엔터(Enter)"
    new "엔터(Enter)"

    # game/screens.rpy:1004
    old "대사 진행 및 UI (선택지 포함) 선택."
    new "대사 진행 및 UI (선택지 포함) 선택."

    # game/screens.rpy:1007
    old "스페이스(Space)"
    new "스페이스(Space)"

    # game/screens.rpy:1008
    old "대사를 진행하되 선택지는 선택하지 않음."
    new "대사를 진행하되 선택지는 선택하지 않음."

    # game/screens.rpy:1011
    old "화살표 키"
    new "화살표 키"

    # game/screens.rpy:1012
    old "UI 이동."
    new "UI 이동."

    # game/screens.rpy:1015
    old "이스케이프(Esc)"
    new "이스케이프(Esc)"

    # game/screens.rpy:1016
    old "게임 메뉴 불러옴."
    new "게임 메뉴 불러옴."

    # game/screens.rpy:1019
    old "컨트롤(Ctrl)"
    new "컨트롤(Ctrl)"

    # game/screens.rpy:1020
    old "누르고 있는 동안 대사를 스킵."
    new "누르고 있는 동안 대사를 스킵."

    # game/screens.rpy:1023
    old "탭(Tab)"
    new "탭(Tab)"

    # game/screens.rpy:1024
    old "대사 스킵 토글."
    new "대사 스킵 토글."

    # game/screens.rpy:1027
    old "페이지 업(Page Up)"
    new "페이지 업(Page Up)"

    # game/screens.rpy:1028
    old "이전 대사로 롤백."
    new "이전 대사로 롤백."

    # game/screens.rpy:1031
    old "페이지 다운(Page Down)"
    new "페이지 다운(Page Down)"

    # game/screens.rpy:1032
    old "이후 대사로 롤포워드."
    new "이후 대사로 롤포워드."

    # game/screens.rpy:1036
    old "UI를 숨김."
    new "UI를 숨김."

    # game/screens.rpy:1040
    old "스크린샷 저장."
    new "스크린샷 저장."

    # game/screens.rpy:1044
    old "{a=https://www.renpy.org/l/voicing}대사 읽어주기 기능{/a} 토글."
    new "{a=https://www.renpy.org/l/voicing}대사 읽어주기 기능{/a} 토글."

    # game/screens.rpy:1048
    old "접근성 메뉴를 엽니다."
    new "접근성 메뉴를 엽니다."

    # game/screens.rpy:1054
    old "클릭"
    new "클릭"

    # game/screens.rpy:1058
    old "가운데 버튼이나 휠버튼 클릭"
    new "가운데 버튼이나 휠버튼 클릭"

    # game/screens.rpy:1062
    old "우클릭"
    new "우클릭"

    # game/screens.rpy:1066
    old "휠 위로"
    new "휠 위로"

    # game/screens.rpy:1070
    old "휠 아래로"
    new "휠 아래로"

    # game/screens.rpy:1077
    old "오른쪽 트리거(RT)\nA버튼/아래 버튼"
    new "오른쪽 트리거(RT)\nA버튼/아래 버튼"

    # game/screens.rpy:1081
    old "왼쪽 트리거\n왼쪽 어깨"
    new "왼쪽 트리거\n왼쪽 어깨"

    # game/screens.rpy:1085
    old "오른쪽 범퍼(RB)"
    new "오른쪽 범퍼(RB)"

    # game/screens.rpy:1089
    old "D-Pad, 아날로그 스틱"
    new "D-Pad, 아날로그 스틱"

    # game/screens.rpy:1093
    old "Start, Guide, B/Right Button"
    new "Start, Guide, B/Right Button"

    # game/screens.rpy:1097
    old "Y버튼/위 버튼"
    new "Y버튼/위 버튼"

    # game/screens.rpy:1100
    old "조정"
    new "조정"

    # game/screens.rpy:1164
    old "네"
    new "是"

    # game/screens.rpy:1165
    old "아니오"
    new "否"

    # game/screens.rpy:1210
    old "넘기는 중"
    new "跳过中"

    # game/screens.rpy:1522
    old "메뉴"
    new "메뉴"

