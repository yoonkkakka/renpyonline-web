"""원본 시트(배경 4x4, 보스 4x4, 자동사냥센터)를 개별 에셋으로 자른다."""
import sys
from pathlib import Path
from PIL import Image

src = Path(sys.argv[1])
out = Path(__file__).resolve().parent.parent / "game" / "images"

from PIL import ImageFilter


def fit_bg(im):
    """1920x1080 로 cover 업스케일(LANCZOS) + 약한 샤프닝."""
    w, h = im.size
    s = max(1920 / w, 1080 / h)
    im = im.resize((round(w * s), round(h * s)), Image.LANCZOS)
    l, t = (im.width - 1920) // 2, (im.height - 1080) // 2
    return im.crop((l, t, l + 1920, t + 1080)).filter(ImageFilter.UnsharpMask(1.2, 60, 2))


def up_sprite(im, k=3):
    return im.resize((im.width * k, im.height * k), Image.LANCZOS)


# 1) 배경 시트: 1536x1024, 4x4, 타일 사이 구분선 ~4px
sheet = Image.open(src / "1.webp").convert("RGB")
W, H = sheet.size
cw, ch = W / 4, H / 4
for i in range(16):
    r, c = divmod(i, 4)
    box = (round(c * cw) + 3, round(r * ch) + 3, round((c + 1) * cw) - 3, round((r + 1) * ch) - 3)
    fit_bg(sheet.crop(box)).save(out / "bg" / f"t{i+1:02d}.webp", quality=88)

# 2) 자동 사냥 센터
fit_bg(Image.open(src / "2.webp").convert("RGB")).save(out / "bg" / "hunt_center.webp", quality=88)

# 3) 보스 시트: 스프라이트가 셀 경계를 넘으므로 알파 연결 영역으로 분리
import numpy as np
from scipy import ndimage as ndi

sheet = Image.open(src / "3.webp").convert("RGBA")
W, H = sheet.size
arr = np.array(sheet)
alpha = arr[:, :, 3]
strict = alpha > 230  # 반투명 후광으로 이웃과 붙지 않도록 엄격한 알파로 분리
lab, n = ndi.label(strict)
cw, ch = W / 4, H / 4
cells = {i: np.zeros((H, W), bool) for i in range(16)}
for k, sl in enumerate(ndi.find_objects(lab), 1):
    m = lab == k
    if m.sum() < 300:
        continue
    cx = (sl[1].start + sl[1].stop) / 2
    cy = (sl[0].start + sl[0].stop) / 2
    idx = min(3, int(cy // ch)) * 4 + min(3, int(cx // cw))
    cells[idx] |= m
for i in range(16):
    m = ndi.binary_dilation(cells[i], iterations=5)  # 후광 살리되 이웃 침범 방지
    ys, xs = np.nonzero(m)
    tile = arr.copy()
    tile[~m, 3] = 0
    up_sprite(Image.fromarray(tile).crop((xs.min(), ys.min(), xs.max() + 1, ys.max() + 1))).save(out / "boss" / f"s{i+1:02d}.png", optimize=True)
