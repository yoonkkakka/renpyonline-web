"""각성 시스템 + 스토리 대치(접근 방식) 서버 패치 (일회성)."""
from pathlib import Path

srv = Path(__file__).resolve().parent.parent / "server"


def patch(path, pairs):
    s = path.read_text(encoding="utf-8")
    for old, new in pairs:
        assert old in s, old[:70]
        s = s.replace(old, new, 1)
    path.write_text(s, encoding="utf-8")


# ── rules.py ─────────────────────────────────────────────────
patch(srv / "rules.py", [
    ('''def compute_stats(level: int, body: dict) -> dict:
    g = lambda k: int(body.get(k, 0))
    return {''', '''def compute_stats(level: int, body: dict, awake: dict | None = None) -> dict:
    awake = awake or {}
    # 각성 1단계 = 신체 단계 +AWAKE_EQ 상당
    g = lambda k: int(body.get(k, 0)) + AWAKE_EQ * int(awake.get(k, 0))
    return {'''),
    ('''"crit": round(min(0.6, 0.05 + 0.004 * g("nerve")), 3),''', '''"crit": round(min(0.6, 0.05 + 0.004 * g("nerve")), 3),'''),
    ('''"cd_reduce": round(min(0.30, 0.006 * g("nerve")), 3),
        "dodge": round(min(0.15, 0.003 * g("legs")), 3),''', '''"cd_reduce": round(min(0.40, 0.006 * g("nerve")), 3),
        "dodge": round(min(0.25, 0.003 * g("legs")), 3),'''),
])

with (srv / "rules.py").open("a", encoding="utf-8") as f:
    f.write('''

# ══════════════════════════════════════════════════════════════
# 각성: 신체 6부위를 모두 BODY_MAX 로 만들면 열리는 다음 성장 단계
# ══════════════════════════════════════════════════════════════
AWAKE_MAX = 10
AWAKE_EQ = 3            # 각성 1단계 = 신체 3단계 상당 (부위당 최대 +30단계)

def awake_unlocked(body: dict) -> bool:
    return all(int(body.get(k, 0)) >= BODY_MAX for k in BODY_IDS)

def awake_cost(a: int) -> tuple[int, int]:
    """각성 a -> a+1 에 필요한 (골드, 각성 결정)."""
    return int(20000 * (a + 1) ** 1.5), 1 + a

def crystal_drop_boss(boss_id: int) -> int:
    """고레벨 보스가 각성 결정을 떨어뜨린다."""
    if boss_id >= 16:
        return 3
    if boss_id >= 10:
        return 1
    return 0


# ══════════════════════════════════════════════════════════════
# 스토리 대치: 보스전 전에 대사를 나누고 접근 방식을 고른다 (선택이 실제 전투를 바꾼다)
# ══════════════════════════════════════════════════════════════
APPROACHES = {
    "direct":  {"name": "정면 돌파", "hp": 1.0,  "atk": 1.0,  "reward": 1.0,
                "desc": "아무 변화 없음"},
    "analyze": {"name": "약점 분석", "hp": 0.85, "atk": 1.0,  "reward": 0.9,
                "desc": "보스 체력 -15% / 보상 -10%"},
    "taunt":   {"name": "도발",      "hp": 1.0,  "atk": 1.25, "reward": 1.4,
                "desc": "보스 공격력 +25% / 보상 +40%"},
    # 대화는 도박: 50% 로 보스가 방심(체력 -30%, 공격 -10%), 50% 로 격노(공격 +40%)
    "talk":    {"name": "대화 시도", "hp": 1.0,  "atk": 1.0,  "reward": 1.0,
                "desc": "도박: 50% 방심(체력 -30%) / 50% 격노(공격 +40%)",
                "success": {"hp": 0.7, "atk": 0.9}, "fail": {"atk": 1.4}},
}
''')

# ── main.py ──────────────────────────────────────────────────
patch(srv / "main.py", [
    # extra 기본값
    ('''    e.setdefault("checkin", {"last": "", "streak": 0})''',
     '''    e.setdefault("checkin", {"last": "", "streak": 0})
    e.setdefault("awake", {k: 0 for k in R.BODY_IDS})
    e.setdefault("crystals", 0)'''),
    # view
    ('''        "stats": R.compute_stats(lv, body), "has_avatar"''',
     '''        "stats": R.compute_stats(lv, body, e["awake"]), "has_avatar"'''),
    ('''        "daily_claimable": claimable,''',
     '''        "awake": {k: int(e["awake"].get(k, 0)) for k in R.BODY_IDS}, "crystals": e["crystals"],
        "awake_unlocked": R.awake_unlocked(body), "daily_claimable": claimable,'''),
    # meta
    ('''        "missions": R.DAILY_MISSIONS,''',
     '''        "missions": R.DAILY_MISSIONS,
        "awake": {"max": R.AWAKE_MAX, "eq": R.AWAKE_EQ,
                  "costs": [dict(zip(("gold", "crystals"), R.awake_cost(a))) for a in range(R.AWAKE_MAX)]},
        "approaches": [{"id": k, **{x: v[x] for x in ("name", "desc")}} for k, v in R.APPROACHES.items()],'''),
    # 보스 시작: 접근 방식
    ('''class BossReq(BaseModel):
    boss_id: int''', '''class BossReq(BaseModel):
    boss_id: int
    approach: str = "direct"'''),
    ('''    stats = R.compute_stats(p["level"], full_body(p))
    bid = uuid.uuid4().hex
    now = time.time()
    for k in [k for k, v in BATTLES.items() if now - v["t0"] > 900]:
        del BATTLES[k]
    BATTLES[bid] = {"pid": p["id"], "boss": r.boss_id, "t0": now, "stats": stats, "level": p["level"]}
    return {"ok": True, "battle_id": bid, "stats": stats, "boss": R.boss_stats(r.boss_id)}''',
     '''    stats = R.compute_stats(p["level"], full_body(p), get_extra(p)["awake"])
    ap = R.APPROACHES.get(r.approach)
    if not ap:
        raise ApiError("알 수 없는 접근 방식입니다.")
    mod = {"hp": ap["hp"], "atk": ap["atk"]}
    outcome = None
    if r.approach == "talk":
        outcome = "success" if secrets.randbelow(2) == 0 else "fail"
        mod = {"hp": ap["hp"], "atk": ap["atk"], **ap[outcome]}
    boss = R.boss_stats(r.boss_id)
    boss["hp"] = int(boss["hp"] * mod["hp"])
    boss["atk"] = round(boss["atk"] * mod["atk"], 1)
    bid = uuid.uuid4().hex
    now = time.time()
    for k in [k for k, v in BATTLES.items() if now - v["t0"] > 900]:
        del BATTLES[k]
    BATTLES[bid] = {"pid": p["id"], "boss": r.boss_id, "t0": now, "stats": stats, "level": p["level"],
                    "boss_stats": boss, "reward_mult": ap["reward"] * (1.0), "approach": r.approach}
    if r.approach == "taunt":
        BATTLES[bid]["reward_mult"] = ap["reward"]
    return {"ok": True, "battle_id": bid, "stats": stats, "boss": boss,
            "approach": {"id": r.approach, "name": ap["name"], "outcome": outcome}}'''),
    # 보스 종료: 저장된 보스 스탯/보상 배수/결정
    ('''        boss = R.boss_stats(bt["boss"])
        # 서버가''', '''        boss = bt["boss_stats"]
        # 서버가'''),
    ('''        rw = R.boss_rewards(bt["boss"])
        boost = time.time() < p.get("boost_until", 0)''', '''        rw = R.boss_rewards(bt["boss"])
        rm = bt["reward_mult"]
        rw = {"exp": int(rw["exp"] * rm), "gold": int(rw["gold"] * rm), "stones": rw["stones"]}
        boost = time.time() < p.get("boost_until", 0)'''),
    ('''        loot = roll_loot(rw, bt["boss"])
        p["gold"] += loot["gold"]''', '''        loot = roll_loot(rw, bt["boss"])
        crystals = R.crystal_drop_boss(bt["boss"]) + (2 if loot["rarity"] == "전설" else 0)
        get_extra(p)["crystals"] += crystals
        p["gold"] += loot["gold"]'''),
    ('''"rewards": {**rw, "exp": exp}, "loot": loot, "player": view(p)}''',
     '''"rewards": {**rw, "exp": exp, "crystals": crystals}, "loot": loot,
            "approach": bt["approach"], "player": view(p)}'''),
    # PVP: 각성 반영
    ('''    my_stats = R.pvp_stats(p["level"], full_body(p))
    opp_stats = R.pvp_stats(opp["level"], opp["body"])''',
     '''    my_stats = R.pvp_stats(p["level"], full_body(p), get_extra(p)["awake"])
    opp_stats = R.pvp_stats(opp["level"], opp["body"], opp.get("awake"))'''),
    ('''"bot": False, "tier": None, "eff": 0.8, "reward": 1.0, "sprite": 0, "body": full_body(row),''',
     '''"bot": False, "tier": None, "eff": 0.8, "reward": 1.0, "sprite": 0, "body": full_body(row),
        "awake": ex["awake"],'''),
    # PVP 승리: 고레벨 각성 결정
    ('''        pv["coins"] += rw["coins"]
        bump(p, "pvp")''', '''        pv["coins"] += rw["coins"]
        if won and p["level"] >= 100:
            e["crystals"] += 1
            rw["crystals"] = 1
        bump(p, "pvp")'''),
    # 일일 올클리어: 결정 +1
    ('''            got = {"gold": 0, "stones": R.DAILY_ALL_BONUS["stones"]}
            save(p, "stones", "boost_until", "extra")''', '''            get_extra(p)["crystals"] += 1
            got = {"gold": 0, "stones": R.DAILY_ALL_BONUS["stones"], "crystals": 1}
            save(p, "stones", "boost_until", "extra")'''),
])

# rules: pvp_stats 각성 인자
patch(srv / "rules.py", [
    ('''def pvp_stats(level: int, body: dict) -> dict:
    st = compute_stats(level, body)''', '''def pvp_stats(level: int, body: dict, awake: dict | None = None) -> dict:
    st = compute_stats(level, body, awake)'''),
])

# 각성 엔드포인트 (개발용 섹션 앞에 삽입)
s = (srv / "main.py").read_text(encoding="utf-8")
marker = "# ── 개발용 (DEV_MODE=1 일 때만)"
new = '''# ── 각성 ─────────────────────────────────────────────────────
@app.post("/api/awake/upgrade")
def awake_upgrade(b: Part, p: dict = Depends(current_player)):
    if b.part not in R.BODY_IDS:
        raise ApiError("알 수 없는 신체 부위입니다.")
    with LOCK:
        p = repo.get_by_id(p["id"])
        if not R.awake_unlocked(full_body(p)):
            raise ApiError(f"신체 6부위를 모두 {R.BODY_MAX}단계로 만들면 각성이 열립니다.")
        e = get_extra(p)
        cur = int(e["awake"].get(b.part, 0))
        if cur >= R.AWAKE_MAX:
            raise ApiError("이미 최대 각성입니다.")
        gold, crystals = R.awake_cost(cur)
        if p["gold"] < gold or e["crystals"] < crystals:
            raise ApiError("골드 또는 각성 결정이 부족합니다.")
        p["gold"] -= gold
        e["crystals"] -= crystals
        e["awake"][b.part] = cur + 1
        save(p, "gold", "extra")
    return {"ok": True, "player": view(p)}


'''
assert marker in s
(srv / "main.py").write_text(s.replace(marker, new + marker, 1), encoding="utf-8")

# 개발용: 각성 결정 지급
s = (srv / "main.py").read_text(encoding="utf-8")
old = '''        p["stones"] += 10_000
        save(p, "level", "exp", "gold", "stones")'''
assert old in s
s = s.replace(old, '''        p["stones"] += 10_000
        get_extra(p)["crystals"] += 100
        save(p, "level", "exp", "gold", "stones", "extra")''', 1)
(srv / "main.py").write_text(s, encoding="utf-8")
print("patched")
