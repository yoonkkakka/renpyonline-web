﻿# TODO: Translation updated at 2026-09-28 16:13

translate schinese strings:

    # game/rpg/fun_api.rpy:20
    old "강화석 %d개로 교환했습니다."
    new "已兑换 %d 个强化石。"

    # game/rpg/fun_api.rpy:32
    old ", 각성 결정 %d"
    new "，觉醒结晶 %d"

    # game/rpg/fun_api.rpy:33
    old "보상: 골드 %s, 강화석 %s%s"
    new "奖励：金币 %s，强化石 %s%s"

    # game/rpg/fun_api.rpy:40
    old "%d일차 출석! 골드 %s, 강화석 %d"
    new "第%d天签到! 金币 %s，强化石 %d"

    # game/rpg/fun_api.rpy:42
    old ", 경험치 부스트 1시간"
    new "，经验加成1小时"

    # game/rpg/fun_api.rpy:54
    old "방금 전"
    new "刚刚"

    # game/rpg/fun_api.rpy:56
    old "%d분 전"
    new "%d分钟前"

    # game/rpg/fun_api.rpy:58
    old "%d시간 전"
    new "%d小时前"

    # game/rpg/fun_api.rpy:59
    old "%d일 전"
    new "%d天前"

    # game/rpg/fun_api.rpy:79
    old "각성 성공!"
    new "觉醒成功!"

