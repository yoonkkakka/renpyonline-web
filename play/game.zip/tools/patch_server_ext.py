"""main.py 에 확장 모듈 연동(히로인 보너스, 트로피 드롭, 시스템 계정 보호, 라우터 등록) 패치 (일회성)."""
from pathlib import Path

p = Path(__file__).resolve().parent.parent / "server" / "main.py"
s = p.read_text(encoding="utf-8")


def rep(old, new, count=1):
    global s
    assert old in s, old[:70]
    s = s.replace(old, new, count)


# 로그인: 시스템 계정("!") 해시 보호
rep('''def check_pw(pw: str, stored: str) -> bool:
    salt, h = stored.split("$")''', '''def check_pw(pw: str, stored: str) -> bool:
    if "$" not in stored:
        return False
    salt, h = stored.split("$")''')

# 가입: "__" 로 시작하는 이름 금지(시스템 계정 예약)
rep('''    if not (2 <= len(name) <= 16) or not name.replace("_", "").isalnum():''',
    '''    if name.startswith("__") or not (2 <= len(name) <= 16) or not name.replace("_", "").isalnum():''')

# 시스템 계정을 랭킹/PVP 후보에서 제외
rep('''def full_body(p: dict) -> dict:''', '''def all_players() -> list[dict]:
    return [r for r in repo.list_all() if not r["username"].startswith("__")]


def full_body(p: dict) -> dict:''')
s = s.replace("repo.list_all()", "all_players()").replace("return [r for r in all_players() if not", "return [r for r in repo.list_all() if not")

# 히로인 보너스를 능력치 계산에 반영
rep('''"stats": R.compute_stats(lv, body, e["awake"]),''', '''"stats": R.compute_stats(lv, body, e["awake"], R.heroine_bonus(e, p.get("clears") or {})),''')
rep('''    stats = R.compute_stats(p["level"], full_body(p), get_extra(p)["awake"])''',
    '''    _e = get_extra(p)
    stats = R.compute_stats(p["level"], full_body(p), _e["awake"], R.heroine_bonus(_e, p.get("clears") or {}))''')
rep('''    my_stats = R.pvp_stats(p["level"], full_body(p), get_extra(p)["awake"])''',
    '''    _e = get_extra(p)
    my_stats = R.pvp_stats(p["level"], full_body(p), _e["awake"], R.heroine_bonus(_e, p.get("clears") or {}))''')

# 보스 트로피 드롭
rep('''        bump(p, "boss")
        clears = dict(p.get("clears") or {})''', '''        bump(p, "boss")
        drop = None
        if secrets.randbelow(1000) < int(R.TROPHY_DROP_CHANCE * 1000):
            drop = f"trophy_{bt['boss']}"
            _e = get_extra(p)
            _e.setdefault("inventory", {})
            _e["inventory"][drop] = _e["inventory"].get(drop, 0) + 1
        clears = dict(p.get("clears") or {})''')
rep('''"approach": bt["approach"], "player": view(p)}''', '''"approach": bt["approach"], "drop": ({"id": drop, "name": R.ITEMS[drop]["name"]} if drop else None),
            "player": view(p)}''')

# 라우터 등록(파일 맨 끝)
s = s.rstrip("\n") + '''


# ── 확장 API (인벤토리/히로인/경매장) ──────────────────────────
import ext  # noqa: E402  (main 의 정의가 끝난 뒤에 가져와야 순환 참조가 안 생긴다)

app.include_router(ext.router)
'''
p.write_text(s, encoding="utf-8")
print("patched")
