"""확장 API: 인벤토리/상점, 히로인(전연령 미연시), 경매장. 모든 거래는 게임 골드로만 이뤄지고 현금 거래는 없다.

경매 목록은 숨은 시스템 계정("__system__") 행의 extra 에 저장한다(테이블 추가 없이 동작).
"""
from __future__ import annotations

import math
import random
import time
import uuid

from fastapi import APIRouter, Depends
from pydantic import BaseModel

import main as M
import rules as R

router = APIRouter()
SYSTEM_NAME = "__system__"
ApiError = M.ApiError


# ── 공통 도우미 ──────────────────────────────────────────────
def ex(p: dict) -> dict:
    e = M.get_extra(p)
    e.setdefault("inventory", {})
    e.setdefault("heroines", {})
    e.setdefault("mail", [])
    return e


def inv_add(p: dict, item: str, n: int = 1) -> None:
    inv = ex(p)["inventory"]
    inv[item] = inv.get(item, 0) + n


def inv_take(p: dict, item: str, n: int) -> None:
    inv = ex(p)["inventory"]
    if inv.get(item, 0) < n:
        raise ApiError("아이템이 부족해요.")
    inv[item] -= n
    if inv[item] <= 0:
        del inv[item]


def mail(p: dict, text: str) -> None:
    e = ex(p)
    e["mail"] = ([{"t": int(time.time()), "text": text}] + e["mail"])[:30]


def item_view(item: str, qty: int) -> dict:
    d = R.ITEMS[item]
    return {"id": item, "name": d["name"], "qty": qty, "price": d["price"], "kind": d["kind"], "desc": d["desc"],
            "sell": int(d["price"] * R.NPC_SELL_RATE) if d["kind"] in ("trophy", "memento") else 0}


def need_item(item: str) -> dict:
    if item not in R.ITEMS:
        raise ApiError("알 수 없는 아이템이에요.")
    return R.ITEMS[item]


# ── 인벤토리 / 상점 ──────────────────────────────────────────
@router.get("/api/inventory")
def inventory(p: dict = Depends(M.current_player)):
    e = ex(p)
    items = [item_view(i, q) for i, q in e["inventory"].items() if q > 0 and i in R.ITEMS]
    items.sort(key=lambda x: (x["kind"], x["id"]))
    shop = [item_view(i, 0) for i in R.SHOP_ITEMS]
    return {"ok": True, "items": items, "shop": shop, "mail": e["mail"][:15]}


class BuyReq(BaseModel):
    item: str
    qty: int = 1


@router.post("/api/shop/buy")
def shop_buy(b: BuyReq, p: dict = Depends(M.current_player)):
    if b.item not in R.SHOP_ITEMS:
        raise ApiError("상점에서 팔지 않는 아이템이에요.")
    if not 1 <= b.qty <= 99:
        raise ApiError("수량이 올바르지 않아요.")
    with M.LOCK:
        p = M.repo.get_by_id(p["id"])
        cost = R.ITEMS[b.item]["price"] * b.qty
        if p["gold"] < cost:
            raise ApiError("골드가 부족해요.")
        p["gold"] -= cost
        inv_add(p, b.item, b.qty)
        M.save(p, "gold", "extra")
    return {"ok": True, "player": M.view(p)}


class ItemReq(BaseModel):
    item: str
    qty: int = 1


@router.post("/api/item/use")
def item_use(b: ItemReq, p: dict = Depends(M.current_player)):
    d = need_item(b.item)
    if d["kind"] != "potion":
        raise ApiError("사용할 수 없는 아이템이에요.")
    with M.LOCK:
        p = M.repo.get_by_id(p["id"])
        inv_take(p, b.item, 1)
        p["boost_until"] = max(time.time(), p.get("boost_until", 0)) + R.BOOST_SECONDS
        M.save(p, "boost_until", "extra")
    return {"ok": True, "player": M.view(p)}


@router.post("/api/item/sell")
def item_sell(b: ItemReq, p: dict = Depends(M.current_player)):
    d = need_item(b.item)
    if d["kind"] not in ("trophy", "memento") or not 1 <= b.qty <= 999:
        raise ApiError("상점에 팔 수 없는 아이템이에요.")
    with M.LOCK:
        p = M.repo.get_by_id(p["id"])
        inv_take(p, b.item, b.qty)
        gold = int(d["price"] * R.NPC_SELL_RATE) * b.qty
        p["gold"] += gold
        M.save(p, "gold", "extra")
    return {"ok": True, "gold": gold, "player": M.view(p)}


@router.get("/api/mail")
def get_mail(p: dict = Depends(M.current_player)):
    return {"ok": True, "mail": ex(p)["mail"]}


# ── 히로인 (전연령 미연시: 호감도, 대화, 선물, 이벤트) ────────────
def heroine_state(p: dict, h: dict) -> dict:
    e = ex(p)
    st = e["heroines"].setdefault(h["id"], {"aff": 0, "talk_date": "", "talks": 0, "claimed": []})
    if st.get("talk_date") != M.today_kst():
        st["talk_date"] = M.today_kst()
        st["talks"] = 0
    return st


def unlocked(p: dict, h: dict) -> bool:
    return int((p.get("clears") or {}).get(str(h["boss_id"]), 0)) > 0


def heroine_view(p: dict, h: dict) -> dict:
    st = heroine_state(p, h)
    aff = st["aff"]
    k, v = h["bonus"]
    events = []
    for i, evn in enumerate(h["events"]):
        events.append({"idx": i, "title": evn["title"], "aff": evn["aff"], "ready": aff >= evn["aff"] and i not in st["claimed"],
                       "done": i in st["claimed"]})
    return {"id": h["id"], "name": h["name"], "boss_id": h["boss_id"], "sprite": h["sprite"], "desc": h["desc"],
            "unlocked": unlocked(p, h), "aff": aff, "talks_left": max(0, R.TALKS_PER_DAY - st["talks"]),
            "likes": h["likes"], "likes_name": R.ITEMS[h["likes"]]["name"],
            "bonus_key": k, "bonus_text": h["bonus_text"], "bonus_now": round(v * aff / R.AFF_MAX * 100, 1),
            "bonus_max": round(v * 100, 1), "events": events}


@router.get("/api/heroines")
def heroines(p: dict = Depends(M.current_player)):
    with M.LOCK:
        p = M.repo.get_by_id(p["id"])
        out = [heroine_view(p, h) for h in R.HEROINES]
        M.save(p, "extra")
    inv = ex(p)["inventory"]
    return {"ok": True, "heroines": out, "gifts": [item_view(g, inv.get(g, 0)) for g in ("gift_flower", "gift_sweet", "gift_book")]}


class HeroineReq(BaseModel):
    id: str
    item: str = ""
    idx: int = 0


def need_heroine(p: dict, hid: str) -> dict:
    h = R.HEROINE_BY_ID.get(hid)
    if not h:
        raise ApiError("알 수 없는 히로인이에요.")
    if not unlocked(p, h):
        raise ApiError(f"{R.BOSS_BY_ID[h['boss_id']]['name']}을(를) 쓰러뜨리면 만날 수 있어요.")
    return h


@router.post("/api/heroines/talk")
def heroine_talk(r: HeroineReq, p: dict = Depends(M.current_player)):
    with M.LOCK:
        p = M.repo.get_by_id(p["id"])
        h = need_heroine(p, r.id)
        st = heroine_state(p, h)
        if st["talks"] >= R.TALKS_PER_DAY:
            raise ApiError("오늘은 더 이야기할 수 없어요. 내일 다시 만나요!")
        st["talks"] += 1
        gain = random.randint(2, 4)
        before = st["aff"]
        st["aff"] = min(R.AFF_MAX, st["aff"] + gain)
        M.save(p, "extra")
    return {"ok": True, "gain": st["aff"] - before, "aff": st["aff"], "mood": random.randint(0, 2),
            "talks_left": R.TALKS_PER_DAY - st["talks"], "player": M.view(p)}


@router.post("/api/heroines/gift")
def heroine_gift(r: HeroineReq, p: dict = Depends(M.current_player)):
    d = need_item(r.item)
    if d["kind"] != "gift":
        raise ApiError("선물로 줄 수 없는 아이템이에요.")
    with M.LOCK:
        p = M.repo.get_by_id(p["id"])
        h = need_heroine(p, r.id)
        st = heroine_state(p, h)
        inv_take(p, r.item, 1)
        gain = int(d["aff"] * (1.5 if r.item == h["likes"] else 1.0))
        before = st["aff"]
        st["aff"] = min(R.AFF_MAX, st["aff"] + gain)
        M.save(p, "extra")
    return {"ok": True, "gain": st["aff"] - before, "liked": r.item == h["likes"], "aff": st["aff"], "player": M.view(p)}


@router.post("/api/heroines/event")
def heroine_event(r: HeroineReq, p: dict = Depends(M.current_player)):
    with M.LOCK:
        p = M.repo.get_by_id(p["id"])
        h = need_heroine(p, r.id)
        st = heroine_state(p, h)
        if not 0 <= r.idx < len(h["events"]):
            raise ApiError("알 수 없는 이벤트예요.")
        evn = h["events"][r.idx]
        if st["aff"] < evn["aff"]:
            raise ApiError("호감도가 부족해요.")
        if r.idx in st["claimed"]:
            raise ApiError("이미 본 이벤트예요.")
        st["claimed"].append(r.idx)
        item = f"mem_{h['id']}_{r.idx + 1}"
        inv_add(p, item, 1)
        gold = 1000 * (r.idx + 1)
        p["gold"] += gold
        mail(p, f"{h['name']} 이벤트 「{evn['title']}」 완료: {R.ITEMS[item]['name']} 획득")
        M.save(p, "gold", "extra")
    return {"ok": True, "item": item_view(item, 1), "gold": gold, "player": M.view(p)}


# ── 경매장 ───────────────────────────────────────────────────
def system_row() -> dict:
    row = M.repo.get_by_username(SYSTEM_NAME)
    if not row:
        row = M.repo.create({"username": SYSTEM_NAME, "password_hash": "!", "level": 1, "exp": 0, "gold": 0, "stones": 0,
                             "body": {}, "avatar_data": None, "hunt": None, "boost_until": 0, "clears": {}, "extra": {}})
    return row


def auction_load() -> tuple[dict, dict, dict]:
    row = system_row()
    e = row.get("extra") or {}
    a = e.get("auction") or {}
    a.setdefault("next_id", 1)
    a.setdefault("list", [])
    a.setdefault("npc_refill", 0)
    return row, e, a


def auction_save(row: dict, e: dict, a: dict) -> None:
    e["auction"] = a
    M.repo.update(row["id"], {"extra": e})


def _player(pid: str | None) -> dict | None:
    return M.repo.get_by_id(pid) if pid else None


def settle(a: dict, now: float) -> None:
    """끝난 경매 정산: 낙찰자에게 아이템, 판매자에게 수수료를 뗀 골드. 유찰이면 NPC 상인이 사거나 아이템을 돌려준다."""
    keep = []
    for L in a["list"]:
        if L["ends"] > now:
            keep.append(L)
            continue
        name = R.ITEMS[L["item"]]["name"]
        seller = _player(L["seller_id"])
        if L["bidder_id"]:
            winner = _player(L["bidder_id"])
            if winner:
                inv_add(winner, L["item"], L["qty"])
                mail(winner, f"경매 낙찰: {name} x{L['qty']} ({L['bid']:,} 골드)")
                M.save(winner, "extra")
            if seller:
                got = int(L["bid"] * (1 - R.AUCTION_FEE))
                seller["gold"] += got
                mail(seller, f"경매 판매 완료: {name} x{L['qty']} → {got:,} 골드(수수료 {int(R.AUCTION_FEE * 100)}%)")
                M.save(seller, "gold", "extra")
        elif seller:
            base = R.ITEMS[L["item"]]["price"] * L["qty"]
            if L["start_price"] <= base * 1.3:      # 합리적인 시작가면 경매 상인이 시작가에 사 준다
                got = int(L["start_price"] * (1 - R.AUCTION_FEE))
                seller["gold"] += got
                mail(seller, f"유찰: 경매 상인이 {name} x{L['qty']} 을(를) {got:,} 골드에 구매했어요.")
                M.save(seller, "gold", "extra")
            else:
                inv_add(seller, L["item"], L["qty"])
                mail(seller, f"유찰: {name} x{L['qty']} 이(가) 인벤토리로 돌아왔어요.")
                M.save(seller, "extra")
    a["list"] = keep


def refill_npc(a: dict, now: float) -> None:
    npc = [L for L in a["list"] if not L["seller_id"]]
    if len(npc) >= 6 or now - a.get("npc_refill", 0) < 600:
        return
    a["npc_refill"] = now
    pool = [i for i, v in R.ITEMS.items() if v["kind"] in ("trophy", "memento")]
    for _ in range(6 - len(npc)):
        item = random.choice(pool)
        base = R.ITEMS[item]["price"]
        a["list"].append({"id": a["next_id"], "seller": "경매 상인", "seller_id": None, "item": item, "qty": 1,
                          "start_price": int(base * random.uniform(0.7, 1.0)), "buyout": int(base * 1.6),
                          "bid": 0, "bidder": None, "bidder_id": None,
                          "ends": now + random.randint(3600, 8 * 3600), "created": now})
        a["next_id"] += 1


def listing_view(L: dict, me: str) -> dict:
    d = R.ITEMS[L["item"]]
    cur = L["bid"] or L["start_price"]
    nxt = L["start_price"] if not L["bid"] else max(L["bid"] + 1, math.ceil(L["bid"] * (1 + R.AUCTION_MIN_RAISE)))
    return {"id": L["id"], "seller": L["seller"], "item": L["item"], "name": d["name"], "kind": d["kind"], "qty": L["qty"],
            "start_price": L["start_price"], "buyout": L["buyout"], "bid": L["bid"], "bidder": L["bidder"], "current": cur,
            "next_bid": nxt, "left": max(0, int(L["ends"] - time.time())), "mine": L["seller_id"] == me,
            "leading": L["bidder_id"] == me, "base": d["price"] * L["qty"]}


@router.get("/api/auction")
def auction_list(p: dict = Depends(M.current_player)):
    now = time.time()
    with M.LOCK:
        row, e, a = auction_load()
        settle(a, now)
        refill_npc(a, now)
        auction_save(row, e, a)
        rows = sorted(a["list"], key=lambda L: L["ends"])
    return {"ok": True, "listings": [listing_view(L, p["id"]) for L in rows],
            "fee": int(R.AUCTION_FEE * 100), "max_listings": R.AUCTION_MAX_LISTINGS, "hours": list(R.AUCTION_HOURS)}


class CreateReq(BaseModel):
    item: str
    qty: int = 1
    start_price: int
    buyout: int = 0
    hours: int = 12


@router.post("/api/auction/create")
def auction_create(c: CreateReq, p: dict = Depends(M.current_player)):
    d = need_item(c.item)
    if d["kind"] not in ("trophy", "memento"):
        raise ApiError("경매에 올릴 수 없는 아이템이에요.")
    if not 1 <= c.qty <= 99 or c.hours not in R.AUCTION_HOURS:
        raise ApiError("수량이나 기간이 올바르지 않아요.")
    base = d["price"] * c.qty
    if c.start_price < 1 or c.start_price > base * R.AUCTION_MAX_MULT:
        raise ApiError("시작가가 올바르지 않아요.")
    if c.buyout and c.buyout <= c.start_price:
        raise ApiError("즉시 구매가는 시작가보다 커야 해요.")
    now = time.time()
    with M.LOCK:
        row, e, a = auction_load()
        settle(a, now)
        p = M.repo.get_by_id(p["id"])
        if sum(1 for L in a["list"] if L["seller_id"] == p["id"]) >= R.AUCTION_MAX_LISTINGS:
            raise ApiError(f"동시에 {R.AUCTION_MAX_LISTINGS}개까지만 올릴 수 있어요.")
        inv_take(p, c.item, c.qty)
        a["list"].append({"id": a["next_id"], "seller": p["username"], "seller_id": p["id"], "item": c.item, "qty": c.qty,
                          "start_price": c.start_price, "buyout": c.buyout, "bid": 0, "bidder": None, "bidder_id": None,
                          "ends": now + c.hours * 3600, "created": now})
        a["next_id"] += 1
        M.save(p, "extra")
        auction_save(row, e, a)
    return {"ok": True, "player": M.view(p)}


class BidReq(BaseModel):
    id: int
    amount: int = 0


def _find(a: dict, lid: int) -> dict:
    L = next((x for x in a["list"] if x["id"] == lid), None)
    if not L:
        raise ApiError("이미 끝났거나 없는 경매예요.")
    return L


@router.post("/api/auction/bid")
def auction_bid(b: BidReq, p: dict = Depends(M.current_player)):
    now = time.time()
    with M.LOCK:
        row, e, a = auction_load()
        settle(a, now)
        L = _find(a, b.id)
        p = M.repo.get_by_id(p["id"])
        if L["seller_id"] == p["id"]:
            raise ApiError("내가 올린 경매에는 입찰할 수 없어요.")
        need = L["start_price"] if not L["bid"] else max(L["bid"] + 1, math.ceil(L["bid"] * (1 + R.AUCTION_MIN_RAISE)))
        if b.amount < need:
            raise ApiError(f"최소 {need:,} 골드 이상 입찰해야 해요.")
        if L["buyout"] and b.amount >= L["buyout"]:
            raise ApiError("즉시 구매가 이상이면 '즉시 구매'를 이용해 주세요.")
        pay = b.amount - (L["bid"] if L["bidder_id"] == p["id"] else 0)
        if p["gold"] < pay:
            raise ApiError("골드가 부족해요.")
        prev = _player(L["bidder_id"]) if L["bidder_id"] and L["bidder_id"] != p["id"] else None
        if prev:                                            # 밀려난 입찰자에게 골드 환불
            prev["gold"] += L["bid"]
            mail(prev, f"입찰 환불: {R.ITEMS[L['item']]['name']} 경매에서 밀려나 {L['bid']:,} 골드가 돌아왔어요.")
            M.save(prev, "gold", "extra")
        p["gold"] -= pay
        L["bid"], L["bidder"], L["bidder_id"] = b.amount, p["username"], p["id"]
        if L["ends"] - now < 300:                           # 막판 입찰 시 5분 연장
            L["ends"] = now + 300
        M.save(p, "gold")
        auction_save(row, e, a)
    return {"ok": True, "player": M.view(p)}


@router.post("/api/auction/buyout")
def auction_buyout(b: BidReq, p: dict = Depends(M.current_player)):
    now = time.time()
    with M.LOCK:
        row, e, a = auction_load()
        settle(a, now)
        L = _find(a, b.id)
        p = M.repo.get_by_id(p["id"])
        if not L["buyout"]:
            raise ApiError("즉시 구매가 없는 경매예요.")
        if L["seller_id"] == p["id"]:
            raise ApiError("내가 올린 경매는 살 수 없어요.")
        pay = L["buyout"] - (L["bid"] if L["bidder_id"] == p["id"] else 0)
        if p["gold"] < pay:
            raise ApiError("골드가 부족해요.")
        prev = _player(L["bidder_id"]) if L["bidder_id"] and L["bidder_id"] != p["id"] else None
        if prev:
            prev["gold"] += L["bid"]
            mail(prev, f"입찰 환불: 즉시 구매로 경매가 끝나 {L['bid']:,} 골드가 돌아왔어요.")
            M.save(prev, "gold", "extra")
        seller = _player(L["seller_id"])
        if seller:
            got = int(L["buyout"] * (1 - R.AUCTION_FEE))
            seller["gold"] += got
            mail(seller, f"경매 판매 완료: {R.ITEMS[L['item']]['name']} x{L['qty']} → {got:,} 골드")
            M.save(seller, "gold", "extra")
        p["gold"] -= pay
        inv_add(p, L["item"], L["qty"])
        mail(p, f"즉시 구매: {R.ITEMS[L['item']]['name']} x{L['qty']} ({L['buyout']:,} 골드)")
        a["list"] = [x for x in a["list"] if x["id"] != L["id"]]
        M.save(p, "gold", "extra")
        auction_save(row, e, a)
    return {"ok": True, "player": M.view(p)}


@router.post("/api/auction/cancel")
def auction_cancel(b: BidReq, p: dict = Depends(M.current_player)):
    now = time.time()
    with M.LOCK:
        row, e, a = auction_load()
        settle(a, now)
        L = _find(a, b.id)
        p = M.repo.get_by_id(p["id"])
        if L["seller_id"] != p["id"]:
            raise ApiError("내가 올린 경매만 취소할 수 있어요.")
        if L["bidder_id"]:
            raise ApiError("입찰자가 있는 경매는 취소할 수 없어요.")
        inv_add(p, L["item"], L["qty"])
        a["list"] = [x for x in a["list"] if x["id"] != L["id"]]
        M.save(p, "extra")
        auction_save(row, e, a)
    return {"ok": True, "player": M.view(p)}
