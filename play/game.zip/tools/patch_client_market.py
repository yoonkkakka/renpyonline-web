"""허브(3x3) / 유혈 이펙트 / 보스 외침 / 거친 대사 토글 / 설정 연동 패치 (일회성)."""
from pathlib import Path

root = Path(__file__).resolve().parent.parent / "game"


def patch(path, pairs):
    s = path.read_text(encoding="utf-8")
    for old, new in pairs:
        assert old in s, (path.name, old[:80])
        s = s.replace(old, new, 1)
    path.write_text(s, encoding="utf-8")


# ── api.rpy: 새 옵션 기본값 ──
patch(root / "rpg" / "api.rpy", [
    ("default persistent.opt_log = True", "default persistent.opt_log = True\ndefault persistent.opt_blood = True\ndefault persistent.opt_rude = True"),
])

# ── ui_skin.rpy: 피 튀김 변환 ──
patch(root / "rpg" / "ui_skin.rpy", [
    ("# 살짝 위아래로 통통 튀는 장식용", '''# 유혈 이펙트: 중심 기준으로 커지며 사라지는 피 튀김
transform blood_fx(z=1.0, rot=0.0, a=1.0):
    anchor (0.5, 0.5)
    zoom z
    rotate rot
    alpha a

# 살짝 위아래로 통통 튀는 장식용'''),
])

# ── battle.rpy: 유혈 + 보스 외침 ──
patch(root / "rpg" / "battle.rpy", [
    ('''            self.combo = 0
            self.last_cast = 0.0
            self.bg_path''', '''            self.combo = 0
            self.last_cast = 0.0
            self.blood = []
            self.stains = []
            self.shout = ""
            self.shout_until = 0.0
            self.shouted = set()
            self.bg_path'''),
    ('''        # ── 조회 ────────────────────────────────''', '''        # ── 유혈 / 외침 ─────────────────────────
        def splash(self, n=1, big=False, boss=True):
            if not persistent.opt_blood:
                return
            now = time.time()
            cx, cy = (1240, 430) if boss else (300, 450)
            for _ in range(n):
                self.blood.append({"t": now, "x": cx + random.randint(-150, 150), "y": cy + random.randint(-160, 160),
                                   "img": random.randint(1, 4), "z": random.uniform(0.7, 1.5) * (1.4 if big else 1.0),
                                   "rot": random.randint(0, 359), "life": 1.1})
            if boss and (big or random.random() < 0.35):
                self.stains.append({"x": cx + random.randint(-260, 260), "y": cy + random.randint(-200, 220),
                                    "img": random.randint(1, 4), "z": random.uniform(0.6, 1.2), "rot": random.randint(0, 359)})
                self.stains = self.stains[-16:]

        def check_shout(self):
            frac = self.boss_hp / self.boss_max
            data = BOSS_SHOUTS.get(self.boss["id"])
            if not data:
                return
            for i, th in enumerate((0.7, 0.4, 0.1)):
                if frac <= th and i not in self.shouted:
                    self.shouted.add(i)
                    self.shout = data["rude" if persistent.opt_rude else "clean"][i]
                    self.shout_until = time.time() + 3.6
                    self.add_log(self.boss["name"] + ": " + self.shout, "#ffb0b0")
                    break

        # ── 조회 ────────────────────────────────'''),
    ('''            self.floaters = [f for f in self.floaters if now - f["t"] < 1.0]
            if self.combo and now - self.last_cast''', '''            self.floaters = [f for f in self.floaters if now - f["t"] < 1.0]
            self.blood = [b for b in self.blood if now - b["t"] < b["life"]]
            if self.combo and now - self.last_cast'''),
    ('''            self.player_hit_until = now + 0.28''', '''            self.player_hit_until = now + 0.28
            if heavy or dmg > self.hp_max * 0.08:
                self.splash(1, False, boss=False)'''),
    ('''                self.boss_hit_until = now + 0.12''', '''                self.boss_hit_until = now + 0.12
                self.splash(3 if crits else 1, bool(crits))
                self.check_shout()'''),
    ('''            if self.boss_hp <= 0:
                self.result = "win"''', '''            if self.boss_hp <= 0:
                self.splash(12, True)
                self.result = "win"'''),
])

# ── pvp.rpy: 유혈 ──
patch(root / "rpg" / "pvp.rpy", [
    ('''            self.combo = 0
            self.last_cast = 0.0
            self.bg_path = "images/bg/t15.webp"''', '''            self.combo = 0
            self.last_cast = 0.0
            self.blood = []
            self.stains = []
            self.bg_path = "images/bg/t15.webp"'''),
    ('''        # ── 내부 ──
        def add_log''', '''        def splash(self, target_is_opp, n=1, big=False):
            if not persistent.opt_blood:
                return
            now = time.time()
            cx, cy = (1250, 450) if target_is_opp else (300, 450)
            for _ in range(n):
                self.blood.append({"t": now, "x": cx + random.randint(-140, 140), "y": cy + random.randint(-150, 150),
                                   "img": random.randint(1, 4), "z": random.uniform(0.7, 1.4) * (1.3 if big else 1.0),
                                   "rot": random.randint(0, 359), "life": 1.1})
            if big or random.random() < 0.3:
                self.stains.append({"x": cx + random.randint(-240, 240), "y": cy + random.randint(-180, 200),
                                    "img": random.randint(1, 4), "z": random.uniform(0.6, 1.1), "rot": random.randint(0, 359)})
                self.stains = self.stains[-14:]

        # ── 내부 ──
        def add_log'''),
    ('''            tgt.hit_until = now + 0.15''', '''            tgt.hit_until = now + 0.15
            self.splash(tgt is self.opp, 3 if crits else 1, bool(crits))'''),
    ('''            self.floaters = [f for f in self.floaters if now - f["t"] < 1.0]
            if self.combo and now - self.last_cast''', '''            self.floaters = [f for f in self.floaters if now - f["t"] < 1.0]
            self.blood = [b for b in self.blood if now - b["t"] < b["life"]]
            if self.combo and now - self.last_cast'''),
])

# ── 스토리: 거친 재도전 대사 / 어두운 에필로그 ──
patch(root / "rpg" / "story.rpy", [
    ('''    def story_choose(boss_id):''', '''    def story_again(boss_id):
        if persistent.opt_rude and boss_id in BOSS_RUDE:
            return BOSS_RUDE[boss_id]["again"]
        return STORY[boss_id]["again"]

    def story_win(boss_id):
        if persistent.opt_rude and boss_id in BOSS_RUDE:
            return BOSS_RUDE[boss_id]["win"]
        return STORY[boss_id]["win"]

    def story_choose(boss_id):'''),
    ('''            story_say_lines(boss_id, [("b", _st["again"])])''', '''            story_say_lines(boss_id, [("b", story_again(boss_id))])'''),
    ('''        story_say_lines(boss_id, [("b", STORY[boss_id]["win"])])''', '''        story_say_lines(boss_id, [("b", story_win(boss_id))])'''),
])

# ── screens.rpy: 허브 3x3, 전투 화면 유혈/외침/비네트 ──
p = root / "rpg" / "screens.rpy"
s = p.read_text(encoding="utf-8")


def rep(old, new):
    global s
    assert old in s, old[:80]
    s = s.replace(old, new, 1)


rep('''        xysize (350, 250)
        background Frame("gui/rp/tile_%s.png" % tile, 44, 44, 44, 54)
        hover_background Frame("gui/rp/tile_%s_hover.png" % tile, 44, 44, 44, 54)
        action Return(ret)
        vbox:
            align (0.5, 0.4)
            spacing 4
            add icon xalign 0.5 zoom 0.9
            text label style "rp_text" size 38 xalign 0.5''', '''        xysize (350, 190)
        background Frame("gui/rp/tile_%s.png" % tile, 44, 44, 44, 54)
        hover_background Frame("gui/rp/tile_%s_hover.png" % tile, 44, 44, 44, 54)
        action Return(ret)
        vbox:
            align (0.5, 0.38)
            spacing 0
            add icon xalign 0.5 zoom 0.62
            text label style "rp_text" size 34 xalign 0.5''')
rep('''    vbox:
        xpos 740
        ypos 250
        spacing 26
        hbox:
            spacing 26
            use hub_tile("pink", "gui/rp/ic_char.png", "캐릭터 / 강화", "char")''', '''    vbox:
        xpos 740
        ypos 240
        spacing 20
        hbox:
            spacing 26
            use hub_tile("pink", "gui/rp/ic_char.png", "캐릭터 / 강화", "char")''')
rep('''            use hub_tile("yellow", "gui/rp/ic_rank.png", "랭킹", "ranking")
''', '''            use hub_tile("yellow", "gui/rp/ic_rank.png", "랭킹", "ranking")
        hbox:
            spacing 26
            use hub_tile("pink", "gui/rp/ic_love.png", "히로인", "heroine")
            use hub_tile("orange", "gui/rp/ic_auction.png", "경매장", "auction")
            use hub_tile("mint", "gui/rp/ic_bag.png", "가방 / 상점", "bag")
''')

# 전투 화면: 유혈 / 비네트 / 외침
rep('''    # 보스 체력 / 예고
    frame:''', '''    # 유혈 이펙트(설정에서 끌 수 있음)
    if persistent.opt_blood:
        for st in bt.stains:
            add "gui/rp/blood_%d.png" % st["img"] at blood_fx(st["z"], st["rot"], 0.42) pos (st["x"], st["y"])
        for bl in bt.blood:
            $ bage = now - bl["t"]
            if bage < bl["life"]:
                add "gui/rp/blood_%d.png" % bl["img"] at blood_fx(bl["z"] * (0.55 + min(bage, 0.3) * 1.6), bl["rot"], max(0.0, 1.0 - bage / bl["life"])) pos (bl["x"], bl["y"])
        if now < bt.player_hit_until:
            add "gui/rp/blood_vignette.png"
        elif bt.hp < bt.hp_max * 0.3:
            add "gui/rp/blood_vignette.png" alpha (0.55 + 0.3 * math.sin(now * 6))
    if bt.shout and now < bt.shout_until:
        frame:
            style "rp_panel"
            xalign 0.78
            ypos 250
            padding (26, 14)
            text bt.shout style "rp_text" size 34 color "#ffb0b0" outlines [(6, "#4a0a1a", 0, 2)]

    # 보스 체력 / 예고
    frame:''')
p.write_text(s, encoding="utf-8")

# PVP 화면 유혈
patch(root / "rpg" / "screens_fun.rpy", [
    ('''    # 체력 바
    frame:
        style "rp_panel"
        xpos 24
        ypos 20
        xsize 730''', '''    # 유혈 이펙트(설정에서 끌 수 있음)
    if persistent.opt_blood:
        for st in bt.stains:
            add "gui/rp/blood_%d.png" % st["img"] at blood_fx(st["z"], st["rot"], 0.42) pos (st["x"], st["y"])
        for bl in bt.blood:
            $ bage = now - bl["t"]
            if bage < bl["life"]:
                add "gui/rp/blood_%d.png" % bl["img"] at blood_fx(bl["z"] * (0.55 + min(bage, 0.3) * 1.6), bl["rot"], max(0.0, 1.0 - bage / bl["life"])) pos (bl["x"], bl["y"])
        if now < me.hit_until:
            add "gui/rp/blood_vignette.png"
        elif me.hp < me.hp_max * 0.3:
            add "gui/rp/blood_vignette.png" alpha (0.55 + 0.3 * math.sin(now * 6))

    # 체력 바
    frame:
        style "rp_panel"
        xpos 24
        ypos 20
        xsize 730'''),
])

# 설정: 유혈 표현 / 거친 대사 토글
patch(root / "rpg" / "settings.rpy", [
    ('''                        use toggle_row("전투 기록", "오른쪽 아래 전투 로그", "opt_log")''',
     '''                        use toggle_row("전투 기록", "오른쪽 아래 전투 로그", "opt_log")
                        use toggle_row("유혈 표현", "맞을 때 피가 튀는 연출", "opt_blood")
                        use toggle_row("거친 대사", "보스 외침과 대사에 거친 말투", "opt_rude")'''),
])

# 허브 분기 (script.rpy)
patch(root / "script.rpy", [
    ('''    elif _return == "ranking":''', '''    elif _return == "heroine":
        call heroine_flow
    elif _return == "auction":
        call auction_flow
    elif _return == "bag":
        call bag_flow
    elif _return == "ranking":'''),
])
print("patched")
