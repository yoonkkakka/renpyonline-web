# 레이드 보스 패턴(연타/파쇄/분노) 문자열

translate tchinese strings:

    old "!! 파쇄 — 지금 방어! (Space) !!"
    new "!! 粉碎 — 現在防禦！(Space) !!"

    old "연속 공격!"
    new "連續攻擊！"

    old "완벽 방어!"
    new "完美防禦！"

    old " (연타)"
    new "（連擊）"

    old "연타 예고!"
    new "連擊預告！"

    old "분노 상태"
    new "暴怒狀態"

    old "크아악!! 이제부터 진심이다!"
    new "啊啊啊！！現在才是認真的！"

    old "보스가 분노했다! 공격이 빨라진다!"
    new "Boss暴怒了！攻擊變快了！"

    old "파쇄를 막았다! 보스가 휘청거린다!"
    new "擋住了粉碎！Boss踉蹌了！"
