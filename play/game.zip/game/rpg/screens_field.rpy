# 실시간 오픈필드 화면 (PC 빌드 전용)

screen field_sprite_upload_screen():
    modal True
    add "images/bg/t08.webp"
    add Solid("#2a1d5ad0")
    frame:
        style "rp_panel"
        align (0.5, 0.5)
        xsize 900
        padding (50, 40)
        vbox:
            spacing 20
            xfill True
            text _("필드 캐릭터 이미지") style "rp_text" size 44 xalign 0.5 color "#fff3a8"
            text _("필드에서 다른 사람에게 보일 8방향 캐릭터 이미지를 올려 주세요.\n3x3 격자 이미지(가로=세로, 가운데 칸이 정면)로 준비하면 자동으로 8방향으로 잘려요.\n올리지 않으면 기본 텍스쳐가 사용돼요.") style "rp_text" size 24 color "#dcd4ff" xalign 0.5 text_align 0.5
            add Transform("images/field/%s_s.png" % field_default_prefix(G.player["username"]), fit="contain", xysize=(180, 180)) xalign 0.5
            hbox:
                xalign 0.5
                spacing 20
                textbutton _("이미지 업로드"):
                    style "rp_btn_mint"
                    xsize 320
                    text_size 30
                    action Function(field_upload_and_continue)
                textbutton _("기본 텍스쳐로 시작"):
                    style "rp_button"
                    xsize 320
                    text_size 30
                    action Return("skip")
            textbutton _("기본 텍스쳐 다운로드"):
                style "rp_btn_pink"
                xalign 0.5
                xsize 320
                text_size 24
                action Function(download_default_field_texture)

screen field_screen():
    default chat_text = ""
    $ cam_x = max(0, min(FIELD_MAP_W - config.screen_width, int(FIELD.x - config.screen_width / 2)))
    $ cam_y = max(0, min(FIELD_MAP_H - config.screen_height, int(FIELD.y - config.screen_height / 2)))
    timer 0.05 repeat True action Function(field_tick)
    key "game_menu" action Show("field_leave_confirm_screen")
    key "K_RETURN" action [Function(field_send_chat_var, chat_text), SetScreenVariable("chat_text", "")]

    add Solid("#1a1230")
    add Transform("images/field/map01.webp", fit="cover", xysize=(FIELD_MAP_W, FIELD_MAP_H)) pos (-cam_x, -cam_y)

    # 몬스터
    for mo in FIELD.monsters.values():
        if mo["alive"]:
            $ mx, my = int(mo["x"] - cam_x), int(mo["y"] - cam_y)
            if -150 < mx < config.screen_width + 150 and -150 < my < config.screen_height + 150:
                button:
                    pos (mx - 90, my - 90)
                    xysize (180, 225)
                    background None
                    action Function(field_hit_monster, mo["id"])
                    add "images/boss/s%02d.png" % boss_meta(mo["boss_id"])["sprite"] fit "contain" xysize (165, 165) align (0.5, 0.0)
                    bar value StaticValue(mo["hp"], mo["hp_max"]) xsize 150 ysize 14 pos (15, 168) left_bar pill("#e0475b") right_bar pill("track") thumb None
                    text mo["name"] style "rp_text" size 22 xalign 0.5 ypos 188

    # 다른 플레이어 + 나
    for pid, pl in FIELD.players.items():
        $ px, py = int(pl["x"] - cam_x), int(pl["y"] - cam_y)
        if -130 < px < config.screen_width + 130 and -130 < py < config.screen_height + 130:
            $ is_me = pid == FIELD.me
            $ sp = fetch_field_sprite(pid)
            if is_me:
                add field_sprite_frame(sp, FIELD.facing, G.player["username"]) fit "contain" xysize (150, 150) pos (px - 75, py - 75)
                text G.player["username"] style "rp_text" size 22 color "#fff3a8" xpos px xanchor 0.5 ypos (py - 96) text_align 0.5
            else:
                button:
                    pos (px - 75, py - 116)
                    xysize (150, 180)
                    background None
                    action Show("field_attack_confirm_screen", pid=pid, name=pl["name"])
                    add field_sprite_frame(sp, pl.get("facing", "s"), pl["name"]) fit "contain" xysize (150, 150) pos (0, 30)
                    text (pl["name"] + ("  ☠" if pl["karma"] >= 20 else "")) style "rp_text" size 22 color ("#ff8080" if pl["karma"] >= 20 else "#ffffff") xalign 0.5 text_align 0.5
                    bar value StaticValue(pl["hp"], pl["hp_max"]) xsize 130 ysize 12 pos (10, 22) left_bar pill("#47d16b") right_bar pill("track") thumb None

    # 상단 상태 표시
    frame:
        style "rp_panel"
        xpos 20
        ypos 20
        padding (20, 12)
        vbox:
            spacing 4
            text (_("채널 %d") % FIELD.channel) style "rp_text" size 24 color "#fff3a8"
            text (_("체력 %s / %s") % (fmt(FIELD.hp), fmt(FIELD.hp_max))) style "rp_text" size 20
            bar value StaticValue(FIELD.hp, FIELD.hp_max) xsize 240 ysize 16 left_bar pill("#47d16b") right_bar pill("track") thumb None
            text (_("카르마 %d") % FIELD.karma) style "rp_text" size 18 color ("#ff8080" if FIELD.karma >= 20 else "#c7b6ff")
            textbutton (_("자동사냥 ON") if FIELD.auto_hunt else _("자동사냥 OFF")):
                style ("rp_btn_mint" if FIELD.auto_hunt else "rp_button")
                xsize 220
                text_size 22
                action Function(field_toggle_auto_hunt)

    textbutton _("나가기"):
        style "rp_btn_pink"
        xalign 1.0
        xoffset -20
        ypos 20
        text_size 24
        action Show("field_leave_confirm_screen")

    # 채팅
    frame:
        style "rp_panel"
        xpos 20
        yalign 1.0
        yoffset -20
        xsize 560
        ysize 220
        padding (16, 10)
        vbox:
            spacing 2
            yfill True
            viewport:
                ysize 150
                scrollbars "vertical"
                mousewheel True
                vbox:
                    spacing 1
                    for c in FIELD.chat[-30:]:
                        text ("%s: %s" % (c["name"], c["text"])) style "rp_text" size 18 color "#f0e8ff"
            hbox:
                spacing 8
                input value ScreenVariableInputValue("chat_text") length 80 style "rp_text" size 20 xsize 420 color "#fff4e4"
                textbutton _("전송") style "rp_button" xsize 90 text_size 20 action [Function(field_send_chat_var, chat_text), SetScreenVariable("chat_text", "")]

    # 조이스틱(좌하단)
    add "gui/rp/panel.png" xysize (FIELD_JOY_RADIUS * 2 + 20, FIELD_JOY_RADIUS * 2 + 20) pos (150 - FIELD_JOY_RADIUS - 10, config.screen_height - 150 - FIELD_JOY_RADIUS - 10) alpha 0.5
    $ jvx, jvy = FIELD.joy_vec
    add "gui/rp/knob.png" pos (int(150 + jvx * FIELD_JOY_RADIUS - 24), int(config.screen_height - 150 + jvy * FIELD_JOY_RADIUS - 24)) xysize (48, 48)
    text _("이동: 조이스틱 또는 WASD/방향키") style "rp_text" size 16 color "#dcd4ff" pos (60, config.screen_height - 40)

    if not FIELD.connected:
        add Solid("#000000c0")
        text _("연결이 끊어졌어요.") style "rp_text" size 40 xalign 0.5 yalign 0.45 color "#ff8080"
        textbutton _("확인") style "rp_btn_mint" xalign 0.5 yalign 0.55 xsize 300 text_size 30 action Return("disconnected")

screen field_attack_confirm_screen(pid, name):
    modal True
    add Solid("#00000090")
    frame:
        style "rp_panel"
        align (0.5, 0.5)
        xsize 600
        padding (40, 30)
        vbox:
            spacing 18
            xfill True
            text (_("%s 님을 공격할까요?") % name) style "rp_text" size 32 xalign 0.5
            text _("PK는 어디서나 누구든 공격할 수 있어요. 죽이면 카르마가 오르고, 카르마가 높으면 이름이 빨갛게 표시돼요.") style "rp_text" size 20 color "#dcd4ff" xalign 0.5 text_align 0.5
            hbox:
                xalign 0.5
                spacing 20
                textbutton _("공격") style "rp_btn_pink" xsize 200 text_size 28 action [Function(FIELD.attack, pid), Hide("field_attack_confirm_screen")]
                textbutton _("신고") style "rp_button" xsize 200 text_size 28 action [Function(FIELD.report, pid, "PK 신고"), Hide("field_attack_confirm_screen")]
                textbutton _("취소") style "rp_button" xsize 200 text_size 28 action Hide("field_attack_confirm_screen")

screen field_leave_confirm_screen():
    modal True
    add Solid("#00000090")
    frame:
        style "rp_panel"
        align (0.5, 0.5)
        xsize 560
        padding (40, 30)
        vbox:
            spacing 18
            xfill True
            text _("필드에서 나갈까요?") style "rp_text" size 32 xalign 0.5
            hbox:
                xalign 0.5
                spacing 20
                textbutton _("나가기") style "rp_btn_pink" xsize 220 text_size 28 action Return("leave")
                textbutton _("취소") style "rp_button" xsize 220 text_size 28 action Hide("field_leave_confirm_screen")
