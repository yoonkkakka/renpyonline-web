﻿# TODO: Translation updated at 2026-09-28 16:13

translate schinese strings:

    # game/rpg/api.rpy:51
    old "서버에 연결할 수 없어요. 잠시 후 다시 시도해 주세요."
    new "无法连接服务器。请稍后再试。"

    # game/rpg/api.rpy:53
    old "알 수 없는 오류"
    new "未知错误"

    # game/rpg/api.rpy:104
    old "아이디와 비밀번호를 입력하세요."
    new "请输入账号和密码。"

    # game/rpg/api.rpy:156
    old "이미지"
    new "图片"

    # game/rpg/api.rpy:156
    old "모든 파일"
    new "所有文件"

    # game/rpg/api.rpy:157
    old "전신 일러스트 선택"
    new "选择全身插画"

    # game/rpg/api.rpy:187
    old "이미지를 충분히 줄일 수 없습니다. 더 작은 이미지를 사용하세요."
    new "无法将图片缩小到足够小。请使用更小的图片。"

    # game/rpg/api.rpy:191
    old "이 기기에서는 일러스트 등록을 지원하지 않아요. PC에서 등록하면 여기서도 보여요!"
    new "这台设备不支持插画上传。请在PC上注册后，这里也会显示！"

    # game/rpg/api.rpy:202
    old "이미지를 읽을 수 없습니다."
    new "无法读取图片。"

    # game/rpg/api.rpy:206
    old "전신 일러스트가 등록되었습니다."
    new "全身插画已注册。"

    # game/rpg/api.rpy:215
    old "대성공!! 2단계 상승!"
    new "大成功!! 提升2个阶段!"

    # game/rpg/api.rpy:215
    old "강화 성공!"
    new "强化成功!"

    # game/rpg/api.rpy:232
    old "수령: 경험치 %s, 골드 %s, 강화석 %s"
    new "领取：经验值 %s，金币 %s，强化石 %s"

    # game/rpg/api.rpy:234
    old " (레벨 +%d!)"
    new "（等级 +%d！）"

