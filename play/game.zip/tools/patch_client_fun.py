"""기존 Ren'Py 파일에 콤보 / 대성공 알림을 반영하는 일회성 패치."""
from pathlib import Path

root = Path(__file__).resolve().parent.parent / "game" / "rpg"

# api.rpy: 신체 강화 대성공 알림
p = root / "api.rpy"
s = p.read_text(encoding="utf-8")
old = '''        if safe(api, "POST", "/api/body/upgrade", {"part": part}):
            renpy.notify("강화 성공!")'''
new = '''        res = safe(api, "POST", "/api/body/upgrade", {"part": part})
        if res:
            renpy.notify("대성공!! 2단계 상승!" if res.get("jackpot") else "강화 성공!")'''
assert old in s
p.write_text(s.replace(old, new), encoding="utf-8")

# battle.rpy: 콤보
p = root / "battle.rpy"
s = p.read_text(encoding="utf-8")
reps = [
    ('''            self.player_hit_until = 0.0
            self.boss_hit_until = 0.0
            self.bg_path''', '''            self.player_hit_until = 0.0
            self.boss_hit_until = 0.0
            self.combo = 0
            self.last_cast = 0.0
            self.bg_path'''),
    ('''            self.floaters = [f for f in self.floaters if now - f["t"] < 1.0]
            if now - self.t0 >= self.limit:''', '''            self.floaters = [f for f in self.floaters if now - f["t"] < 1.0]
            if self.combo and now - self.last_cast > G.meta["combo"]["window"]:
                self.combo = 0
            if now - self.t0 >= self.limit:'''),
    ('''            total = 0
            crits = 0
            for _ in range(sk["hits"]):
                d = self.st["atk"] * sk["mult"] * random.uniform(0.9, 1.1)''', '''            cb = G.meta["combo"]
            bonus = (1.0 + cb["step"] * self.combo) if sk["hits"] else 1.0
            self.combo = min(cb["max"], self.combo + 1)
            self.last_cast = now
            total = 0
            crits = 0
            for _ in range(sk["hits"]):
                d = self.st["atk"] * sk["mult"] * bonus * random.uniform(0.9, 1.1)'''),
]
for old, new in reps:
    assert old in s, old[:40]
    s = s.replace(old, new, 1)
p.write_text(s, encoding="utf-8")
print("patched")
