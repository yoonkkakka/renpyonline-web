# 귀여운 모바일 게임풍 UI 스킨 (에셋: tools/make_ui_assets.py 로 생성 -> game/gui/rp/)

init -20 python:
    def rp_frame(name, l=34, t=34, r=None, b=None, **kw):
        return Frame("gui/rp/%s.png" % name, l, t, r if r is not None else l, b if b is not None else t, **kw)

    _PILL_MAP = {
        "#e0475b": "red", "#ff3030": "red", "#ff6b6b": "red",
        "#47d16b": "green",
        "#4d8dff": "blue", "#5fd0ff": "blue", "#5fb8ff": "blue",
        "#ffe066": "yellow", "#ffb84d": "orange",
        "#ff8fd0": "pink",
    }

    def pill(color):
        """바 색상(hex) -> 둥근 캔디 바 이미지. 트랙은 'track' 계열 색을 넘긴다."""
        key = _PILL_MAP.get(color)
        if key is None:
            key = "track"
        name = "pill_track" if key == "track" else "pill_" + key
        return Frame("gui/rp/%s.png" % name, 14, 14, 14, 14)

    _SLOT_COLOR = {1: "pink", 2: "orange", 3: "green", 4: "yellow", 5: "red", 6: "purple", 7: "green", 8: "blue"}

    def slot_bg(slot, locked=False):
        return "gui/rp/slot_%s.png" % ("gray" if locked else _SLOT_COLOR.get(slot, "pink"))

    def round_shade(w, h, color, r=30):
        """둥근 모서리의 반투명 색 덮개."""
        return AlphaMask(Solid(color, xysize=(w, h)), Frame("gui/rp/mask.png", r, r, r, r, xysize=(w, h)))

    def border_img(w, h, kind="white", r=30):
        return Frame("gui/rp/border_%s.png" % kind, r, r, r, r, xysize=(w, h))

    def round_clip(child, w, h, r=30):
        """child 를 w x h 둥근 모서리로 잘라 돌려준다."""
        return AlphaMask(Transform(child, fit="cover", xysize=(w, h)), Frame("gui/rp/mask.png", r, r, r, r, xysize=(w, h)))

# ── 글씨: 스티커 스타일(굵은 보라 테두리) ─────────────────────
style rp_text is text:
    font gui.text_font
    color "#fffaf2"
    size 30
    outlines [(4, "#3a2a6a", 0, 2)]

# ── 패널 / 카드 ──────────────────────────────────────────────
style rp_panel is empty:
    background Frame("gui/rp/panel.png", 40, 40, 40, 40)
    padding (30, 24)

style rp_inputbox is empty:
    background Frame("gui/rp/inputbox.png", 34, 34, 34, 34)
    padding (24, 14)
    xfill True

style rp_input is rp_text:
    color "#5a3f7a"
    outlines []

# ── 버튼(통통한 젤리) ─────────────────────────────────────────
style rp_button is button:
    background Frame("gui/rp/btn_blue.png", 34, 34, 34, 42)
    hover_background Frame("gui/rp/btn_blue_hover.png", 34, 34, 34, 42)
    selected_background Frame("gui/rp/btn_yellow.png", 34, 34, 34, 42)
    selected_hover_background Frame("gui/rp/btn_yellow_hover.png", 34, 34, 34, 42)
    insensitive_background Frame("gui/rp/btn_off.png", 34, 34, 34, 42)
    padding (26, 12, 26, 24)

style rp_button_text is rp_text:
    hover_color "#ffffff"
    insensitive_color "#b9b4d6"
    xalign 0.5
    text_align 0.5

style rp_btn_pink is rp_button:
    background Frame("gui/rp/btn_pink.png", 34, 34, 34, 42)
    hover_background Frame("gui/rp/btn_pink_hover.png", 34, 34, 34, 42)
    insensitive_background Frame("gui/rp/btn_off.png", 34, 34, 34, 42)
style rp_btn_pink_text is rp_button_text

style rp_btn_mint is rp_button:
    background Frame("gui/rp/btn_mint.png", 34, 34, 34, 42)
    hover_background Frame("gui/rp/btn_mint_hover.png", 34, 34, 34, 42)
    insensitive_background Frame("gui/rp/btn_off.png", 34, 34, 34, 42)
style rp_btn_mint_text is rp_button_text

style rp_btn_purple is rp_button:
    background Frame("gui/rp/btn_purple.png", 34, 34, 34, 42)
    hover_background Frame("gui/rp/btn_purple_hover.png", 34, 34, 34, 42)
    insensitive_background Frame("gui/rp/btn_off.png", 34, 34, 34, 42)
style rp_btn_purple_text is rp_button_text

style rp_btn_orange is rp_button:
    background Frame("gui/rp/btn_orange.png", 34, 34, 34, 42)
    hover_background Frame("gui/rp/btn_orange_hover.png", 34, 34, 34, 42)
    insensitive_background Frame("gui/rp/btn_off.png", 34, 34, 34, 42)
style rp_btn_orange_text is rp_button_text

style rp_btn_yellow is rp_button:
    background Frame("gui/rp/btn_yellow.png", 34, 34, 34, 42)
    hover_background Frame("gui/rp/btn_yellow_hover.png", 34, 34, 34, 42)
    insensitive_background Frame("gui/rp/btn_off.png", 34, 34, 34, 42)
style rp_btn_yellow_text is rp_button_text

# 카드형 버튼(목록 항목)
style rp_card_btn is button:
    background Frame("gui/rp/card.png", 30, 30, 30, 30)
    hover_background Frame("gui/rp/card_hover.png", 30, 30, 30, 30)
    selected_background Frame("gui/rp/card_purple.png", 30, 30, 30, 30)
    selected_hover_background Frame("gui/rp/card_purple.png", 30, 30, 30, 30)
    insensitive_background Frame("gui/rp/card_dim.png", 30, 30, 30, 30)
    padding (22, 12)
style rp_card_btn_text is rp_text:
    insensitive_color "#8f88bb"

transform rp_fade(a):
    alpha a

# 하트가 콩콩 뛰는 로딩용: 점프(위로 올라갔다 내려옴) + 착지할 때 납작해지는 찌그러짐
transform heart_jump(delay=0.0):
    anchor (0.5, 1.0)
    yoffset 0
    zoom 1.0
    pause delay
    block:
        parallel:
            ease 0.32 yoffset -110
            ease 0.28 yoffset 0
            pause 0.25
        parallel:
            ease 0.32 zoom 1.08
            ease 0.18 zoom 0.95
            ease 0.10 zoom 0.84
            ease 0.25 zoom 1.0
        repeat

# 유혈 이펙트: 중심 기준으로 커지며 사라지는 피 튀김
transform blood_fx(z=1.0, rot=0.0, a=1.0):
    anchor (0.5, 0.5)
    zoom z
    rotate rot
    alpha a

# 살짝 위아래로 통통 튀는 장식용
transform rp_bounce:
    ease 0.9 yoffset -8
    ease 0.9 yoffset 0
    repeat


# ── 렌파이 기본 대화창 / 선택지도 같은 스킨으로 ───────────────
init 10:
    style window:
        background Frame("gui/rp/panel.png", 40, 40, 40, 40)

    style namebox:
        background Frame("gui/rp/btn_yellow.png", 34, 34, 34, 42)
        padding (30, 8, 30, 20)

    style say_label:
        color "#5a2f86"
        outlines []

    style say_dialogue:
        color "#fffaf2"
        outlines [(3, "#3a2a6a", 0, 1)]

    style choice_button:
        background Frame("gui/rp/btn_pink.png", 34, 34, 34, 42)
        hover_background Frame("gui/rp/btn_pink_hover.png", 34, 34, 34, 42)
        padding (34, 14, 34, 28)
        xsize 1100

    style choice_button_text:
        color "#ffffff"
        hover_color "#ffffff"
        outlines [(4, "#3a2a6a", 0, 2)]
        xalign 0.5
        text_align 0.5

    style notify_frame:
        ypos 122
        xalign 0.98
        background Frame("gui/rp/btn_yellow.png", 34, 34, 34, 42)
        padding (44, 12, 44, 30)

    style notify_text:
        color "#5a2f86"
        size 30
        outlines []

    style confirm_frame:
        background Frame("gui/rp/panel.png", 40, 40, 40, 40)
        padding (70, 56, 70, 56)
        xalign 0.5
        yalign 0.5

    style confirm_prompt_text:
        color "#fffaf2"
        outlines [(4, "#3a2a6a", 0, 2)]
        text_align 0.5
        xalign 0.5
        size 38

    style confirm_button:
        background Frame("gui/rp/btn_blue.png", 34, 34, 34, 42)
        hover_background Frame("gui/rp/btn_blue_hover.png", 34, 34, 34, 42)
        padding (30, 12, 30, 26)
        xsize 220

    style confirm_button_text:
        color "#ffffff"
        outlines [(4, "#3a2a6a", 0, 2)]
        xalign 0.5
        text_align 0.5
        size 34
