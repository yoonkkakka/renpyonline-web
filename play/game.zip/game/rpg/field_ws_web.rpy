# 웹(브라우저) 빌드 전용 WebSocket 클라이언트.
# Python에는 socket/ssl이 없으므로, 브라우저 네이티브 WebSocket을 JS로 열고
# emscripten.run_script*()로 Python<->JS 메시지를 주고받는다(JS 함수는 index.html에 주입,
# tools/patch_web_index.py 참고). FieldSocket(PC, field_ws.rpy)과 동일한 인터페이스를 제공한다.
# 주의: emscripten 모듈은 PC 빌드에는 없으므로, 절대 파일 최상단(init 시점)에서 import하지 말고
# 실제로 웹에서만 호출되는 메서드 안에서 그때그때 import한다(안 그러면 PC에서 게임이 아예 안 뜬다).

init -6 python:
    import time as _wtime

    class WebFieldSocket(object):
        def __init__(self):
            self.id = None
            self.connected = False

        def connect(self, host, port, path, use_tls, timeout=15):
            import emscripten
            scheme = "wss" if use_tls else "ws"
            url = "%s://%s:%d%s" % (scheme, host, port, path)
            self.id = emscripten.run_script_int("fieldConnect(%s)" % _json.dumps(url))
            if self.id is None or self.id < 0:
                raise FieldSocketError(u"웹소켓을 열 수 없어요.")
            t0 = _wtime.time()
            while _wtime.time() - t0 < timeout:
                st = emscripten.run_script_int("fieldState(%d)" % self.id)
                if st == 1:
                    self.connected = True
                    return
                if st == 3 or st is None or st < 0:
                    raise FieldSocketError(u"웹소켓 연결에 실패했어요.")
                renpy.pause(0.05, hard=True)
            raise FieldSocketError(u"연결 시간이 초과됐어요.")

        def send_json(self, obj):
            if self.id is None:
                return
            try:
                import emscripten
                text = _json.dumps(obj)
                emscripten.run_script("fieldSend(%d, %s)" % (self.id, _json.dumps(text)))
            except Exception:
                self.connected = False

        def poll(self):
            if self.id is None:
                return []
            try:
                import emscripten
                raw = emscripten.run_script_string("fieldPoll(%d)" % self.id)
                items = _json.loads(raw) if raw else []
            except Exception:
                return []
            out = []
            for it in items:
                if it == "__CLOSED__":
                    self.connected = False
                    out.append({"t": "_closed"})
                    continue
                try:
                    out.append(_json.loads(it))
                except Exception:
                    pass
            return out

        def close(self):
            if self.id is not None:
                try:
                    import emscripten
                    emscripten.run_script("fieldClose(%d)" % self.id)
                except Exception:
                    pass
            self.connected = False
