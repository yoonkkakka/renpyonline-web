# PVP / 일일 미션 / 출석 / 랭킹용 API 도우미

init -9 python:
    G.opps = []
    G.pvp_log = []
    G.daily = None
    G.ranking = None

    def refresh_pvp():
        res = safe(api, "GET", "/api/pvp/opponents")
        if res:
            G.opps = res["opponents"]
        res = safe(api, "GET", "/api/pvp/log")
        if res:
            G.pvp_log = res["log"]
        safe(api, "GET", "/api/me")

    def pvp_exchange(n):
        if safe(api, "POST", "/api/pvp/exchange", {"stones": n}):
            renpy.notify("강화석 %d개로 교환했습니다." % n)

    def refresh_daily():
        res = safe(api, "GET", "/api/daily")
        if res:
            G.daily = res
        safe(api, "GET", "/api/me")

    def claim_mission(mid):
        res = safe(api, "POST", "/api/daily/claim", {"id": mid})
        if res:
            g = res["got"]
            extra = (", 각성 결정 %d" % g["crystals"]) if g.get("crystals") else ""
            renpy.notify("보상: 골드 %s, 강화석 %s%s" % (fmt(g["gold"]), fmt(g["stones"]), extra))
            refresh_daily()

    def do_checkin():
        res = safe(api, "POST", "/api/checkin")
        if res:
            rw = res["reward"]
            msg = "%d일차 출석! 골드 %s, 강화석 %d" % (rw["day"], fmt(rw["gold"]), rw["stones"])
            if rw["boost_seconds"]:
                msg += ", 경험치 부스트 1시간"
            renpy.notify(msg)
            refresh_daily()

    def refresh_ranking():
        res = safe(api, "GET", "/api/ranking")
        if res:
            G.ranking = res

    def time_ago(t):
        d = max(0, int(time.time() - t))
        if d < 60:
            return "방금 전"
        if d < 3600:
            return "%d분 전" % (d // 60)
        if d < 86400:
            return "%d시간 전" % (d // 3600)
        return "%d일 전" % (d // 86400)

    def checkin_days(ck):
        """이번 7일 주기에서 이미 채운 칸 수."""
        if ck["streak"] <= 0:
            return 0
        day = (ck["streak"] - 1) % 7 + 1
        if ck["ready"] and day == 7:
            return 0     # 7일을 채웠으면 새 주기 시작
        return day

    def rarity_color(r):
        return {"일반": "#c9d5f0", "희귀": "#6fc3ff", "영웅": "#c58bff", "전설": "#ffb347"}.get(r, "#ffffff")

    def awake_cost(a):
        c = G.meta["awake"]["costs"][a]
        return c["gold"], c["crystals"]

    def upgrade_awake(part):
        if safe(api, "POST", "/api/awake/upgrade", {"part": part}):
            renpy.notify("각성 성공!")
