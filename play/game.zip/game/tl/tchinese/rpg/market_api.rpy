﻿# TODO: Translation updated at 2026-09-28 16:26

translate tchinese strings:

    # game/rpg/market_api.rpy:12
    old "%d시간 %d분"
    new "%d小時%d分鐘"

    # game/rpg/market_api.rpy:13
    old "%d분 %d초"
    new "%d分%d秒"

    # game/rpg/market_api.rpy:23
    old "구매했어요!"
    new "購買成功!"

    # game/rpg/market_api.rpy:28
    old "경험치 부스트 30분!"
    new "經驗加成30分鐘!"

    # game/rpg/market_api.rpy:34
    old "%s 골드를 받았어요."
    new "獲得了 %s 金幣。"

    # game/rpg/market_api.rpy:65
    old "입찰했어요! (밀려나면 골드가 돌아와요)"
    new "已出價!（被超越時金幣會退還）"

    # game/rpg/market_api.rpy:70
    old "즉시 구매 완료!"
    new "已完成一口價購買!"

    # game/rpg/market_api.rpy:76
    old "경매를 취소했어요."
    new "已取消拍賣。"

    # game/rpg/market_api.rpy:83
    old "경매에 올렸어요!"
    new "已上架拍賣!"

    # game/rpg/market_api.rpy:105
    old "호감도 +%d"
    new "好感度 +%d"

    # game/rpg/market_api.rpy:125
    old "기념품 획득: "
    new "獲得紀念品："

