﻿# TODO: Translation updated at 2026-09-28 16:13

translate schinese strings:

    # game/script.rpy:12
    old "게임을 불러오는 중"
    new "正在加载游戏"

    # game/script.rpy:12
    old "잠시만 기다려 주세요"
    new "请稍候片刻"

