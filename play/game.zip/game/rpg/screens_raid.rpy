# 레이드 보스 화면: 대상 선택 / 매칭 대기 / 협동 전투 / 결과

screen raid_boss_select():
    $ p = G.player
    add "images/bg/t08.webp"
    add Solid("#2a1d5ab0")
    use topbar
    viewport:
        xpos 40
        ypos 128
        xsize 1850
        ysize 800
        mousewheel True
        scrollbars "vertical"
        draggable True
        vpgrid:
            cols 4
            spacing 20
            for b in G.meta["bosses"]:
                if b["raid"]:
                    $ locked = p["level"] < b["min_level"]
                    $ cl = p["clears"].get(str(b["id"]), 0)
                    button:
                        background None
                        xysize (440, 260)
                        action (NullAction() if locked else Return(b["id"]))
                        add round_clip("images/bg/t%02d.webp" % b["bg"], 440, 260)
                        add "images/boss/s%02d.png" % b["sprite"] fit "contain" xysize (250, 230) xalign 0.97 yalign 1.0 matrixcolor (BrightnessMatrix(-0.6) if locked else IdentityMatrix())
                        if locked:
                            add round_shade(440, 260, "#2a1d5acc")
                        add border_img(440, 260, "gray" if locked else "purple")
                        vbox:
                            xpos 18
                            ypos 12
                            spacing 0
                            text ("%d. %s" % (b["id"], b["name"])) style "rp_text" size 30 color "#fff1a8"
                            text (_("권장 Lv.%d") % b["min_level"]) style "rp_text" size 24 color ("#ffb0b0" if locked else "#c7b6ff")
                        vbox:
                            xpos 18
                            yalign 0.95
                            spacing 0
                            text _("레이드 2~4인(혼자도 가능)") style "rp_text" size 22 color "#ffd6ec"
                            text (_("처치 %d회") % cl) style "rp_text" size 20 color "#f0e8ff"
                        if locked:
                            text "LOCK" style "rp_text" size 50 align (0.5, 0.42) color "#ffd6ec"
    use back_button

screen raid_mode_screen(boss_id):
    modal True
    $ bm = boss_meta(boss_id)
    add "images/bg/t%02d.webp" % bm["bg"]
    add Solid("#2a1d5ab8")
    frame:
        style "rp_panel"
        align (0.5, 0.5)
        xsize 760
        padding (50, 40)
        vbox:
            spacing 22
            xfill True
            text bm["name"] style "rp_text" size 44 xalign 0.5 color "#fff3a8"
            text _("어떻게 도전할까요?") style "rp_text" size 30 xalign 0.5
            textbutton _("협동전 매칭 (2~4인)"):
                style "rp_btn_mint"
                xfill True
                text_size 30
                action Return("party")
            textbutton _("혼자 입장 (1인 기준 난이도/보상)"):
                style "rp_button"
                xfill True
                text_size 30
                action Return("solo")
            textbutton _("취소"):
                style "rp_btn_pink"
                xfill True
                text_size 26
                action Return("back")

screen raid_queue_screen(boss_id):
    $ bm = boss_meta(boss_id)
    $ elapsed = time.time() - RQ.wait_started
    timer 2.0 repeat True action Function(raid_queue_poll)
    add "images/bg/t%02d.webp" % bm["bg"]
    add Solid("#2a1d5ab8")
    frame:
        style "rp_panel"
        align (0.5, 0.5)
        xsize 900
        padding (50, 40)
        vbox:
            spacing 22
            xfill True
            text bm["name"] style "rp_text" size 48 xalign 0.5 color "#fff3a8"
            text _("레이드 매칭 대기 중...") style "rp_text" size 34 xalign 0.5
            text (_("대기 인원  %d / 4") % RQ.queue_len) style "rp_text" size 40 xalign 0.5 color "#c7b6ff"
            if RQ.queue_len >= 2:
                $ left = max(0, RQ.wait_total - elapsed)
                text (_("%.0f초 후 자동 시작 (인원이 차면 즉시 시작)") % left) style "rp_text" size 24 xalign 0.5 color "#dcd4ff"
            else:
                text _("2명 이상 모이면 카운트다운이 시작돼요.") style "rp_text" size 24 xalign 0.5 color "#dcd4ff"
            textbutton _("취소"):
                style "rp_btn_pink"
                xalign 0.5
                xsize 300
                text_size 30
                action [Function(raid_queue_leave), Return("back")]

screen raid_party_slot(m):
    frame:
        background Frame(("gui/rp/card_blue.png" if m["me"] else "gui/rp/card.png"), 30, 30, 30, 30)
        xsize 300
        ysize 82
        padding (16, 8)
        vbox:
            spacing 2
            hbox:
                xfill True
                text (m["name"] + (_(" (나)") if m["me"] else "")) style "rp_text" size 22 color "#fff1a8" xsize 200
                text ("Lv.%d" % m["level"]) style "rp_text" size 18 color "#dcd4ff" xalign 1.0
            if m["left"]:
                text _("이탈함") style "rp_text" size 18 color "#9a92c4"
            elif not m["alive"]:
                text _("전투 불능") style "rp_text" size 18 color "#ff8080"
            else:
                text (_("기여 %s") % fmt(m["damage"])) style "rp_text" size 18 color "#b6ffca"

screen raid_battle_screen():
    $ now = time.time()
    $ bt = RB
    $ boss = bt.boss
    timer 0.05 repeat True action Function(rd_tick)
    timer 1.5 repeat True action Function(rd_report)
    key "K_1" action Function(rd_skill, 1)
    key "K_2" action Function(rd_skill, 2)
    key "K_3" action Function(rd_skill, 3)
    key "K_4" action Function(rd_skill, 4)
    key "K_5" action Function(rd_skill, 5)
    key "K_6" action Function(rd_skill, 6)
    key "K_7" action Function(rd_skill, 7)
    key "K_8" action Function(rd_skill, 8)
    key "K_KP1" action Function(rd_skill, 1)
    key "K_KP2" action Function(rd_skill, 2)
    key "K_KP3" action Function(rd_skill, 3)
    key "K_KP4" action Function(rd_skill, 4)
    key "K_KP5" action Function(rd_skill, 5)
    key "K_KP6" action Function(rd_skill, 6)
    key "K_KP7" action Function(rd_skill, 7)
    key "K_KP8" action Function(rd_skill, 8)
    key "K_SPACE" action Function(rd_guard)
    key "game_menu" action Function(rd_flee)

    add bt.bg_path
    add bt.sprite_path:
        fit "contain"
        xysize (760, 660)
        align (0.86, 0.62)
        xoffset (random.randint(-10, 10) if (persistent.opt_shake and now < bt.boss_hit_until) else 0)
        alpha (0.65 if now < bt.boss_hit_until else 1.0)
    if bt.alive:
        add avatar_disp(480, 680):
            pos (70, 210)
            xoffset (random.randint(-8, 8) if (persistent.opt_shake and now < bt.player_hit_until) else 0)
            alpha (0.7 if bt.guarding() else 1.0)
        if bt.guarding():
            add Solid("#8fd0ff40") xysize (480, 680) pos (70, 210)
        if now < bt.player_hit_until:
            add Solid("#ff5a8a30")
    else:
        add avatar_disp(480, 680) pos (70, 210) matrixcolor BrightnessMatrix(-0.7)
        text _("전투 불능") style "rp_text" size 40 xpos 130 ypos 500 color "#ff8080"

    if persistent.opt_blood:
        for st in bt.stains:
            add "gui/rp/blood_%d.png" % st["img"] at blood_fx(st["z"], st["rot"], 0.42) pos (st["x"], st["y"])
        for bl in bt.blood:
            $ bage = now - bl["t"]
            if bage < bl["life"]:
                add "gui/rp/blood_%d.png" % bl["img"] at blood_fx(bl["z"] * (0.55 + min(bage, 0.3) * 1.6), bl["rot"], max(0.0, 1.0 - bage / bl["life"])) pos (bl["x"], bl["y"])
        if now < bt.player_hit_until:
            add "gui/rp/blood_vignette.png"
    if bt.shout and now < bt.shout_until:
        frame:
            style "rp_panel"
            xalign 0.78
            ypos 250
            padding (26, 14)
            text bt.shout style "rp_text" size 34 color "#ffb0b0" outlines [(6, "#4a0a1a", 0, 2)]

    # 보스 체력(공유)
    frame:
        style "rp_panel"
        xalign 0.5
        ypos 20
        xsize 1240
        padding (30, 14)
        vbox:
            spacing 4
            hbox:
                xfill True
                text ("Lv.%d  %s" % (boss["level"], boss["name"])) style "rp_text" size 36 color "#fff1a8"
                text ("%s / %s" % (fmt(bt.boss_hp), fmt(bt.boss_max))) style "rp_text" size 28 xalign 1.0
            bar value StaticValue(bt.boss_hp, bt.boss_max) xsize 1180 ysize 28 left_bar pill("#c060ff") right_bar pill("track") thumb None
            hbox:
                spacing 16
                if bt.next_is_heavy():
                    text _("!! 강공격 준비 !!") style "rp_text" size 24 color "#ffb0b0"
                else:
                    text (_("다음 공격: %s") % boss["attack"]) style "rp_text" size 24 color "#f0e8ff"
                bar value StaticValue(bt.charge(), 1.0) xsize 700 ysize 16 yalign 0.5 left_bar pill("#ff3030" if bt.next_is_heavy() else "#ffb84d") right_bar pill("track") thumb None
    hbox:
        xalign 1.0
        xoffset -30
        ypos 20
        use chip("gui/rp/icon_gem.png", fmt_time(int(bt.time_left())), "#ffffff")
    if bt.combo >= 2:
        text ("COMBO x%d   +%d%%" % (bt.combo, int(G.meta["combo"]["step"] * 100 * bt.combo))) style "rp_text" size 56 color "#fff1a8" xalign 0.5 ypos 196 outlines [(8, "#c2437a", 0, 3)]
    textbutton _("도망 (Esc)"):
        style "rp_btn_pink"
        xpos 30
        ypos 24
        text_size 24
        action Function(rd_flee)

    # 파티 현황(좌측)
    vbox:
        xpos 24
        ypos 140
        spacing 8
        for m in bt.party:
            use raid_party_slot(m)

    # 플레이어 상태
    frame:
        style "rp_panel"
        xpos 24
        yalign 1.0
        yoffset -20
        xsize 440
        padding (26, 16)
        vbox:
            spacing 4
            text (_("체력 %s / %s") % (fmt(bt.hp), fmt(bt.hp_max))) style "rp_text" size 26
            bar value StaticValue(bt.hp, bt.hp_max) xsize 386 ysize 24 left_bar pill("#47d16b") right_bar pill("track") thumb None
            text (_("기력 %d / %d") % (bt.mana, bt.st["mana"])) style "rp_text" size 24 color "#d4e4ff"
            bar value StaticValue(bt.mana, bt.st["mana"]) xsize 386 ysize 18 left_bar pill("#4d8dff") right_bar pill("track") thumb None
    hbox:
        xpos 490
        yalign 1.0
        yoffset -20
        spacing 10
        for sk in G.meta["skills"]:
            use skill_slot(sk, bt)
        use guard_slot(bt)
    vbox:
        xalign 1.0
        xoffset -30
        yalign 1.0
        yoffset -170
        spacing 2
        for (t, c) in (bt.log if persistent.opt_log else []):
            text t style "rp_text" size 22 color c xalign 1.0
    for f in (bt.floaters if persistent.opt_floaters else []):
        $ age = now - f["t"]
        $ ft = f["text"]
        text ft at rp_fade(max(0.0, 1.0 - max(0.0, age - 0.5) * 2.0)):
            style "rp_text"
            size f["size"]
            color f["color"]
            bold True
            outlines [(6, "#3a2a6a", 0, 2)]
            xpos f["x"]
            ypos int(f["y"] - age * 110)

screen raid_result(outcome, fin):
    modal True
    add RB.bg_path
    add Solid("#2a1d5acc")
    frame:
        style "rp_panel"
        align (0.5, 0.5)
        xsize 800
        padding (54, 40)
        vbox:
            spacing 14
            xfill True
            if outcome == "win" and fin:
                $ rw = fin["rewards"]
                text _("레이드 승리!") style "rp_text" size 88 xalign 0.5 color "#fff3a8" outlines [(10, "#7a3ac2", 0, 4)]
                text (_("내 기여도  %.0f%%") % (fin["share"] * 100)) style "rp_text" size 32 xalign 0.5 color "#c7b6ff"
                text (_("경험치 +%s") % fmt(rw["exp"])) style "rp_text" size 36 xalign 0.5
                hbox:
                    xalign 0.5
                    spacing 10
                    add "gui/rp/icon_coin.png" yalign 0.5
                    text (_("골드 +%s") % fmt(rw["gold"])) style "rp_text" size 36 color "#ffe27a"
                hbox:
                    xalign 0.5
                    spacing 10
                    add "gui/rp/icon_gem.png" yalign 0.5
                    text (_("강화석 +%d") % rw["stones"]) style "rp_text" size 36 color "#e3d0ff"
                if rw.get("crystals"):
                    hbox:
                        xalign 0.5
                        spacing 10
                        add "gui/rp/icon_crystal.png" yalign 0.5
                        text (_("각성 결정 +%d") % rw["crystals"]) style "rp_text" size 36 color "#ffc0ea"
                if fin["level_ups"]:
                    text (_("레벨 UP!  Lv.%d") % fin["player"]["level"]) style "rp_text" size 46 xalign 0.5 color "#b6ffca"
            elif outcome == "win":
                text _("보스는 쓰러졌지만 보상 수령에 실패했어요.") style "rp_text" size 32 xalign 0.5 color "#ffb0b0"
            elif outcome == "wipe":
                text _("전멸했어요...") style "rp_text" size 80 xalign 0.5 color "#ffb0c8"
                text _("신체를 더 강화하고 다시 도전해요!") style "rp_text" size 28 xalign 0.5
            elif outcome == "timeout":
                text _("시간 초과로 레이드가 종료됐어요.") style "rp_text" size 44 xalign 0.5 color "#ffb0c8"
            else:
                text _("레이드에서 물러났어요") style "rp_text" size 56 xalign 0.5
            textbutton _("확인") style "rp_btn_mint" xfill True text_size 38 action Return(True)
