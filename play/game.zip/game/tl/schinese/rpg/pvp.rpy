﻿# TODO: Translation updated at 2026-09-28 16:13

translate schinese strings:

    # game/rpg/pvp.rpy:123
    old "%s: %s 체력 %s 회복"
    new "%s：%s 恢复体力 %s"

    # game/rpg/pvp.rpy:133
    old "%s: %s %s 피해"
    new "%s：%s %s 伤害"

    # game/rpg/pvp.rpy:151
    old "시간 초과! (무승부는 패배)"
    new "时间到!（平局判负）"

    # game/rpg/pvp.rpy:184
    old "승리!"
    new "胜利!"

    # game/rpg/pvp.rpy:187
    old "패배..."
    new "败北…"

