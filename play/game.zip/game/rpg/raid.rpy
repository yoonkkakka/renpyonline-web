# 레이드 보스: 2~4인 자동 매칭 협동전. 각자 로컬에서 전투를 시뮬레이션하고,
# 보스 체력만 주기적으로 서버에 보고/동기화한다(서버가 데미지를 구간별로 검증).

init -5 python:
    class RaidBattle(object):
        def __init__(self, res, bm):
            self.room_id = res["room_id"]
            self.st = G.player["stats"]
            self.boss = res["boss"]
            self.bm = bm
            self.level = G.player["level"]
            self.skills = G.meta["skills"]
            self.guard = G.meta["guard"]
            now = time.time()
            self.t0 = now
            self.last = now
            self.boss_hp = float(self.boss["hp"])
            self.boss_max = float(self.boss["hp"])
            self.hp = float(self.st["hp"])
            self.hp_max = float(self.st["hp"])
            self.mana = float(self.st["mana"])
            self.ready = dict((s["slot"], 0.0) for s in self.skills)
            self.guard_until = 0.0
            self.guard_ready = 0.0
            self.boss_next = now + 2.0
            self.boss_n = 0
            self.floaters = []
            self.log = []
            self.result = None
            self.alive = True
            self.player_hit_until = 0.0
            self.boss_hit_until = 0.0
            self.combo = 0
            self.last_cast = 0.0
            self.blood = []
            self.stains = []
            self.shout = ""
            self.shout_until = 0.0
            self.shouted = set()
            self.bg_path = "images/bg/t%02d.webp" % bm["bg"]
            self.sprite_path = "images/boss/s%02d.png" % bm["sprite"]
            self.pending_damage = 0.0
            self.party = res.get("party") or []
            self.server_time_left = res.get("time_left", 300)
            self.server_time_left_t = now
            self.last_report = now

        # ── 유혈 / 외침 ─────────────────────────
        def splash(self, n=1, big=False, boss=True):
            if not persistent.opt_blood:
                return
            now = time.time()
            cx, cy = (1240, 430) if boss else (300, 450)
            for _i in range(n):
                self.blood.append({"t": now, "x": cx + random.randint(-150, 150), "y": cy + random.randint(-160, 160),
                                   "img": random.randint(1, 4), "z": random.uniform(0.7, 1.5) * (1.4 if big else 1.0),
                                   "rot": random.randint(0, 359), "life": 1.1})
            if boss and (big or random.random() < 0.35):
                self.stains.append({"x": cx + random.randint(-260, 260), "y": cy + random.randint(-200, 220),
                                    "img": random.randint(1, 4), "z": random.uniform(0.6, 1.2), "rot": random.randint(0, 359)})
                self.stains = self.stains[-16:]

        def check_shout(self):
            frac = self.boss_hp / self.boss_max
            data = BOSS_SHOUTS.get(self.boss["id"])
            if not data:
                return
            for i, th in enumerate((0.7, 0.4, 0.1)):
                if frac <= th and i not in self.shouted:
                    self.shouted.add(i)
                    self.shout = data["rude" if persistent.opt_rude else "clean"][i]
                    self.shout_until = time.time() + 3.6
                    self.add_log(self.boss["name"] + ": " + self.shout, "#ffb0b0")
                    break

        # ── 조회 ────────────────────────────────
        def cd_left(self, slot):
            return max(0.0, self.ready[slot] - time.time())

        def guard_left(self):
            return max(0.0, self.guard_ready - time.time())

        def guarding(self):
            return time.time() < self.guard_until

        def charge(self):
            iv = self.boss["interval"]
            return max(0.0, min(1.0, 1.0 - (self.boss_next - time.time()) / iv))

        def next_is_heavy(self):
            return (self.boss_n + 1) % self.boss["heavy_every"] == 0

        def time_left(self):
            return max(0.0, self.server_time_left - (time.time() - self.server_time_left_t))

        # ── 내부 ────────────────────────────────
        def add_log(self, text, color="#dfe8ff"):
            self.log.append((text, color))
            self.log = self.log[-7:]

        def float_text(self, text, x, y, color="#ffffff", size=44):
            self.floaters.append({"text": text, "x": x + random.randint(-40, 40), "y": y,
                                  "color": color, "size": size, "t": time.time()})

        # ── 틱: 보스가 "나"를 공격하는 건 각자 로컬 독립 시뮬레이션 ──
        def tick(self):
            if self.result:
                return
            now = time.time()
            dt = min(0.25, now - self.last)
            self.last = now
            self.mana = min(self.st["mana"], self.mana + self.st["mana_regen"] * dt)
            if self.st.get("hp_regen"):
                self.hp = min(self.hp_max, self.hp + self.hp_max * self.st["hp_regen"] * dt)
            self.floaters = [f for f in self.floaters if now - f["t"] < 1.0]
            self.blood = [b for b in self.blood if now - b["t"] < b["life"]]
            if self.combo and now - self.last_cast > G.meta["combo"]["window"]:
                self.combo = 0
            if self.time_left() <= 0:
                self.alive = False
                return
            if self.alive and now >= self.boss_next:
                self.boss_attack(now)

        def boss_attack(self, now):
            self.boss_n += 1
            b = self.boss
            heavy = self.boss_n % b["heavy_every"] == 0
            raw = b["atk"] * (b["heavy_mult"] if heavy else 1.0) * random.uniform(0.92, 1.08)
            mitig = b["k"] / (b["k"] + self.st["def"])
            dmg = raw * mitig
            self.boss_next = now + b["interval"]
            if random.random() < self.st["dodge"]:
                self.float_text(_("회피!"), 330, 420, "#8ff0ff")
                self.add_log(_("공격을 회피했다!"), "#8ff0ff")
                return
            if now <= self.guard_until:
                dmg *= (1.0 - self.guard["reduce"])
                tag = _(" (방어)")
            else:
                tag = ""
            dmg = max(1, int(dmg))
            self.hp = max(0.0, self.hp - dmg)
            self.player_hit_until = now + 0.28
            if heavy or dmg > self.hp_max * 0.08:
                self.splash(1, False, boss=False)
            name = b["attack"] + (_(" (강공격)") if heavy else "")
            self.float_text("-" + fmt(dmg), 320, 380, "#ff6b6b" if not heavy else "#ff3030", 56 if heavy else 44)
            self.add_log(_("%s: %s 피해%s") % (name, fmt(dmg), tag), "#ffb0b0")
            if self.hp <= 0:
                self.alive = False
                self.add_log(_("전투 불능..."), "#ff8080")

        # ── 입력 ────────────────────────────────
        def use_skill(self, slot):
            if self.result or not self.alive:
                return
            sk = [s for s in self.skills if s["slot"] == slot][0]
            now = time.time()
            if sk["level"] > self.level:
                renpy.notify(_("Lv.%d 에 해금") % sk["level"])
                return
            if now < self.ready[slot]:
                return
            if self.mana < sk["mana"]:
                self.float_text(_("기력 부족!"), 320, 420, "#7fa8ff", 36)
                return
            self.mana -= sk["mana"]
            cd = max(0.2, sk["cd"] * (1.0 - self.st["cd_reduce"]))
            self.ready[slot] = now + cd
            if sk["heal"]:
                amt = int(self.hp_max * sk["heal"])
                self.hp = min(self.hp_max, self.hp + amt)
                self.float_text("+" + fmt(amt), 320, 380, "#7dff9b")
                self.add_log(_("%s: 체력 %s 회복") % (sk["name"], fmt(amt)), "#9dffb5")
            if sk.get("mana_gain"):
                got = int(self.st["mana"] * sk["mana_gain"])
                self.mana = min(self.st["mana"], self.mana + got)
                self.float_text(_("기력 +") + fmt(got), 320, 340, "#7fb0ff", 40)
                self.add_log(_("%s: 기력 %s 회복") % (sk["name"], fmt(got)), "#9fc4ff")
            cb = G.meta["combo"]
            bonus = (1.0 + cb["step"] * self.combo) if sk["hits"] else 1.0
            self.combo = min(cb["max"], self.combo + 1)
            self.last_cast = now
            total = 0
            crits = 0
            for _i in range(sk["hits"]):
                d = self.st["atk"] * sk["mult"] * bonus * random.uniform(0.9, 1.1)
                if random.random() < self.st["crit"]:
                    d *= self.st["crit_dmg"]
                    crits += 1
                total += int(d)
            if total:
                self.boss_hp = max(0.0, self.boss_hp - total)
                self.pending_damage += total
                self.boss_hit_until = now + 0.12
                self.splash(3 if crits else 1, bool(crits))
                self.check_shout()
                self.float_text(fmt(total) + ("!" if crits else ""), 1320, 300,
                                "#ffe066" if crits else "#ffffff", 60 if crits else 46)
                self.add_log(_("%s: %s 피해%s") % (sk["name"], fmt(total), _(" (치명타)") if crits else ""), "#dfe8ff")
            if sk["stun"]:
                self.boss_next += sk["stun"]
                self.float_text(_("기절!"), 1300, 240, "#ffd27f", 40)

        def use_guard(self):
            if self.result or not self.alive:
                return
            now = time.time()
            if now < self.guard_ready:
                return
            self.guard_until = now + self.guard["duration"]
            self.guard_ready = now + self.guard["cd"]
            self.add_log(_("방어 자세!"), "#8fd0ff")

        def flee(self):
            if not self.result:
                self.result = "flee"

    RB = None
    RQ = _G()
    RQ.status = "idle"
    RQ.boss_id = None
    RQ.room_id = None
    RQ.queue_len = 0
    RQ.wait_total = 15
    RQ.wait_started = 0.0

    def rd_tick():
        RB.tick()
        return RB.result

    def rd_skill(slot):
        RB.use_skill(slot)
        return RB.result

    def rd_guard():
        RB.use_guard()

    def rd_flee():
        RB.flee()
        safe(api, "POST", "/api/raid/leave", {"room_id": RB.room_id})
        return RB.result

    def rd_report():
        if RB is None or RB.result:
            return RB.result if RB else None
        res = safe(api, "POST", "/api/raid/report",
                   {"room_id": RB.room_id, "damage": RB.pending_damage, "alive": RB.alive, "hp_frac": (RB.hp / RB.hp_max) if RB.hp_max else 0})
        if res:
            RB.pending_damage = 0.0
            RB.boss_hp = res["boss"]["hp"]
            RB.party = res["party"]
            RB.server_time_left = res["time_left"]
            RB.server_time_left_t = time.time()
            if res["result"] and not RB.result:
                RB.result = res["result"]
        return RB.result

    # ── 대기열 ─────────────────────────────────
    def raid_queue_join(boss_id, solo=False):
        global RQ
        res = safe(api, "POST", "/api/raid/queue/join", {"boss_id": boss_id, "solo": solo})
        if not res:
            return None
        RQ.boss_id = boss_id
        RQ.room_id = res.get("room_id")
        RQ.status = res["status"]
        RQ.queue_len = res.get("queue_len", 0)
        RQ.wait_total = res.get("wait_total", 15)
        RQ.wait_started = time.time()
        return RQ.status

    def raid_queue_poll():
        global RQ
        res = safe(api, "GET", "/api/raid/queue/poll?boss_id=%d" % RQ.boss_id)
        if not res:
            return None
        RQ.status = res["status"]
        RQ.room_id = res.get("room_id")
        RQ.queue_len = res.get("queue_len", RQ.queue_len)
        return "matched" if RQ.status == "matched" else None

    def raid_queue_leave():
        if RQ.boss_id is not None:
            safe(api, "POST", "/api/raid/queue/leave", {"boss_id": RQ.boss_id})
        RQ.status = "idle"

    def start_raid(room_id, boss_id):
        global RB
        # 방의 최신 상태(보스 체력/파티)를 받아오기 위해 데미지 0으로 한 번 보고하며 진입
        res = safe(api, "POST", "/api/raid/report", {"room_id": room_id, "damage": 0, "alive": True, "hp_frac": 1.0})
        if not res:
            return False
        res["room_id"] = room_id
        RB = RaidBattle(res, boss_meta(boss_id))
        return True

    def claim_raid():
        return safe(api, "POST", "/api/raid/claim", {"room_id": RB.room_id})
