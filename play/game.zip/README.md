# 렌파이 온라인 서버 (FastAPI + Supabase, Render 배포)

> 이 저장소에는 서버만 포함됩니다. Ren'Py 클라이언트는 별도로 관리합니다.

## 실행
1. `server/` 에서 `pip install -r requirements.txt`
2. (선택) Supabase: SQL Editor 에서 `server/schema.sql` 실행 → `server/.env.example` 을 `.env` 로 복사해
   `SUPABASE_URL`, `SUPABASE_KEY`(service_role) 입력.
   **비워두면 로컬 JSON 저장소(`server/data/`)로 동작**합니다.
3. 로컬 테스트가 필요하면 `server/` 에서 `python -m uvicorn main:app --port 8000` 로 실행 (평소에는 Render 사용)

`DEV_MODE=1` 이면 마을 화면에 [DEV] 레벨 변경 버튼이 나타납니다(테스트용).

## 조작
전투: 숫자키 1~6 = 스킬, Space = 방어 자세, Esc = 도망

## 구조
- `server/rules.py` : 만렙 200 / 보스 16종(입장 레벨) / 신체 강화 6부위 / 스킬 / 밸런스 (클라이언트는 `/api/meta` 로 받아 사용)
- `server/main.py` : FastAPI (가입·로그인, 신체 강화, 보스 전투 시작·종료 검증, 자동 사냥, 일러스트 data-URL 저장)

## Render 배포
1. 이 폴더를 GitHub 에 올립니다(`server/.env`, `server/data/` 는 올리지 마세요).
2. Render → New → Blueprint 로 `render.yaml` 을 연결하거나, Web Service 를 직접 만들고
   Root Directory=`server`, Build=`pip install -r requirements.txt`, Start=`uvicorn main:app --host 0.0.0.0 --port $PORT`.
3. 환경변수: `SUPABASE_URL`, `SUPABASE_KEY`(service_role), `TOKEN_SECRET`(고정 랜덤 문자열). `DEV_MODE` 는 넣지 마세요.
   (Render 에서 Supabase/TOKEN_SECRET 이 없으면 서버가 시작을 거부합니다.)
4. 클라이언트의 `SERVER_URL` 을 `https://renpy-online-api.onrender.com` 으로 설정합니다.
5. 무료 플랜은 15분 무응답 시 잠들어 첫 접속이 ~50초 걸립니다(클라이언트 타임아웃 60초로 대응).
   전투 진행 정보는 서버 메모리에 있어, 서버 재시작 중이던 전투는 무효 처리됩니다. 인스턴스는 1개만 쓰세요.

## 주요 시스템
- **신체 강화**: 근육/심장/골격/신경/폐/다리 6부위 (장비 없음). 12% 확률로 2단계 상승(대성공).
- **각성**: 6부위를 모두 50단계로 만들면 해금. 부위별 0~10단계, 각성 결정 소모, 1단계 = 신체 +3단계 상당, 능력치 상한 확장.
- **스토리 대치 (렌파이 온라인의 특징)**: 보스전 전에 노벨 게임식 대사 + 접근 방식 선택(정면 돌파/약점 분석/도발/대화 시도). 선택이 보스 체력·공격력·보상을 바꾼다.
- **PVP 아레나**: 유저 스냅샷/봇과 실시간 교전(AI), 엘로 레이팅·티어·PVP 코인.
- **히로인(전연령 미연시)**: 보스 처치로 해금, 대화/선물/이벤트로 호감도 상승, 호감도에 비례한 전투 보너스. 성적인 내용 없음.
- **경매장**: 게임 골드로만 거래(현금/환전 없음). 입찰·즉시 구매·수수료 8%·NPC 상인. 보스 트로피와 히로인 기념품이 아이템.
- **유혈/거친 대사**: 스타일화된 피 튀김 이펙트와 보스 외침(설정에서 각각 끌 수 있음).
- **재미 요소**: 콤보, 보스 전리품 상자, 일일 미션, 7일 출석, 레벨/PVP 랭킹.

## DB 마이그레이션 (선택)
PVP/미션/각성 상태는 `players.extra`(jsonb) 컬럼에 저장합니다. 컬럼이 없으면 서버가 자동으로 `clears` 안에 저장하는 호환 모드로 동작하므로 **마이그레이션 없이도 정상 작동**합니다.
컬럼을 만들고 싶다면 Supabase SQL Editor 에서 `server/migrations/001_extra.sql` 을 실행하세요(이후 서버가 자동으로 컬럼을 사용).
