# 무한의 탑 / 업적 화면

screen tower_screen():
    $ t = G.tower
    $ bm = boss_meta(t["boss"]["id"])
    add "images/bg/t%02d.webp" % bm["bg"]
    add Solid("#2a1d5ab8")
    use topbar
    frame:
        style "rp_panel"
        xpos 80
        ypos 140
        xsize 1040
        ysize 760
        padding (44, 30)
        vbox:
            spacing 14
            text _("무한의 탑") style "rp_text" size 56 color "#fff3a8"
            text (_("최고 기록  %d층") % t["best"]) style "rp_text" size 30 color "#c7b6ff"
            null height 6
            text (_("%d층 도전") % t["floor"]) style "rp_text" size 46 color "#ffe27a"
            text t["boss"]["name"] style "rp_text" size 36
            text (_("보스 체력 %s") % fmt(t["boss"]["hp"])) style "rp_text" size 26 color "#dcd4ff"
            if t["milestone"]:
                text _("층보스! 보상 2배 + 각성 결정") style "rp_text" size 28 color "#ffb0b0"
            null height 6
            text _("클리어 보상") style "rp_text" size 28 color "#fff1a8"
            text (_("경험치 +%s   골드 +%s   강화석 +%d") % (fmt(t["rewards"]["exp"]), fmt(t["rewards"]["gold"]), t["rewards"]["stones"])) style "rp_text" size 26
            if t["rewards"]["crystals"]:
                text (_("각성 결정 +%d") % t["rewards"]["crystals"]) style "rp_text" size 26 color "#ffc0ea"
            null height 10
            textbutton _("도전!"):
                style "rp_btn_pink"
                xsize 360
                text_size 44
                action Return("go")
    add "images/boss/s%02d.png" % bm["sprite"] fit "contain" xysize (520, 600) pos (1240, 150)
    frame:
        style "rp_panel"
        xpos 1180
        ypos 700
        xsize 660
        ysize 250
        padding (26, 16)
        vbox:
            spacing 2
            text _("무한의 탑 순위") style "rp_text" size 26 color "#fff1a8"
            if not t["rank"]:
                text _("아직 기록이 없어요.") style "rp_text" size 22 color "#dcd4ff"
            for i, r in enumerate(t["rank"][:5]):
                text ("%d. %s   %s" % (i + 1, r["name"], _("%d층") % r["floor"])) style "rp_text" size 22 color ("#b6ffca" if r["name"] == G.player["username"] else "#ffffff")
    use back_button

screen achievements_screen():
    add "images/bg/t08.webp"
    add Solid("#2a1d5ab0")
    use topbar
    viewport:
        xpos 160
        ypos 128
        xsize 1600
        ysize 800
        mousewheel True
        scrollbars "vertical"
        draggable True
        vbox:
            spacing 10
            text _("업적") style "rp_text" size 48 color "#fff1a8"
            for a in G.ach:
                frame:
                    background Frame("gui/rp/card_purple.png" if a["done"] and not a["claimed"] else "gui/rp/card.png", 30, 30, 30, 30)
                    xsize 1500
                    padding (26, 12)
                    hbox:
                        spacing 24
                        vbox:
                            xsize 960
                            yalign 0.5
                            text ach_title(a) style "rp_text" size 32 color ("#9a92c4" if a["claimed"] else ("#b6ffca" if a["done"] else "#ffe9a8"))
                            bar value StaticValue(a["value"], a["goal"]) xsize 900 ysize 14 left_bar pill("#5fd0ff") right_bar pill("track") thumb None
                            text ("%d / %d      %s" % (a["value"], a["goal"], ach_reward_text(a["reward"]))) style "rp_text" size 20 color "#dcd4ff"
                        textbutton (_("수령 완료") if a["claimed"] else _("보상 받기")):
                            style "rp_btn_mint"
                            xsize 260
                            yalign 0.5
                            text_size 28
                            sensitive (a["done"] and not a["claimed"])
                            action Function(claim_ach, a["id"])
    use back_button
