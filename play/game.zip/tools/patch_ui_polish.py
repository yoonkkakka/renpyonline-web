"""UI 마무리 패치: 쿨타임 표시, 스킬 목록 크기 (일회성)."""
from pathlib import Path

p = Path(__file__).resolve().parent.parent / "game" / "rpg" / "screens.rpy"
s = p.read_text(encoding="utf-8")

pairs = [
    ('''        text sk["name"] style "rp_text" size 22 align (0.5, 0.45) text_align 0.5 xmaximum 120 color ("#c9c3e6" if locked else ("#d8d0f0" if poor else "#ffffff"))''',
     '''        if left <= 0:
            text sk["name"] style "rp_text" size 22 align (0.5, 0.45) text_align 0.5 xmaximum 120 color ("#c9c3e6" if locked else ("#d8d0f0" if poor else "#ffffff"))'''),
    ('''        text "방어\\n자세" style "rp_text" size 26 align (0.5, 0.5) text_align 0.5
        if bt.guard_left() > 0:''',
     '''        if bt.guard_left() <= 0:
            text "방어\\n자세" style "rp_text" size 26 align (0.5, 0.5) text_align 0.5
        if bt.guard_left() > 0:'''),
    ('''style "rp_text" size 24 color ("#ffffff" if ok else "#9a92c4")''',
     '''style "rp_text" size 22 color ("#ffffff" if ok else "#9a92c4")'''),
    ('''            text "Space. 방어 자세" style "rp_text" size 24''',
     '''            text "Space. 방어 자세" style "rp_text" size 22'''),
]
for old, new in pairs:
    if old not in s:
        print("MISSING:", old[:60])
        continue
    s = s.replace(old, new, 1)
p.write_text(s, encoding="utf-8")
print("done")
