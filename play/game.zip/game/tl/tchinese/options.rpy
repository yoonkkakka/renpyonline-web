﻿# TODO: Translation updated at 2026-09-28 16:26

translate tchinese strings:

    # game/options.rpy:14
    old "렌파이 온라인"
    new "렌파이 온라인"

