"""회복 스킬(생명의 파동 / 명상 호흡) + 자연 회복 스탯 패치 (일회성)."""
from pathlib import Path

root = Path(__file__).resolve().parent.parent


def patch(path, pairs):
    s = path.read_text(encoding="utf-8")
    for old, new in pairs:
        assert old in s, (path.name, old[:70])
        s = s.replace(old, new, 1)
    path.write_text(s, encoding="utf-8")


# ── 서버 ──
patch(root / "server" / "rules.py", [
    ('''    {"slot": 6, "name": "서울 브레이커", "level": 120, "mult": 20.0, "hits": 1, "cd": 40.0, "mana": 100, "heal": 0,    "stun": 2.0},
]''', '''    {"slot": 6, "name": "서울 브레이커", "level": 120, "mult": 20.0, "hits": 1, "cd": 40.0, "mana": 100, "heal": 0,    "stun": 2.0},
    # 회복 계열: 대회복 / 기력 회복
    {"slot": 7, "name": "생명의 파동", "level": 90,  "mult": 0,    "hits": 0, "cd": 40.0, "mana": 80,  "heal": 0.5,  "stun": 0},
    {"slot": 8, "name": "명상 호흡",   "level": 50,  "mult": 0,    "hits": 0, "cd": 30.0, "mana": 0,   "heal": 0,    "stun": 0, "mana_gain": 0.5},
]'''),
    ('''        "dodge": round(min(0.25, 0.003 * g("legs")), 3),''', '''        "dodge": round(min(0.25, 0.003 * g("legs")), 3),
        "hp_regen": round(0.0001 * g("heart"), 5),   # 초당 최대 체력 비율(심장 단계가 높을수록 자연 회복)'''),
])

# ── 클라이언트: 보스전 ──
patch(root / "game" / "rpg" / "battle.rpy", [
    ('''            self.mana = min(self.st["mana"], self.mana + self.st["mana_regen"] * dt)
            self.floaters''', '''            self.mana = min(self.st["mana"], self.mana + self.st["mana_regen"] * dt)
            if self.st.get("hp_regen"):
                self.hp = min(self.hp_max, self.hp + self.hp_max * self.st["hp_regen"] * dt)
            self.floaters'''),
    ('''            if sk["heal"]:
                amt = int(self.hp_max * sk["heal"])
                self.hp = min(self.hp_max, self.hp + amt)
                self.float_text("+" + fmt(amt), 320, 380, "#7dff9b")
                self.add_log("%s: 체력 %s 회복" % (sk["name"], fmt(amt)), "#9dffb5")''', '''            if sk["heal"]:
                amt = int(self.hp_max * sk["heal"])
                self.hp = min(self.hp_max, self.hp + amt)
                self.float_text("+" + fmt(amt), 320, 380, "#7dff9b")
                self.add_log("%s: 체력 %s 회복" % (sk["name"], fmt(amt)), "#9dffb5")
            if sk.get("mana_gain"):
                got = int(self.st["mana"] * sk["mana_gain"])
                self.mana = min(self.st["mana"], self.mana + got)
                self.float_text("기력 +" + fmt(got), 320, 340, "#7fb0ff", 40)
                self.add_log("%s: 기력 %s 회복" % (sk["name"], fmt(got)), "#9fc4ff")'''),
])

# ── 클라이언트: PVP ──
patch(root / "game" / "rpg" / "pvp.rpy", [
    ('''            for f in (self.me, self.opp):
                f.mana = min(f.st["mana"], f.mana + f.st["mana_regen"] * dt)''', '''            for f in (self.me, self.opp):
                f.mana = min(f.st["mana"], f.mana + f.st["mana_regen"] * dt)
                if f.st.get("hp_regen"):
                    f.hp = min(f.hp_max, f.hp + f.hp_max * f.st["hp_regen"] * dt)'''),
    ('''                self.add_log("%s: %s 체력 %s 회복" % (atk.name, sk["name"], fmt(amt)), "#9dffb5")''', '''                self.add_log("%s: %s 체력 %s 회복" % (atk.name, sk["name"], fmt(amt)), "#9dffb5")
            if sk.get("mana_gain"):
                got = int(atk.st["mana"] * sk["mana_gain"])
                atk.mana = min(atk.st["mana"], atk.mana + got)
                self.float_text("기력 +" + fmt(got), 320 if mine else 1400, 340, "#7fb0ff", 40)'''),
    ('''            heal = [s for s in usable if s["heal"]]
            if heal and o.hp < o.hp_max * 0.4:
                self._cast(o, self.me, heal[0], now, False)
                return''', '''            heal = [s for s in usable if s["heal"]]
            if heal and o.hp < o.hp_max * 0.4:
                self._cast(o, self.me, max(heal, key=lambda s: s["heal"]), now, False)
                return
            gain = [s for s in usable if s.get("mana_gain")]
            if gain and o.mana < o.st["mana"] * 0.3:
                self._cast(o, self.me, gain[0], now, False)
                return'''),
])

# ── 키 바인딩 (7, 8) ──
for name in ("screens.rpy", "screens_fun.rpy"):
    p = root / "game" / "rpg" / name
    s = p.read_text(encoding="utf-8")
    for fn in ("bt_skill", "pb_skill"):
        anchor = f'    key "K_6" action Function({fn}, 6)\n'
        if anchor in s:
            s = s.replace(anchor, anchor + f'    key "K_7" action Function({fn}, 7)\n    key "K_8" action Function({fn}, 8)\n', 1)
            k6 = f'    key "K_KP6" action Function({fn}, 6)\n'
            s = s.replace(k6, k6 + f'    key "K_KP7" action Function({fn}, 7)\n    key "K_KP8" action Function({fn}, 8)\n', 1)
    p.write_text(s, encoding="utf-8")
print("patched")
