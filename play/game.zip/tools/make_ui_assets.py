"""귀여운 모바일 게임풍 UI 에셋 생성 (Pillow). 결과: game/gui/rp/*.png"""
import math
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter

OUT = Path(__file__).resolve().parent.parent / "game" / "gui" / "rp"
OUT.mkdir(parents=True, exist_ok=True)
SS = 4  # 슈퍼샘플링 배율(안티에일리어싱)


def hexc(h, a=255):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) + (a,)


def mix(c1, c2, t):
    return tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(4))


def lighten(c, t):
    return mix(c, (255, 255, 255, c[3]), t)


def darken(c, t):
    return mix(c, (0, 0, 0, c[3]), t)


def save(im, name):
    im.save(OUT / name)


def rrect(w, h, r, top, bottom, border=None, bw=0, shadow=0, shadow_col=None, gloss=False, alpha=255):
    """둥근 사각형(세로 그라데이션 + 테두리 + 아래 그림자 + 광택)."""
    W, H = w * SS, h * SS
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    body_h = H - shadow * SS
    if shadow:
        d = ImageDraw.Draw(im)
        d.rounded_rectangle((0, shadow * SS, W - 1, H - 1), r * SS, fill=shadow_col or darken(bottom, 0.35))
    grad = Image.new("RGBA", (W, body_h))
    gd = ImageDraw.Draw(grad)
    for y in range(body_h):
        gd.line((0, y, W, y), fill=mix(top, bottom, y / max(1, body_h - 1)))
    mask = Image.new("L", (W, body_h), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, W - 1, body_h - 1), r * SS, fill=255)
    im.paste(grad, (0, 0), mask)
    d = ImageDraw.Draw(im)
    if border and bw:
        d.rounded_rectangle((0, 0, W - 1, body_h - 1), r * SS, outline=border, width=bw * SS)
    if gloss:
        g = Image.new("RGBA", (W, body_h), (0, 0, 0, 0))
        gd = ImageDraw.Draw(g)
        gd.rounded_rectangle((bw * SS + 8, bw * SS + 6, W - bw * SS - 9, body_h * 0.48), max(4, (r - 4) * SS),
                             fill=(255, 255, 255, 70))
        im.alpha_composite(g)
    if alpha != 255:
        a = im.getchannel("A").point(lambda v: v * alpha // 255)
        im.putalpha(a)
    return im.resize((w, h), Image.LANCZOS)


# ── 패널 / 카드 ──────────────────────────────────────────────
save(rrect(96, 96, 30, hexc("#3a3070"), hexc("#2b2354"), hexc("#cdbdff"), 4, alpha=238), "panel.png")
save(rrect(96, 96, 26, hexc("#4a3f8c"), hexc("#3b3275"), hexc("#a99cf5"), 3, alpha=240), "card.png")
save(rrect(96, 96, 26, hexc("#6a3a9a"), hexc("#552d83"), hexc("#ff9de2"), 3, alpha=240), "card_purple.png")
save(rrect(96, 96, 26, hexc("#3f6fc0"), hexc("#2f5aa4"), hexc("#9adaff"), 3, alpha=240), "card_blue.png")
save(rrect(96, 96, 26, hexc("#8a6a2a"), hexc("#705220"), hexc("#ffe08a"), 3, alpha=240), "card_gold.png")
save(rrect(96, 96, 26, hexc("#6a5fc0"), hexc("#5a4faa"), hexc("#ffffff"), 3, alpha=245), "card_hover.png")
save(rrect(96, 96, 26, hexc("#2c2750"), hexc("#25213f"), hexc("#5a5388"), 3, alpha=235), "card_dim.png")

# ── 입력창 ───────────────────────────────────────────────────
save(rrect(96, 72, 26, hexc("#fffaf0"), hexc("#ffefdc"), hexc("#ff9dc0"), 4), "inputbox.png")

# ── 버튼 (통통한 젤리 스타일) ─────────────────────────────────
BTN = {
    "blue": ("#69b4ff", "#3d80ff"), "pink": ("#ff92bd", "#ff5f9b"), "mint": ("#72e8c6", "#2fc79a"),
    "yellow": ("#ffdc72", "#ffb62e"), "purple": ("#bfa3ff", "#8f68ff"), "gray": ("#9a94b4", "#77719a"),
    "orange": ("#ffb072", "#ff8a3d"),
}
for name, (t, b) in BTN.items():
    tc, bc = hexc(t), hexc(b)
    save(rrect(96, 96, 30, tc, bc, darken(bc, 0.25), 3, shadow=8, gloss=True), f"btn_{name}.png")
    save(rrect(96, 96, 30, lighten(tc, 0.25), lighten(bc, 0.2), darken(bc, 0.15), 3, shadow=8, gloss=True), f"btn_{name}_hover.png")
save(rrect(96, 96, 30, hexc("#5f5a80"), hexc("#4c476b"), hexc("#3a3656"), 3, shadow=8, gloss=False), "btn_off.png")

# ── 바(캔디) ─────────────────────────────────────────────────
PILL = {"red": ("#ff8fa8", "#ff5b7f"), "green": ("#8ff0a8", "#4fd47a"), "blue": ("#8fc8ff", "#4f95ff"),
        "yellow": ("#ffe58a", "#ffc93a"), "pink": ("#ffb0e0", "#ff7cc4"), "orange": ("#ffc48a", "#ff9a3a")}
for name, (t, b) in PILL.items():
    save(rrect(64, 32, 16, hexc(t), hexc(b), darken(hexc(b), 0.2), 2, gloss=True), f"pill_{name}.png")
save(rrect(64, 32, 16, hexc("#2c2552"), hexc("#3a3168"), hexc("#171233"), 2), "pill_track.png")

# ── 스킬 슬롯 ────────────────────────────────────────────────
SLOT = {"pink": "#ff7fb0", "orange": "#ff9a4d", "green": "#4fd47a", "yellow": "#ffc93a",
        "red": "#ff5b6b", "purple": "#a071ff", "blue": "#4f95ff", "gray": "#6d6890"}
for name, b in SLOT.items():
    bc = hexc(b)
    save(rrect(128, 128, 34, lighten(bc, 0.3), bc, darken(bc, 0.3), 4, shadow=8, gloss=True), f"slot_{name}.png")
save(rrect(128, 128, 34, hexc("#1a1240", 200), hexc("#1a1240", 200), None, 0, shadow=8), "slot_cd.png")

# ── 칩 / 뱃지 ────────────────────────────────────────────────
save(rrect(96, 64, 32, hexc("#3a3070"), hexc("#2b2354"), hexc("#cdbdff"), 3, alpha=240), "chip.png")


def circle(size, fill, border=None, bw=0):
    im = Image.new("RGBA", (size * SS, size * SS), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.ellipse((0, 0, size * SS - 1, size * SS - 1), fill=fill, outline=border, width=bw * SS)
    return im.resize((size, size), Image.LANCZOS)


save(circle(40, hexc("#ff4d6d"), hexc("#ffffff"), 3), "badge_red.png")
save(circle(96, hexc("#8f68ff"), hexc("#ffffff"), 4), "lv_badge.png")


def star_poly(cx, cy, r_out, r_in, n=5, rot=-90):
    pts = []
    for i in range(n * 2):
        r = r_out if i % 2 == 0 else r_in
        a = math.radians(rot + i * 180 / n)
        pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def icon_canvas(size=64):
    return Image.new("RGBA", (size * SS, size * SS), (0, 0, 0, 0))


def finish(im, size):
    return im.resize((size, size), Image.LANCZOS)


# 재화 아이콘
S = 64 * SS
im = icon_canvas(); d = ImageDraw.Draw(im)
d.ellipse((4 * SS, 4 * SS, 60 * SS, 60 * SS), fill=hexc("#ffd23a"), outline=hexc("#c98a00"), width=4 * SS)
d.ellipse((14 * SS, 14 * SS, 50 * SS, 50 * SS), outline=hexc("#ffef9a"), width=3 * SS)
d.polygon(star_poly(32 * SS, 33 * SS, 12 * SS, 5 * SS), fill=hexc("#ffb400"))
save(finish(im, 64), "icon_coin.png")
im = icon_canvas(); d = ImageDraw.Draw(im)
d.polygon([(32 * SS, 4 * SS), (58 * SS, 24 * SS), (32 * SS, 60 * SS), (6 * SS, 24 * SS)], fill=hexc("#b48cff"), outline=hexc("#6b3fd0"))
d.polygon([(32 * SS, 4 * SS), (44 * SS, 24 * SS), (20 * SS, 24 * SS)], fill=hexc("#e2ccff"))
d.polygon([(6 * SS, 24 * SS), (20 * SS, 24 * SS), (32 * SS, 60 * SS)], fill=hexc("#9a6cf5"))
save(finish(im, 64), "icon_gem.png")
im = icon_canvas(); d = ImageDraw.Draw(im)
d.polygon(star_poly(32 * SS, 34 * SS, 29 * SS, 13 * SS), fill=hexc("#ff8fd6"), outline=hexc("#d24aa2"))
d.polygon(star_poly(32 * SS, 34 * SS, 15 * SS, 7 * SS), fill=hexc("#ffd0ee"))
save(finish(im, 64), "icon_crystal.png")


def menu_icon(name, draw_fn, bg):
    size = 128
    im = Image.new("RGBA", (size * SS, size * SS), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.ellipse((0, 0, size * SS - 1, size * SS - 1), fill=hexc("#ffffff"))
    d.ellipse((8 * SS, 8 * SS, (size - 8) * SS, (size - 8) * SS), fill=hexc(bg))
    draw_fn(d, SS)
    save(im.resize((size, size), Image.LANCZOS), name)


def heart(cx, cy, sz, ss):
    pts = []
    for i in range(120):
        t = i / 120 * 2 * math.pi
        x = 16 * math.sin(t) ** 3
        y = -(13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t))
        pts.append((cx + x * sz * ss, cy + y * sz * ss))
    return pts


menu_icon("ic_char.png", lambda d, s: d.polygon(heart(64 * s, 64 * s, 2.4, s), fill=hexc("#ffffff")), "#ff6fa5")


def crown(d, s):
    w = hexc("#ffffff")
    d.polygon([(30 * s, 84 * s), (26 * s, 48 * s), (46 * s, 64 * s), (64 * s, 38 * s), (82 * s, 64 * s), (102 * s, 48 * s), (98 * s, 84 * s)], fill=w)
    d.rounded_rectangle((30 * s, 86 * s, 98 * s, 96 * s), 4 * s, fill=w)
    for x, y in ((26, 46), (64, 36), (102, 46)):
        d.ellipse(((x - 6) * s, (y - 6) * s, (x + 6) * s, (y + 6) * s), fill=w)


menu_icon("ic_boss.png", crown, "#ffa53d")


def clock(d, s):
    w = hexc("#ffffff")
    d.ellipse((30 * s, 30 * s, 98 * s, 98 * s), outline=w, width=7 * s)
    d.line((64 * s, 64 * s, 64 * s, 42 * s), fill=w, width=7 * s)
    d.line((64 * s, 64 * s, 80 * s, 72 * s), fill=w, width=7 * s)
    d.ellipse((58 * s, 58 * s, 70 * s, 70 * s), fill=w)


menu_icon("ic_hunt.png", clock, "#34c9a0")


def swords(d, s):
    w = hexc("#ffffff")
    d.line((36 * s, 92 * s, 92 * s, 36 * s), fill=w, width=9 * s)
    d.line((92 * s, 92 * s, 36 * s, 36 * s), fill=w, width=9 * s)
    d.line((30 * s, 78 * s, 50 * s, 98 * s), fill=w, width=7 * s)
    d.line((98 * s, 78 * s, 78 * s, 98 * s), fill=w, width=7 * s)
    d.polygon([(92 * s, 36 * s), (100 * s, 26 * s), (102 * s, 40 * s)], fill=w)
    d.polygon([(36 * s, 36 * s), (28 * s, 26 * s), (26 * s, 40 * s)], fill=w)


menu_icon("ic_pvp.png", swords, "#5b8dff")


def scroll(d, s):
    w = hexc("#ffffff")
    d.rounded_rectangle((36 * s, 28 * s, 92 * s, 100 * s), 10 * s, fill=w)
    for y in (46, 62):
        d.rounded_rectangle((46 * s, y * s, 82 * s, (y + 6) * s), 3 * s, fill=hexc("#b98cff"))
    d.line((48 * s, 84 * s, 56 * s, 91 * s, 76 * s, 74 * s), fill=hexc("#ff6fa5"), width=6 * s, joint="curve")


menu_icon("ic_mission.png", scroll, "#9a6cf5")


def podium(d, s):
    w = hexc("#ffffff")
    d.rounded_rectangle((26 * s, 66 * s, 50 * s, 98 * s), 4 * s, fill=w)
    d.rounded_rectangle((52 * s, 50 * s, 76 * s, 98 * s), 4 * s, fill=w)
    d.rounded_rectangle((78 * s, 76 * s, 102 * s, 98 * s), 4 * s, fill=w)
    d.polygon(star_poly(64 * s, 34 * s, 14 * s, 6 * s), fill=w)


menu_icon("ic_rank.png", podium, "#ff8a3d")

# 화살표(돌아가기)
im = icon_canvas(); d = ImageDraw.Draw(im)
d.line((42 * SS, 14 * SS, 20 * SS, 32 * SS, 42 * SS, 50 * SS), fill=hexc("#ffffff"), width=9 * SS, joint="curve")
save(finish(im, 64), "icon_back.png")

# 반짝이 장식
im = icon_canvas(); d = ImageDraw.Draw(im)
d.polygon(star_poly(32 * SS, 32 * SS, 30 * SS, 7 * SS, n=4, rot=-90), fill=hexc("#fff1a8"))
save(finish(im, 64), "sparkle.png")
im = icon_canvas(); d = ImageDraw.Draw(im)
d.polygon(heart(32 * SS, 34 * SS, 1.7, SS), fill=hexc("#ff9dc8"))
save(finish(im, 64), "deco_heart.png")

# 허브 타일(크게)
TILE = {"pink": ("#ff9cc4", "#ff669f"), "orange": ("#ffc07a", "#ff9040"), "mint": ("#7cecc9", "#33cba0"),
        "blue": ("#86bcff", "#4a86ff"), "purple": ("#c7aeff", "#9a70ff"), "yellow": ("#ffe184", "#ffbb33")}
for name, (t, b) in TILE.items():
    tc, bc = hexc(t), hexc(b)
    save(rrect(160, 130, 36, tc, bc, darken(bc, 0.25), 4, shadow=10, gloss=True), f"tile_{name}.png")
    save(rrect(160, 130, 36, lighten(tc, 0.25), lighten(bc, 0.2), darken(bc, 0.15), 4, shadow=10, gloss=True), f"tile_{name}_hover.png")
print("assets ->", OUT, len(list(OUT.glob('*.png'))), "files")

# 마스크(카드 모서리 자르기용): 불투명 흰색 둥근 사각형
save(rrect(96, 96, 30, hexc("#ffffff"), hexc("#ffffff")), "mask.png")


# 카드 테두리(안쪽은 투명한 둥근 외곽선)
def outline_rrect(w, h, r, color, bw):
    im = Image.new("RGBA", (w * SS, h * SS), (0, 0, 0, 0))
    ImageDraw.Draw(im).rounded_rectangle((0, 0, w * SS - 1, h * SS - 1), r * SS, outline=color, width=bw * SS)
    return im.resize((w, h), Image.LANCZOS)


save(outline_rrect(96, 96, 30, hexc("#ffffff"), 5), "border_white.png")
save(outline_rrect(96, 96, 30, hexc("#ff9dc8"), 5), "border_pink.png")
save(outline_rrect(96, 96, 30, hexc("#7d76a8"), 5), "border_gray.png")
save(outline_rrect(96, 96, 30, hexc("#ffe27a"), 5), "border_gold.png")
