﻿# TODO: Translation updated at 2026-09-28 16:26

translate tchinese strings:

    # game/rpg/fun_api.rpy:20
    old "강화석 %d개로 교환했습니다."
    new "已兌換 %d 個強化石。"

    # game/rpg/fun_api.rpy:32
    old ", 각성 결정 %d"
    new "，覺醒結晶 %d"

    # game/rpg/fun_api.rpy:33
    old "보상: 골드 %s, 강화석 %s%s"
    new "獎勵：金幣 %s，強化石 %s%s"

    # game/rpg/fun_api.rpy:40
    old "%d일차 출석! 골드 %s, 강화석 %d"
    new "第%d天簽到! 金幣 %s，強化石 %d"

    # game/rpg/fun_api.rpy:42
    old ", 경험치 부스트 1시간"
    new "，經驗加成1小時"

    # game/rpg/fun_api.rpy:54
    old "방금 전"
    new "剛剛"

    # game/rpg/fun_api.rpy:56
    old "%d분 전"
    new "%d分鐘前"

    # game/rpg/fun_api.rpy:58
    old "%d시간 전"
    new "%d小時前"

    # game/rpg/fun_api.rpy:59
    old "%d일 전"
    new "%d天前"

    # game/rpg/fun_api.rpy:79
    old "각성 성공!"
    new "覺醒成功!"

