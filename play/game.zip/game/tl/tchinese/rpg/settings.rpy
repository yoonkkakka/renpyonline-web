﻿# TODO: Translation updated at 2026-09-28 16:26

translate tchinese strings:

    # game/rpg/settings.rpy:29
    old "켜짐"
    new "開啟"

    # game/rpg/settings.rpy:29
    old "꺼짐"
    new "關閉"

    # game/rpg/settings.rpy:58
    old "렌파이 온라인 v%s"
    new "렌파이 온라인 v%s"

    # game/rpg/settings.rpy:59
    old "닫기 (Esc)"
    new "關閉（Esc）"

    # game/rpg/settings.rpy:65
    old "소리"
    new "聲音"

    # game/rpg/settings.rpy:66
    old "배경음"
    new "背景音樂"

    # game/rpg/settings.rpy:67
    old "효과음"
    new "音效"

    # game/rpg/settings.rpy:68
    old "전체 음소거"
    new "全部靜音"

    # game/rpg/settings.rpy:69
    old "화면"
    new "畫面"

    # game/rpg/settings.rpy:72
    old "창 모드"
    new "視窗模式"

    # game/rpg/settings.rpy:79
    old "스토리 대사"
    new "劇情對話"

    # game/rpg/settings.rpy:80
    old "대사 속도"
    new "文字速度"

    # game/rpg/settings.rpy:81
    old "조작법"
    new "操作方法"

    # game/rpg/settings.rpy:82
    old "1~8 스킬  /  Space 방어 자세"
    new "1~8 技能  /  空格鍵 防禦姿態"

    # game/rpg/settings.rpy:83
    old "Esc 설정 (전투 중에는 도망)"
    new "Esc 開啟設定（戰鬥中為逃跑）"

    # game/rpg/settings.rpy:84
    old "스킬을 2초 안에 이어 쓰면 콤보로 피해 최대 +20%!"
    new "2秒內連續使用技能可透過連擊最多提升20%傷害！"

    # game/rpg/settings.rpy:88
    old "전투 효과"
    new "戰鬥效果"

    # game/rpg/settings.rpy:89
    old "화면 흔들림"
    new "畫面震動"

    # game/rpg/settings.rpy:89
    old "맞을 때 캐릭터가 부르르 떨려요"
    new "受擊時角色會震動抖動"

    # game/rpg/settings.rpy:90
    old "피해 숫자"
    new "傷害數字"

    # game/rpg/settings.rpy:90
    old "떠오르는 데미지/회복 숫자"
    new "浮現的傷害／恢復數字"

    # game/rpg/settings.rpy:91
    old "전투 기록"
    new "戰鬥記錄"

    # game/rpg/settings.rpy:91
    old "오른쪽 아래 전투 로그"
    new "右下角的戰鬥日誌"

    # game/rpg/settings.rpy:92
    old "유혈 표현"
    new "流血效果"

    # game/rpg/settings.rpy:92
    old "맞을 때 피가 튀는 연출"
    new "受擊時濺血的效果"

    # game/rpg/settings.rpy:93
    old "거친 대사"
    new "粗口臺詞"

    # game/rpg/settings.rpy:93
    old "보스 외침과 대사에 거친 말투"
    new "首領吶喊與臺詞使用粗俗語氣"

    # game/rpg/settings.rpy:94
    old "계정"
    new "賬戶"

    # game/rpg/settings.rpy:98
    old "아직 로그인하지 않았어요"
    new "尚未登入"

    # game/rpg/settings.rpy:109
    old "게임 종료"
    new "退出遊戲"

