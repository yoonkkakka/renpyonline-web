﻿# TODO: Translation updated at 2026-09-28 16:26

translate tchinese strings:

    # game/rpg/screens_market.rpy:38
    old "호감도 %d / 100"
    new "好感度 %d / 100"

    # game/rpg/screens_market.rpy:41
    old "잠김"
    new "未解鎖"

    # game/rpg/screens_market.rpy:57
    old "필드 보스  %s 을(를) 쓰러뜨리면 만날 수 있어요."
    new "擊敗野外首領 %s 後即可相遇。"

    # game/rpg/screens_market.rpy:59
    old "호감도  %d / 100"
    new "好感度  %d / 100"

    # game/rpg/screens_market.rpy:61
    old "호감도 보너스: %s +%.1f%%  (최대 +%.1f%%)"
    new "好感度加成：%s +%.1f%%  （最大 +%.1f%%）"

    # game/rpg/screens_market.rpy:65
    old "대화하기  (오늘 %d회 남음)"
    new "對話  （今日剩餘 %d 次）"

    # game/rpg/screens_market.rpy:71
    old "선물하기  (%s 를 좋아해요 / 가방/상점에서 구매)"
    new "贈送禮物  （喜歡 %s / 可在揹包/商店購買）"

    # game/rpg/screens_market.rpy:81
    old "이벤트"
    new "劇情事件"

    # game/rpg/screens_market.rpy:83
    old "%s   (호감도 %d)  "
    new "%s   （好感度 %d）  "

    # game/rpg/screens_market.rpy:83
    old "보기 >"
    new "檢視 >"

    # game/rpg/screens_market.rpy:106
    old "가방"
    new "揹包"

    # game/rpg/screens_market.rpy:108
    old "가방이 비어 있어요.\n보스를 잡으면 트로피가 나오고,\n히로인 이벤트로 기념품을 얻을 수 있어요."
    new "揹包是空的。\n擊敗首領可獲得紀念獎盃，\n透過女主角劇情可獲得紀念品。"

    # game/rpg/screens_market.rpy:129
    old "상점에 판매\n%s G"
    new "賣給商店\n%s 金"

    # game/rpg/screens_market.rpy:131
    old "사용"
    new "使用"

    # game/rpg/screens_market.rpy:141
    old "상점"
    new "商店"

    # game/rpg/screens_market.rpy:165
    old "우편함"
    new "郵箱"

    # game/rpg/screens_market.rpy:167
    old "받은 소식이 없어요."
    new "沒有收到的訊息。"

    # game/rpg/screens_market.rpy:190
    old "구매"
    new "購買"

    # game/rpg/screens_market.rpy:191
    old "판매하기"
    new "出售"

    # game/rpg/screens_market.rpy:192
    old "내 경매"
    new "我的拍賣"

    # game/rpg/screens_market.rpy:194
    old "골드로만 거래해요. 낙찰 수수료 %d%%"
    new "僅限金幣交易。成交手續費 %d%%"

    # game/rpg/screens_market.rpy:222
    old "판매자 %s   남은 시간 %s%s"
    new "賣家 %s   剩餘時間 %s%s"

    # game/rpg/screens_market.rpy:222
    old "   (내가 최고 입찰!)"
    new "   （我是最高出價！）"

    # game/rpg/screens_market.rpy:226
    old "현재가 %s G"
    new "當前價 %s 金"

    # game/rpg/screens_market.rpy:227
    old "기본가 %s G"
    new "基礎價 %s 金"

    # game/rpg/screens_market.rpy:228
    old "입찰 %s G"
    new "出價 %s 金"

    # game/rpg/screens_market.rpy:236
    old "즉시 구매 %s G"
    new "一口價 %s 金"

    # game/rpg/screens_market.rpy:244
    old "지금 열려 있는 경매가 없어요."
    new "目前沒有正在進行的拍賣。"

    # game/rpg/screens_market.rpy:251
    old "판매할 아이템 (트로피 / 기념품)"
    new "要出售的物品（紀念獎盃／紀念品）"

    # game/rpg/screens_market.rpy:253
    old "올릴 수 있는 아이템이 없어요."
    new "沒有可上架的物品。"

    # game/rpg/screens_market.rpy:262
    old "%s  x%d   (기본가 %s G)"
    new "%s  x%d   （基礎價 %s 金）"

    # game/rpg/screens_market.rpy:273
    old "왼쪽에서 아이템을 골라 주세요."
    new "請在左側選擇物品。"

    # game/rpg/screens_market.rpy:281
    old "수량 %d"
    new "數量 %d"

    # game/rpg/screens_market.rpy:284
    old "시작가  %s G   (기본가 %s G)"
    new "起拍價  %s 金   （基礎價 %s 金）"

    # game/rpg/screens_market.rpy:291
    old "기본가"
    new "基礎價"

    # game/rpg/screens_market.rpy:292
    old "즉시 구매가: 시작가의 160%  (%s G)"
    new "一口價：起拍價的160%  （%s 金）"

    # game/rpg/screens_market.rpy:292
    old "즉시 구매가: 없음"
    new "一口價：無"

    # game/rpg/screens_market.rpy:299
    old "기간"
    new "時長"

    # game/rpg/screens_market.rpy:301
    old "%d시간"
    new "%d小時"

    # game/rpg/screens_market.rpy:302
    old "시작가가 기본가의 약 130% 이하인데 입찰이 없으면\n경매 상인이 시작가에 사 줘요."
    new "若起拍價低於基礎價約130%且無人出價，\n拍賣商人會以起拍價買下。"

    # game/rpg/screens_market.rpy:303
    old "경매에 올리기"
    new "上架拍賣"

    # game/rpg/screens_market.rpy:312
    old "내가 올린 경매  %d / %d"
    new "我上架的拍賣  %d / %d"

    # game/rpg/screens_market.rpy:314
    old "올린 경매가 없어요. '판매하기' 탭에서 올려 보세요!"
    new "還沒有上架的拍賣。請到「出售」標籤頁上架看看！"

    # game/rpg/screens_market.rpy:326
    old "현재가 %s G   %s   남은 시간 %s"
    new "當前價 %s 金   %s   剩餘時間 %s"

    # game/rpg/screens_market.rpy:326
    old "최고 입찰자 "
    new "最高出價者 "

    # game/rpg/screens_market.rpy:326
    old "아직 입찰 없음"
    new "尚無出價"

    # game/rpg/screens_market.rpy:327
    old "취소"
    new "取消"

