"""허브 / 스킬 슬롯 / 보스 전투 / 결과 화면에 PVP·재미 요소를 반영하는 일회성 패치."""
from pathlib import Path

root = Path(__file__).resolve().parent.parent / "game" / "rpg"

# ── fun_api.rpy: 출석 칸 계산 ──
p = root / "fun_api.rpy"
s = p.read_text(encoding="utf-8")
s = s.replace('''    def rarity_color(r):''', '''    def checkin_days(ck):
        """이번 7일 주기에서 이미 채운 칸 수."""
        if ck["streak"] <= 0:
            return 0
        day = (ck["streak"] - 1) % 7 + 1
        if ck["ready"] and day == 7:
            return 0     # 7일을 채웠으면 새 주기 시작
        return day

    def rarity_color(r):''', 1)
p.write_text(s, encoding="utf-8")

p = root / "screens_fun.rpy"
s = p.read_text(encoding="utf-8")
a = s.index("                    $ got = ck[")
b = s.index("\n", a)
s = s[:a] + "                    $ got = day <= checkin_days(ck)" + s[b:]
p.write_text(s, encoding="utf-8")

# ── screens.rpy ──
p = root / "screens.rpy"
s = p.read_text(encoding="utf-8")

def rep(old, new, count=1):
    global s
    assert old in s, old[:60]
    s = s.replace(old, new, count)

# skill_slot: 전투 객체를 인자로 받는다(보스/PVP 공용)
rep("screen skill_slot(sk):\n    $ locked = B.level < sk[\"level\"]\n    $ left = B.cd_left(sk[\"slot\"])\n    $ poor = B.mana < sk[\"mana\"]\n    $ frac = 0.0 if sk[\"cd\"] <= 0 else min(1.0, left / max(0.2, sk[\"cd\"] * (1.0 - B.st[\"cd_reduce\"])))",
    "screen skill_slot(sk, bt):\n    $ locked = bt.level < sk[\"level\"]\n    $ left = bt.cd_left(sk[\"slot\"])\n    $ poor = bt.mana < sk[\"mana\"]\n    $ frac = 0.0 if sk[\"cd\"] <= 0 else min(1.0, left / max(0.2, sk[\"cd\"] * (1.0 - bt.st[\"cd_reduce\"])))")
rep("            use skill_slot(sk)\n", "            use skill_slot(sk, bt)\n")

# 보스 전투: 콤보 표시
rep('''    textbutton "도망 (Esc)":''', '''    if bt.combo >= 2:
        text ("COMBO x%d   +%d%%" % (bt.combo, int(G.meta["combo"]["step"] * 100 * bt.combo))) style "rp_text" size 48 color "#ffe066" xalign 0.5 ypos 190
    textbutton "도망 (Esc)":''')

# 보스 결과: 전리품 상자
rep('''                text "경험치 부스트 30분 획득 (+50%)" style "rp_text" size 24 xalign 0.5 color "#9dffb5"''',
    '''                if fin.get("loot"):
                    $ lt = fin["loot"]
                    text ("전리품 상자  %s" % lt["rarity"]) style "rp_text" size 40 xalign 0.5 color rarity_color(lt["rarity"])
                    if lt["gold"] or lt["stones"]:
                        text ("보너스 골드 +%s   강화석 +%d" % (fmt(lt["gold"]), lt["stones"])) style "rp_text" size 28 xalign 0.5 color rarity_color(lt["rarity"])
                    if lt["boost_seconds"]:
                        text "전설 보너스: 경험치 부스트 +1시간!" style "rp_text" size 26 xalign 0.5 color "#ffb347"
                text "경험치 부스트 30분 획득 (+50%)" style "rp_text" size 24 xalign 0.5 color "#9dffb5"''')

# 허브: 2열 6버튼
a = s.index('            textbutton "캐릭터 / 신체 강화":')
b = s.index("            hbox:\n                spacing 20\n                textbutton \"로그아웃\"")
hub_buttons = '''            hbox:
                spacing 20
                vbox:
                    spacing 20
                    xsize 490
                    textbutton "캐릭터 / 신체 강화" style "rp_button" xfill True text_size 34 text_xalign 0.0 action Return("char")
                    textbutton "필드 보스 (16종)" style "rp_button" xfill True text_size 34 text_xalign 0.0 action Return("boss")
                    textbutton "자동 사냥 센터" style "rp_button" xfill True text_size 34 text_xalign 0.0 action Return("hunt")
                vbox:
                    spacing 20
                    xsize 490
                    textbutton "PVP 아레나" style "rp_button" xfill True text_size 34 text_xalign 0.0 action Return("pvp")
                    textbutton ("일일 미션 / 출석" + ("  (!)" if (G.player["daily_claimable"] or G.player["checkin_ready"]) else "")) style "rp_button" xfill True text_size 34 text_xalign 0.0 action Return("missions")
                    textbutton "랭킹" style "rp_button" xfill True text_size 34 text_xalign 0.0 action Return("ranking")
'''
s = s[:a] + hub_buttons + s[b:]
p.write_text(s, encoding="utf-8")

# ── script.rpy: 새 화면 흐름 ──
p = root.parent / "script.rpy"
s = p.read_text(encoding="utf-8")
old = '''    elif _return == "logout":'''
new = '''    elif _return == "pvp":
        call pvp_lobby
    elif _return == "missions":
        $ refresh_daily()
        call screen missions_screen
    elif _return == "ranking":
        $ refresh_ranking()
        if G.ranking:
            call screen ranking_screen
    elif _return == "logout":'''
assert old in s
s = s.replace(old, new, 1)
s += '''
label pvp_lobby:
    $ refresh_pvp()
    call screen pvp_screen
    if _return == "back":
        return
    call pvp_fight(_return)
    jump pvp_lobby

label pvp_fight(target_id):
    $ started = start_pvp(target_id)
    if not started:
        return
    call screen pvp_battle_screen
    $ outcome = _return
    $ fin = finish_pvp(outcome)
    call screen pvp_result(outcome, fin)
    return
'''
p.write_text(s, encoding="utf-8")
print("patched")
