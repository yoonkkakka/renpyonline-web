# 레이드 보스 패턴(연타/파쇄/분노) 문자열

translate schinese strings:

    old "!! 파쇄 — 지금 방어! (Space) !!"
    new "!! 粉碎 — 现在防御！(Space) !!"

    old "연속 공격!"
    new "连续攻击！"

    old "완벽 방어!"
    new "完美防御！"

    old " (연타)"
    new "（连击）"

    old "연타 예고!"
    new "连击预告！"

    old "분노 상태"
    new "暴怒状态"

    old "크아악!! 이제부터 진심이다!"
    new "啊啊啊！！现在才是认真的！"

    old "보스가 분노했다! 공격이 빨라진다!"
    new "Boss暴怒了！攻击变快了！"

    old "파쇄를 막았다! 보스가 휘청거린다!"
    new "挡住了粉碎！Boss踉跄了！"
