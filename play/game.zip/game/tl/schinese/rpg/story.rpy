﻿# TODO: Translation updated at 2026-09-28 16:13

translate schinese strings:

    # game/rpg/story.rpy:6
    old "한강 위로 롯데타워가 노을을 삼키고 있다."
    new "汉江上空，乐天塔正吞没着夕阳的余晖。"

    # game/rpg/story.rpy:6
    old "이 도시의 주인은 나야. 신참, 이름이 뭐지?"
    new "这座城市的主人是我。新人，你叫什么名字？"

    # game/rpg/story.rpy:6
    old "렌파이 온라인의 모험가야. 네 왕관을 가지러 왔어."
    new "我是렌파이 온라인的冒险者，是来取走你的王冠的。"

    # game/rpg/story.rpy:6
    old "건방지긴. 몸이 먼저 부서지는 걸 보여주지."
    new "真是嚣张。我会让你先尝尝身体被击碎的滋味。"

    # game/rpg/story.rpy:6
    old "또 왔니? 이번엔 왕관을 걸어보렴."
    new "又来了？这次就赌上王冠试试吧。"

    # game/rpg/story.rpy:6
    old "...흠, 말이 통하는 아이구나. 잠깐 방심해 줄게."
    new "……嗯，你还挺懂事的嘛，我就暂时放松一下警惕吧。"

    # game/rpg/story.rpy:6
    old "감히 여왕에게 훈계를? 용서 못 해!"
    new "竟敢教训女王？绝不饶恕！"

    # game/rpg/story.rpy:6
    old "왕관은... 네 몫이다. 이 도시를... 부탁해."
    new "王冠……归你了。这座城市……就拜托你了。"

    # game/rpg/story.rpy:6
    old "강남 대로의 신호등이 전부 붉게 꺼져 있다."
    new "江南大道上的红绿灯全都熄灭成一片死红。"

    # game/rpg/story.rpy:6
    old "치직... 통행 금지 구역이다. 시민은 즉시 후퇴하라."
    new "滋滋……此处为禁止通行区域，市民请立即撤离。"

    # game/rpg/story.rpy:6
    old "난 시민이 아니라 모험가야. 길 좀 비켜줄래?"
    new "我不是市民，是个冒险者。能让让路吗？"

    # game/rpg/story.rpy:6
    old "규정 위반 확인. 진압을 개시한다."
    new "确认违反规定，开始执行镇压。"

    # game/rpg/story.rpy:6
    old "재접근 확인. 경고는 이미 끝났다."
    new "确认再次接近，警告已经结束。"

    # game/rpg/story.rpy:6
    old "...대화 프로토콜 수신. 출력을 낮춘다."
    new "……接收到对话协议，降低输出功率。"

    # game/rpg/story.rpy:6
    old "협상 거부. 화력을 증강한다!"
    new "拒绝协商，增强火力！"

    # game/rpg/story.rpy:6
    old "치직... 시스템 종료. 시민 여러분... 안전...하게..."
    new "滋滋……系统关闭。各位市民……请务必……平安……"

    # game/rpg/story.rpy:6
    old "경복궁 담장 너머로 붉은 안개가 흘러나온다."
    new "红雾从景福宫的宫墙那头缓缓弥漫而出。"

    # game/rpg/story.rpy:6
    old "오랜 세월... 나를 잊은 자들을 기억하느냐."
    new "漫长的岁月……你可还记得那些遗忘了我的人？"

    # game/rpg/story.rpy:6
    old "난 네 원한을 몰라. 하지만 들어줄 순 있어."
    new "我不知道你的怨恨从何而来，但我愿意听你说。"

    # game/rpg/story.rpy:6
    old "들을 필요 없다. 그저 베어낼 뿐."
    new "无需聆听，只需斩断一切。"

    # game/rpg/story.rpy:6
    old "또다시 궁의 문을 넘었구나."
    new "你又一次跨过了宫门。"

    # game/rpg/story.rpy:6
    old "...누군가 내 이야기를 들어주는 건 오랜만이구나."
    new "……已经很久没有人愿意听我说话了。"

    # game/rpg/story.rpy:6
    old "동정 따위는 필요 없다!"
    new "我不需要什么同情！"

    # game/rpg/story.rpy:6
    old "이제야... 눈을 감을 수 있겠구나."
    new "如今……终于可以瞑目了。"

    # game/rpg/story.rpy:6
    old "한강의 야경 위로 마녀의 그림자가 드리운다."
    new "女巫的身影笼罩在汉江的夜景之上。"

    # game/rpg/story.rpy:6
    old "예쁜 불빛이지? 저 불빛들, 다 내 소원이란다."
    new "这些灯光很美吧？那些光，全都是我的心愿呢。"

    # game/rpg/story.rpy:6
    old "그 불빛의 주인은 시민들이야. 돌려받으러 왔어."
    new "那些灯光的主人是市民们，我是来讨回来的。"

    # game/rpg/story.rpy:6
    old "후후, 그럼 네 그림자부터 가져가 볼까?"
    new "呵呵，那我就先拿走你的影子吧？"

    # game/rpg/story.rpy:6
    old "밤이 깊었는데 또 왔니, 귀여운 손님."
    new "夜已深了，你又来了呢，可爱的客人。"

    # game/rpg/story.rpy:6
    old "어머, 재밌는 말을 하네. 한 잔 할래?"
    new "哎呀，说的话真有意思，要不要喝一杯？"

    # game/rpg/story.rpy:6
    old "감히 내 밤을 훈계해?"
    new "竟敢教训我的夜晚？"

    # game/rpg/story.rpy:6
    old "야경이... 참 예쁘구나. 처음 보는 것처럼."
    new "这夜景……真的好美啊，仿佛第一次看见一样。"

    # game/rpg/story.rpy:6
    old "홍대 뒷골목, 간판 불빛 아래에서 누군가 저격총을 어깨에 멘다."
    new "弘大后巷，招牌灯光下有人把狙击枪扛上了肩。"

    # game/rpg/story.rpy:6
    old "어이, 신입. 여기 내 구역인 건 알고 왔지?"
    new "喂，新人，你知道这里是我的地盘吧？"

    # game/rpg/story.rpy:6
    old "구역이고 뭐고 난 지나가는 중인데."
    new "什么地盘不地盘的，我只是路过而已。"

    # game/rpg/story.rpy:6
    old "지나가려면 통행료를 내야지. 몸으로!"
    new "想过路就得交过路费，用你的身体来交！"

    # game/rpg/story.rpy:6
    old "야, 또 왔네? 이번엔 좀 하나 보자."
    new "喂，又来了？这次让我瞧瞧你的本事。"

    # game/rpg/story.rpy:6
    old "...뭐야, 말 되게 잘 통하네. 한 번 봐준다."
    new "……什么嘛，还挺聊得来的，这次就放你一马。"

    # game/rpg/story.rpy:6
    old "말이 많아! 시끄러워!"
    new "废话真多！吵死了！"

    # game/rpg/story.rpy:6
    old "쳇, 세다... 다음엔 내가 이긴다."
    new "切，真强……下次一定我赢。"

    # game/rpg/story.rpy:6
    old "넥슨 사옥 카페, 모니터 불빛만 켜진 채로 누군가 키보드를 두드린다."
    new "Nexon总部咖啡厅里，只有显示器的光亮着，有人正在敲打键盘。"

    # game/rpg/story.rpy:6
    old "패치... 핫픽스... 또 패치... 집에 가고 싶다..."
    new "补丁……紧急修复……又要打补丁……好想回家……"

    # game/rpg/story.rpy:6
    old "괜찮아? 잠깐 쉬어."
    new "还好吗？稍微休息一下吧。"

    # game/rpg/story.rpy:6
    old "쉬라고? 마감이 코앞인데... 방해하지 마세요!"
    new "休息？截止日期都火烧眉毛了……请不要打扰我！"

    # game/rpg/story.rpy:6
    old "또 왔어요? 저 야근 중인데..."
    new "你又来了？我正在加班呢……"

    # game/rpg/story.rpy:6
    old "...사실 오늘 처음 누가 걱정해 줬네요. 고마워요."
    new "……其实今天是第一次有人关心我，谢谢你。"

    # game/rpg/story.rpy:6
    old "마감이 코앞이라고요!!"
    new "截止日期都快到了啊！！"

    # game/rpg/story.rpy:6
    old "퇴근...할 수 있는 건가요... 감사합니다..."
    new "我……终于可以下班了吗……谢谢你……"

    # game/rpg/story.rpy:6
    old "도로가 꽉 막혔다. 경적 소리 사이로 검은 머리 사내가 웃는다."
    new "道路被堵得水泄不通，喇叭声中一个黑发男人露出了笑容。"

    # game/rpg/story.rpy:6
    old "하하, 퇴근길은 지옥이지. 내가 그렇게 만들었으니까."
    new "哈哈，下班的路就是地狱，因为这都是我一手造成的。"

    # game/rpg/story.rpy:6
    old "그 정체를 오늘 풀어주겠어."
    new "今天我就要把这堵塞给解开。"

    # game/rpg/story.rpy:6
    old "풀린다고? 이 도시가 그렇게 쉽게 뚫릴 것 같아?"
    new "解开？你以为这座城市会这么容易被打通吗？"

    # game/rpg/story.rpy:6
    old "또 막히러 왔구나!"
    new "又来添堵了啊！"

    # game/rpg/story.rpy:6
    old "...사실 나도 막히는 거 싫어. 좀 풀어줄게."
    new "……其实我也讨厌堵车，就稍微给你放行吧。"

    # game/rpg/story.rpy:6
    old "감히 내 정체를 건드려?"
    new "竟敢动我的堵塞？"

    # game/rpg/story.rpy:6
    old "뚫렸다... 오랜만에... 시원하네."
    new "打通了……好久没这么畅快过了。"

    # game/rpg/story.rpy:6
    old "롯데타워 꼭대기에서 거대한 그림자가 내려다본다."
    new "乐天塔顶端，一道巨大的身影俯视着下方。"

    # game/rpg/story.rpy:6
    old "...쿵. (거대한 토끼가 왕관을 고쳐 쓴다.)"
    new "……咚。（巨大的兔子重新戴正了王冠。）"

    # game/rpg/story.rpy:6
    old "이렇게 큰 토끼는 처음 보는데."
    new "还是第一次见到这么大的兔子呢。"

    # game/rpg/story.rpy:6
    old "쿵! 쿵! (발구르기에 도시가 흔들린다.)"
    new "咚！咚！（跺脚声让整座城市为之震动。）"

    # game/rpg/story.rpy:6
    old "쿵! (당근을 내놓으라는 눈빛이다.)"
    new "咚！（那眼神像是在说，快把胡萝卜交出来。）"

    # game/rpg/story.rpy:6
    old "...쿵. (어쩐지 조금 부드러운 눈빛이다.)"
    new "……咚。（不知为何，眼神变得温柔了几分。）"

    # game/rpg/story.rpy:6
    old "쿠우웅!! (거대한 발이 치켜올라간다!)"
    new "轰咚！！（巨大的脚高高抬起！）"

    # game/rpg/story.rpy:6
    old "...쿵. (왕관을 두고 폴짝 사라진다.)"
    new "……咚。（留下王冠，蹦跳着消失了。）"

    # game/rpg/story.rpy:6
    old "김포 공항 활주로에 검은 머리의 여인이 서 있다."
    new "金浦机场的跑道上，站着一位黑发女子。"

    # game/rpg/story.rpy:6
    old "탑승 수속은 끝났어. 다음 목적지는 이 도시 밖이지."
    new "登机手续已经办完，下一个目的地是这座城市之外。"

    # game/rpg/story.rpy:6
    old "이 도시를 두고 가게 놔둘 순 없어."
    new "我不能让你就这样丢下这座城市离开。"

    # game/rpg/story.rpy:6
    old "그럼 이륙 전에 막아 보시지!"
    new "那就在起飞之前阻止我看看啊！"

    # game/rpg/story.rpy:6
    old "탑승 시간이 다 됐는데... 또 방해?"
    new "登机时间都快到了……又来打扰我？"

    # game/rpg/story.rpy:6
    old "...뭐, 한 편쯤 늦어도 되겠지."
    new "……嘛，晚一班航班也没关系吧。"

    # game/rpg/story.rpy:6
    old "이륙 방해 시 강제 배제한다!"
    new "妨碍起飞者，将被强制排除！"

    # game/rpg/story.rpy:6
    old "이륙 취소... 이 도시에도 나쁘지 않네."
    new "取消起飞……这座城市，似乎也不错呢。"

    # game/rpg/story.rpy:6
    old "국정원 청사의 태극기가 바람에 흔들린다."
    new "国情院大楼上的太极旗在风中飘扬。"

    # game/rpg/story.rpy:6
    old "귀하는 1급 기밀 구역에 접근했습니다."
    new "您已接近一级机密区域。"

    # game/rpg/story.rpy:6
    old "기밀이라니, 난 그냥 모험가일 뿐인데."
    new "机密什么的，我只是个普通的冒险者而已。"

    # game/rpg/story.rpy:6
    old "모험가는 보통 여기까지 못 옵니다. 작전 개시."
    new "普通冒险者是到不了这里的，开始执行行动。"

    # game/rpg/story.rpy:6
    old "또 귀하입니까. 보고서 쓰기 귀찮군요."
    new "又是您啊，写报告真是麻烦。"

    # game/rpg/story.rpy:6
    old "...일리가 있군요. 잠시 경계를 낮추겠습니다."
    new "……说得有道理，暂时降低警戒。"

    # game/rpg/story.rpy:6
    old "협상 시도 자체가 위협 행위입니다."
    new "尝试协商本身就是一种威胁行为。"

    # game/rpg/story.rpy:6
    old "보고서에는... 뭐라고 쓴다."
    new "报告上……该怎么写呢。"

    # game/rpg/story.rpy:6
    old "서울역 승강장, 모니터 속 데이터가 미친 듯이 흐른다."
    new "首尔站的月台上，显示器中的数据疯狂地流淌着。"

    # game/rpg/story.rpy:6
    old "접속을 환영해요. 이미 당신 정보는 다 가져왔답니다."
    new "欢迎连接。您的所有信息我早已全部掌握了。"

    # game/rpg/story.rpy:6
    old "그런 건 내 몸에 새겨진 게 아니잖아."
    new "那种东西又没有刻在我的身体上。"

    # game/rpg/story.rpy:6
    old "그럼 몸을 해킹해 볼까요?"
    new "那就来入侵一下您的身体吧？"

    # game/rpg/story.rpy:6
    old "재접속 확인. 로그인 기록이 남아 있어요."
    new "确认再次连接，登录记录仍然留存。"

    # game/rpg/story.rpy:6
    old "...어라, 방화벽이 조금 열렸네요."
    new "……咦，防火墙好像打开了一点呢。"

    # game/rpg/story.rpy:6
    old "시스템에 무례하게 접근하지 마세요!"
    new "请不要如此无礼地接近系统！"

    # game/rpg/story.rpy:6
    old "연결... 끊김. 이제 자유롭게... 로그아웃."
    new "连接……已断开。如今可以自由地……登出了。"

    # game/rpg/story.rpy:6
    old "한강 위, 파도가 하늘로 솟구친다."
    new "汉江之上，巨浪直冲天际。"

    # game/rpg/story.rpy:6
    old "인간이여, 바다는 이 도시의 시작이었다."
    new "人类啊，大海曾是这座城市的起点。"

    # game/rpg/story.rpy:6
    old "지금은 그 위에 사람들이 살고 있어."
    new "而如今，人们已经生活在这片土地之上了。"

    # game/rpg/story.rpy:6
    old "그렇다면 파도로 씻어 내리마!"
    new "那就让海浪将一切冲刷殆尽吧！"

    # game/rpg/story.rpy:6
    old "다시 바다 앞에 섰구나."
    new "你又一次站到了大海面前。"

    # game/rpg/story.rpy:6
    old "...바다도 사람의 이야기를 듣는 법이지."
    new "……大海，也是懂得聆听人心的。"

    # game/rpg/story.rpy:6
    old "해일이 너를 삼키리라!"
    new "巨浪将会把你吞没！"

    # game/rpg/story.rpy:6
    old "바다는... 다시 잔잔해질 것이다."
    new "大海……终将重归平静。"

    # game/rpg/story.rpy:6
    old "남산타워 아래, 우산을 든 귀신이 쓸쓸히 서 있다."
    new "南山塔下，一个撑着伞的幽灵孤零零地站着。"

    # game/rpg/story.rpy:6
    old "비가 오면 누군가 나를 기억해 줄까..."
    new "如果下雨了，会有人记得我吗……"

    # game/rpg/story.rpy:6
    old "나는 기억할게. 그러니 이제 쉬어."
    new "我会记得你的，所以现在好好安息吧。"

    # game/rpg/story.rpy:6
    old "그 말... 거짓이면 우산으로 찌를 거야."
    new "这句话……如果是假的，我就用伞刺你。"

    # game/rpg/story.rpy:6
    old "또 비가 오네... 너도 왔구나."
    new "又下雨了呢……你也来了啊。"

    # game/rpg/story.rpy:6
    old "...정말 기억해 줄 거야? 알겠어, 잠깐만."
    new "……你真的会记得我吗？好吧，那就等一下。"

    # game/rpg/story.rpy:6
    old "거짓말쟁이!! 다들 그렇게 말했어!"
    new "骗子！！大家都是这么说的！"

    # game/rpg/story.rpy:6
    old "비가... 그쳤네. 고마워."
    new "雨……停了呢，谢谢你。"

    # game/rpg/story.rpy:6
    old "무대 조명이 켜지고 환호성이 쏟아진다."
    new "舞台灯光亮起，欢呼声如潮水般涌来。"

    # game/rpg/story.rpy:6
    old "오늘 무대의 게스트가 네 차례야! 준비됐어?"
    new "今天舞台的嘉宾轮到你了！准备好了吗？"

    # game/rpg/story.rpy:6
    old "난 노래는 못 하는데."
    new "可我不会唱歌啊。"

    # game/rpg/story.rpy:6
    old "괜찮아, 싸움도 무대니까! 앙코르는 없어!"
    new "没关系，打斗也是一种舞台表演！没有安可！"

    # game/rpg/story.rpy:6
    old "재방문 팬? 이번엔 더 화려하게 갈게!"
    new "回头客粉丝？这次要更华丽地登场！"

    # game/rpg/story.rpy:6
    old "어머, 팬 서비스 잘 아네? 좋아, 한 곡 서비스!"
    new "哎呀，还挺懂粉丝福利的嘛？好，加送一首歌！"

    # game/rpg/story.rpy:6
    old "무대 매너 없이 끼어들지 마!"
    new "别这么没规矩地闯入舞台！"

    # game/rpg/story.rpy:6
    old "우와... 오늘 무대... 최고였어."
    new "哇……今天的舞台……真的太棒了。"

    # game/rpg/story.rpy:6
    old "서울 상공에 드론 편대가 별처럼 떠 있다."
    new "首尔上空，无人机编队如繁星般漂浮着。"

    # game/rpg/story.rpy:6
    old "관제 완료. 이 하늘은 제가 책임져요."
    new "管制完毕，这片天空由我负责。"

    # game/rpg/story.rpy:6
    old "하늘에 그렇게 많은 눈은 필요 없잖아."
    new "天空上应该不需要这么多双眼睛吧。"

    # game/rpg/story.rpy:6
    old "안전을 위해서예요. 전 편대, 사격 준비!"
    new "这都是为了安全。全编队，准备射击！"

    # game/rpg/story.rpy:6
    old "재진입 확인. 편대 전개!"
    new "确认再次进入，编队展开！"

    # game/rpg/story.rpy:6
    old "...일리 있어요. 편대 절반을 착륙시킬게요."
    new "……有道理，我会让一半编队降落的。"

    # game/rpg/story.rpy:6
    old "안전 위협 발언 감지! 전 편대 발사!"
    new "检测到威胁安全的言论！全编队开火！"

    # game/rpg/story.rpy:6
    old "관제 종료... 하늘이 조용하네요."
    new "管制结束……天空变得安静了呢。"

    # game/rpg/story.rpy:6
    old "하늘이 붉게 갈라지고, 서울의 빌딩 숲이 촉수로 일어선다."
    new "天空被染成血红并裂开，首尔的高楼森林化作触手般耸立而起。"

    # game/rpg/story.rpy:6
    old "모든 것의 끝이 왔다. 이 도시는 여기서 멈춘다."
    new "万物的终结已经降临，这座城市将在此终止。"

    # game/rpg/story.rpy:6
    old "아직 끝이 아니야. 내가 여기 있으니까."
    new "还没有结束，因为我就在这里。"

    # game/rpg/story.rpy:6
    old "그렇다면 마지막 시험이다. 서울의 종말이 너를 삼키리라."
    new "那么这将是最后的考验，首尔的终结会将你彻底吞没。"

    # game/rpg/story.rpy:6
    old "또다시 종말 앞에 섰구나."
    new "你又一次站到了终结面前。"

    # game/rpg/story.rpy:6
    old "...너의 의지를 시험해 보자. 잠시 힘을 늦추겠다."
    new "……那就来试探你的意志吧，暂时收敛一下力量。"

    # game/rpg/story.rpy:6
    old "종말 앞에서 말이 통할 줄 알았느냐!"
    new "你以为在终结面前还能讲道理吗！"

    # game/rpg/story.rpy:6
    old "...서울은 계속되겠구나. 그것이 너의 선택이라면."
    new "……看来首尔会继续存在下去了。既然这是你的选择。"

    # game/rpg/story.rpy:162
    old "어떻게 상대할까?"
    new "要怎么应对呢？"

