﻿# TODO: Translation updated at 2026-09-28 18:01

translate tchinese strings:

    # game/rpg/screens_raid.rpy:42
    old "레이드 2~4인"
    new "團本 2~4人"

    # game/rpg/screens_raid.rpy:63
    old "레이드 매칭 대기 중..."
    new "團本配對中…"

    # game/rpg/screens_raid.rpy:64
    old "대기 인원  %d / 4"
    new "等待人數  %d / 4"

    # game/rpg/screens_raid.rpy:67
    old "%.0f초 후 자동 시작 (인원이 차면 즉시 시작)"
    new "%.0f秒後自動開始（人數滿員則立即開始）"

    # game/rpg/screens_raid.rpy:69
    old "2명 이상 모이면 카운트다운이 시작돼요."
    new "滿2人以上就會開始倒數計時。"

    # game/rpg/screens_raid.rpy:87
    old " (나)"
    new "（我）"

    # game/rpg/screens_raid.rpy:90
    old "이탈함"
    new "已離開"

    # game/rpg/screens_raid.rpy:92
    old "전투 불능"
    new "戰鬥不能"

    # game/rpg/screens_raid.rpy:94
    old "기여 %s"
    new "貢獻 %s"

    # game/rpg/screens_raid.rpy:257
    old "레이드 승리!"
    new "團本勝利!"

    # game/rpg/screens_raid.rpy:258
    old "내 기여도  %.0f%%"
    new "我的貢獻度  %.0f%%"

    # game/rpg/screens_raid.rpy:279
    old "보스는 쓰러졌지만 보상 수령에 실패했어요."
    new "首領雖然倒下了，但領取獎勵失敗了。"

    # game/rpg/screens_raid.rpy:281
    old "전멸했어요..."
    new "全滅了…"

    # game/rpg/screens_raid.rpy:284
    old "시간 초과로 레이드가 종료됐어요."
    new "因超時，團本已結束。"

    # game/rpg/screens_raid.rpy:286
    old "레이드에서 물러났어요"
    new "已退出團本"

