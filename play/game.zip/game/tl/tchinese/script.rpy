﻿# TODO: Translation updated at 2026-09-28 16:26

translate tchinese strings:

    # game/script.rpy:12
    old "게임을 불러오는 중"
    new "正在載入遊戲"

    # game/script.rpy:12
    old "잠시만 기다려 주세요"
    new "請稍候片刻"

