# PVP / 일일 미션 / 출석 / 랭킹 화면 (귀여운 모바일 스타일)

# ── PVP 아레나 로비 ──────────────────────────────────────────
screen pvp_screen():
    $ p = G.player
    $ pv = p["pvp"]
    add "images/bg/t15.webp"
    add Solid("#2a1d5ab8")
    use topbar
    frame:
        style "rp_panel"
        xpos 40
        ypos 128
        xsize 540
        ysize 800
        padding (30, 24)
        vbox:
            spacing 10
            text "PVP 아레나" style "rp_text" size 44 color "#fff1a8"
            text pv["tier"] style "rp_text" size 72 color "#ffe27a" outlines [(8, "#c2437a", 0, 3)]
            text ("레이팅  %d" % pv["rating"]) style "rp_text" size 36
            text ("%d승  %d패" % (pv["wins"], pv["losses"])) style "rp_text" size 30
            null height 6
            hbox:
                spacing 8
                add "gui/rp/icon_crystal.png" zoom 0.8 yalign 0.5
                text ("PVP 코인  %d" % pv["coins"]) style "rp_text" size 32 color "#b6f0ff"
            textbutton ("코인 %d개  >  강화석 1개" % G.meta["pvp"]["coin_per_stone"]):
                style "rp_btn_mint"
                xfill True
                text_size 26
                sensitive pv["coins"] >= G.meta["pvp"]["coin_per_stone"]
                action Function(pvp_exchange, 1)
            null height 6
            text "상대는 실시간으로 움직이는 AI예요.\n이기면 레이팅, 코인, 골드를 얻고\n져도 골드와 코인을 조금 받아요.\n\n스킬을 이어 쓰면 콤보로 피해가 늘고,\n기절하면 잠깐 조작할 수 없어요." style "rp_text" size 22 color "#e6dcff"
            textbutton "상대 새로고침" style "rp_button" xfill True text_size 26 action Function(refresh_pvp)

    frame:
        style "rp_panel"
        xpos 600
        ypos 128
        xsize 800
        ysize 800
        padding (26, 20)
        vbox:
            spacing 10
            text "도전 상대" style "rp_text" size 40 color "#fff1a8"
            for o in G.opps:
                button:
                    style "rp_card_btn"
                    xfill True
                    ysize 118
                    padding (22, 8)
                    action Return(o["id"])
                    hbox:
                        spacing 20
                        yalign 0.5
                        vbox:
                            xsize 480
                            yalign 0.5
                            text o["name"] style "rp_text" size 34 color ("#ffe9a8" if not o["bot"] else "#ffffff")
                            text ("Lv.%d   %s %d" % (o["level"], o["rating_tier"], o["rating"])) style "rp_text" size 24 color "#dcd4ff"
                        vbox:
                            xsize 220
                            yalign 0.5
                            text o["difficulty"] style "rp_text" size 28 color ("#ffb08c" if o["difficulty"] == "어려움" else ("#b6ffca" if o["difficulty"] == "쉬움" else "#ffe27a")) xalign 0.5
                            text "도전 >" style "rp_text" size 28 xalign 0.5

    frame:
        style "rp_panel"
        xpos 1420
        ypos 128
        xsize 460
        ysize 800
        padding (28, 20)
        vbox:
            spacing 10
            text "방어 기록" style "rp_text" size 40 color "#fff1a8"
            if not G.pvp_log:
                text "아직 도전받은 기록이 없어요." style "rp_text" size 22 color "#dcd4ff"
            for e in G.pvp_log:
                text ("%s 님의 도전  %s\n%s" % (e["who"], "방어 성공" if e["won"] else "방어 실패", time_ago(e["t"]))) style "rp_text" size 24 color ("#b6ffca" if e["won"] else "#ffb0b0")
    use back_button

# ── PVP 전투 ─────────────────────────────────────────────────
screen pvp_battle_screen():
    $ now = time.time()
    $ bt = PB
    $ me = bt.me
    $ op = bt.opp
    timer 0.05 repeat True action Function(pb_tick)
    key "K_1" action Function(pb_skill, 1)
    key "K_2" action Function(pb_skill, 2)
    key "K_3" action Function(pb_skill, 3)
    key "K_4" action Function(pb_skill, 4)
    key "K_5" action Function(pb_skill, 5)
    key "K_6" action Function(pb_skill, 6)
    key "K_7" action Function(pb_skill, 7)
    key "K_8" action Function(pb_skill, 8)
    key "K_KP1" action Function(pb_skill, 1)
    key "K_KP2" action Function(pb_skill, 2)
    key "K_KP3" action Function(pb_skill, 3)
    key "K_KP4" action Function(pb_skill, 4)
    key "K_KP5" action Function(pb_skill, 5)
    key "K_KP6" action Function(pb_skill, 6)
    key "K_KP7" action Function(pb_skill, 7)
    key "K_KP8" action Function(pb_skill, 8)
    key "K_SPACE" action Function(pb_guard)
    key "game_menu" action Function(pb_flee)

    add bt.bg_path
    add Solid("#2a1d5a30")
    add Transform(bt.opp_img, fit="contain", xysize=(700, 720)):
        align (0.86, 0.60)
        xoffset (random.randint(-8, 8) if (persistent.opt_shake and now < op.hit_until) else 0)
        alpha (0.65 if now < op.hit_until else 1.0)
    add avatar_disp(520, 720):
        pos (70, 190)
        xoffset (random.randint(-8, 8) if (persistent.opt_shake and now < me.hit_until) else 0)
        alpha (0.7 if bt.guarding() else 1.0)
    if bt.guarding():
        add Solid("#8fd0ff40") xysize (520, 720) pos (70, 190)
    if bt.stunned():
        text "기절!" style "rp_text" size 96 color "#ffe27a" xpos 240 ypos 380 outlines [(9, "#c2437a", 0, 3)]
    if now < me.hit_until:
        add Solid("#ff5a8a28")

    # 유혈 이펙트(설정에서 끌 수 있음)
    if persistent.opt_blood:
        for st in bt.stains:
            add "gui/rp/blood_%d.png" % st["img"] at blood_fx(st["z"], st["rot"], 0.42) pos (st["x"], st["y"])
        for bl in bt.blood:
            $ bage = now - bl["t"]
            if bage < bl["life"]:
                add "gui/rp/blood_%d.png" % bl["img"] at blood_fx(bl["z"] * (0.55 + min(bage, 0.3) * 1.6), bl["rot"], max(0.0, 1.0 - bage / bl["life"])) pos (bl["x"], bl["y"])
        if now < me.hit_until:
            add "gui/rp/blood_vignette.png"
        elif me.hp < me.hp_max * 0.3:
            add "gui/rp/blood_vignette.png" alpha (0.55 + 0.3 * math.sin(now * 6))

    # 체력 바
    frame:
        style "rp_panel"
        xpos 24
        ypos 20
        xsize 730
        padding (26, 12)
        vbox:
            spacing 3
            text ("%s  Lv.%d" % (me.name, me.level)) style "rp_text" size 30 color "#b6f0ff"
            bar value StaticValue(me.hp, me.hp_max) xsize 676 ysize 26 left_bar pill("#47d16b") right_bar pill("track") thumb None
            text ("%s / %s" % (fmt(me.hp), fmt(me.hp_max))) style "rp_text" size 20
    frame:
        style "rp_panel"
        xalign 1.0
        xoffset -24
        ypos 20
        xsize 730
        padding (26, 12)
        vbox:
            spacing 3
            hbox:
                xfill True
                text ("%s  Lv.%d" % (op.name, op.level)) style "rp_text" size 30 color "#fff1a8"
                text bt.opp_info["difficulty"] style "rp_text" size 24 xalign 1.0 yalign 0.5
            bar value StaticValue(op.hp, op.hp_max) xsize 676 ysize 26 left_bar pill("#e0475b") right_bar pill("track") thumb None
            text ("%s / %s" % (fmt(op.hp), fmt(op.hp_max))) style "rp_text" size 20
    hbox:
        xalign 0.5
        ypos 24
        use chip("gui/rp/icon_gem.png", fmt_time(bt.time_left()), "#ffffff")
    textbutton "항복 (Esc)":
        style "rp_btn_pink"
        xpos 24
        ypos 158
        text_size 24
        action Function(pb_flee)
    if bt.combo >= 2:
        text ("COMBO x%d   +%d%%" % (bt.combo, int(G.meta["combo"]["step"] * 100 * bt.combo))) style "rp_text" size 56 color "#fff1a8" xalign 0.5 ypos 150 outlines [(8, "#c2437a", 0, 3)]

    # 내 상태 / 스킬 바
    frame:
        style "rp_panel"
        xpos 24
        yalign 1.0
        yoffset -20
        xsize 440
        padding (26, 16)
        vbox:
            spacing 4
            text ("기력 %d / %d" % (me.mana, me.st["mana"])) style "rp_text" size 24 color "#d4e4ff"
            bar value StaticValue(me.mana, me.st["mana"]) xsize 386 ysize 18 left_bar pill("#4d8dff") right_bar pill("track") thumb None
    hbox:
        xpos 490
        yalign 1.0
        yoffset -20
        spacing 10
        for sk in G.meta["skills"]:
            use skill_slot(sk, bt)
        use guard_slot(bt)
    vbox:
        xalign 1.0
        xoffset -30
        yalign 1.0
        yoffset -170
        spacing 2
        for (t, c) in (bt.log if persistent.opt_log else []):
            text t style "rp_text" size 22 color c xalign 1.0
    for f in (bt.floaters if persistent.opt_floaters else []):
        $ age = now - f["t"]
        $ ft = f["text"]
        text ft at rp_fade(max(0.0, 1.0 - max(0.0, age - 0.5) * 2.0)):
            style "rp_text"
            size f["size"]
            color f["color"]
            bold True
            outlines [(6, "#3a2a6a", 0, 2)]
            xpos f["x"]
            ypos int(f["y"] - age * 110)

screen pvp_result(outcome, fin):
    modal True
    add PB.bg_path
    add Solid("#2a1d5acc")
    frame:
        style "rp_panel"
        align (0.5, 0.5)
        xsize 800
        padding (54, 40)
        vbox:
            spacing 16
            xfill True
            if fin is None:
                text "결과를 서버에 반영하지 못했어요." style "rp_text" size 34 xalign 0.5 color "#ffb0b0"
            elif fin["won"]:
                text "승리!" style "rp_text" size 96 xalign 0.5 color "#fff3a8" outlines [(10, "#c2437a", 0, 4)]
            else:
                text "패배..." style "rp_text" size 90 xalign 0.5 color "#ffb0c8"
            if fin is not None:
                $ rw = fin["rewards"]
                text ("레이팅  %+d   (%d  %s)" % (fin["delta"], fin["rating"], fin["tier"])) style "rp_text" size 34 xalign 0.5 color ("#b6ffca" if fin["delta"] > 0 else "#ffb0b0")
                hbox:
                    xalign 0.5
                    spacing 10
                    add "gui/rp/icon_coin.png" yalign 0.5
                    text ("골드 +%s" % fmt(rw["gold"])) style "rp_text" size 32 color "#ffe27a"
                text ("PVP 코인 +%d" % rw["coins"]) style "rp_text" size 32 xalign 0.5 color "#b6f0ff"
                if rw.get("crystals"):
                    hbox:
                        xalign 0.5
                        spacing 10
                        add "gui/rp/icon_crystal.png" yalign 0.5
                        text ("각성 결정 +%d" % rw["crystals"]) style "rp_text" size 32 color "#ffc0ea"
            textbutton "확인" style "rp_btn_mint" xfill True text_size 38 action Return(True)

# ── 일일 미션 / 출석 ─────────────────────────────────────────
screen missions_screen():
    $ d = G.daily
    add "images/bg/t08.webp"
    add Solid("#2a1d5ab0")
    use topbar
    frame:
        style "rp_panel"
        xpos 40
        ypos 128
        xsize 1100
        ysize 800
        padding (30, 22)
        vbox:
            spacing 12
            text "일일 미션" style "rp_text" size 44 color "#fff1a8"
            text "매일 오전 0시(KST)에 초기화돼요." style "rp_text" size 22 color "#dcd4ff"
            for m in d["missions"]:
                frame:
                    background Frame("gui/rp/card.png", 30, 30, 30, 30)
                    xfill True
                    padding (22, 12)
                    hbox:
                        spacing 20
                        vbox:
                            xsize 620
                            yalign 0.5
                            text m["name"] style "rp_text" size 32 color ("#b6ffca" if m["done"] else "#ffe9a8")
                            bar value StaticValue(m["prog"], m["need"]) xsize 580 ysize 16 left_bar pill("#5fd0ff") right_bar pill("track") thumb None
                            text ("%d / %d   보상: 골드 %s, 강화석 %d" % (m["prog"], m["need"], fmt(m["gold"]), m["stones"])) style "rp_text" size 20 color "#dcd4ff"
                        textbutton ("수령 완료" if m["claimed"] else "보상 받기"):
                            style "rp_btn_mint"
                            xsize 220
                            yalign 0.5
                            text_size 28
                            sensitive (m["done"] and not m["claimed"])
                            action Function(claim_mission, m["id"])
            null height 6
            frame:
                background Frame("gui/rp/card_purple.png", 30, 30, 30, 30)
                xfill True
                padding (22, 12)
                hbox:
                    spacing 20
                    vbox:
                        xsize 620
                        yalign 0.5
                        text "올 클리어 보너스" style "rp_text" size 32 color "#ffd27a"
                        text ("강화석 +%d, 각성 결정 +1, 경험치 부스트 %d분" % (d["bonus"]["stones"], d["bonus"]["boost_seconds"] // 60)) style "rp_text" size 22 color "#f0dcff"
                    textbutton ("수령 완료" if d["bonus_claimed"] else "보너스 받기"):
                        style "rp_btn_pink"
                        xsize 220
                        yalign 0.5
                        text_size 28
                        sensitive (d["all_claimed"] and not d["bonus_claimed"])
                        action Function(claim_mission, "bonus")

    frame:
        style "rp_panel"
        xpos 1160
        ypos 128
        xsize 720
        ysize 800
        padding (30, 22)
        vbox:
            spacing 14
            text "출석 체크" style "rp_text" size 44 color "#fff1a8"
            $ ck = d["checkin"]
            text ("연속 출석  %d일" % ck["streak"]) style "rp_text" size 34 color "#ffe27a"
            hbox:
                spacing 8
                for day in range(1, 8):
                    $ got = day <= checkin_days(ck)
                    frame:
                        background Frame("gui/rp/card_blue.png" if got else "gui/rp/card.png", 30, 30, 30, 30)
                        xsize 86
                        ysize 100
                        padding (4, 4)
                        vbox:
                            xalign 0.5
                            yalign 0.5
                            text ("%d일" % day) style "rp_text" size 24 xalign 0.5 color ("#ffd27a" if day == 7 else "#ffffff")
                            text ("완료" if got else ("대박" if day == 7 else "")) style "rp_text" size 18 xalign 0.5
            if ck["ready"]:
                $ pr = ck["preview"]
                text ("오늘의 보상 (%d일차)" % pr["day"]) style "rp_text" size 28 color "#fff1a8"
                text ("골드 %s\n강화석 %d%s" % (fmt(pr["gold"]), pr["stones"], "\n경험치 부스트 1시간" if pr["boost_seconds"] else "")) style "rp_text" size 28
                textbutton "출석하기" style "rp_btn_pink" xfill True text_size 42 action Function(do_checkin)
            else:
                text "오늘은 이미 출석했어요.\n내일 또 만나요!" style "rp_text" size 28 color "#b6ffca"
            text "7일째는 강화석과 경험치 부스트가 듬뿍!\n하루를 거르면 처음부터 다시 시작해요." style "rp_text" size 22 color "#dcd4ff"
    use back_button

# ── 랭킹 ─────────────────────────────────────────────────────
screen ranking_screen():
    $ rk = G.ranking
    add "images/bg/t08.webp"
    add Solid("#2a1d5ab0")
    use topbar
    frame:
        style "rp_panel"
        xpos 40
        ypos 128
        xsize 900
        ysize 800
        padding (30, 22)
        vbox:
            spacing 8
            text "레벨 랭킹" style "rp_text" size 44 color "#fff1a8"
            for i, r in enumerate(rk["level"]):
                text ("%2d위   %s   Lv.%d" % (i + 1, r["name"], r["level"])) style "rp_text" size 30 color ("#ffe27a" if i == 0 else ("#ffffff" if r["name"] != G.player["username"] else "#b6ffca"))
            null height 10
            text ("내 순위: %s위 / %d명" % (rk["my_level_rank"], rk["total"])) style "rp_text" size 28 color "#b6ffca"
    frame:
        style "rp_panel"
        xpos 960
        ypos 128
        xsize 920
        ysize 800
        padding (30, 22)
        vbox:
            spacing 8
            text "PVP 랭킹" style "rp_text" size 44 color "#fff1a8"
            for i, r in enumerate(rk["pvp"]):
                text ("%2d위   %s   %s  %d" % (i + 1, r["name"], r["tier"], r["rating"])) style "rp_text" size 30 color ("#ffe27a" if i == 0 else ("#ffffff" if r["name"] != G.player["username"] else "#b6ffca"))
            null height 10
            text ("내 순위: %s위 / %d명" % (rk["my_pvp_rank"], rk["total"])) style "rp_text" size 28 color "#b6ffca"
    use back_button
