# 게임 설정 화면: ESC / 오른쪽 클릭으로 열리는 렌파이 기본 메뉴를 완전히 대체한다.
# (script.rpy 의 label game_menu 에서 이 화면을 호출)

screen setting_card(title, tone="card"):
    frame:
        background Frame("gui/rp/%s.png" % tone, 30, 30, 30, 30)
        xfill True
        padding (28, 16, 28, 20)
        vbox:
            spacing 10
            text title style "rp_text" size 34 color "#fff1a8"
            transclude

screen slider_row(label, value):
    hbox:
        spacing 18
        yalign 0.5
        text label style "rp_text" size 28 xsize 150 yalign 0.5
        bar value value xsize 440 ysize 26 yalign 0.5 left_bar pill("#ff8fd0") right_bar pill("track") thumb "gui/rp/knob.png" thumb_offset 20

screen toggle_row(label, hint, field):
    hbox:
        spacing 16
        vbox:
            xsize 430
            yalign 0.5
            text label style "rp_text" size 28
            text hint style "rp_text" size 20 color "#dcd4ff"
        textbutton (_("켜짐") if getattr(persistent, field) else _("꺼짐")):
            style ("rp_btn_mint" if getattr(persistent, field) else "rp_button")
            xsize 180
            yalign 0.5
            text_size 28
            action ToggleField(persistent, field)

screen rp_settings():
    modal True
    zorder 200
    key "game_menu" action Return()
    add Solid("#2a1d5ad0")
    add "gui/rp/sparkle.png" pos (170, 130) zoom 1.4 at rp_bounce
    add "gui/rp/sparkle.png" pos (1700, 900) zoom 1.2 at rp_bounce
    add "gui/rp/deco_heart.png" pos (1730, 150) zoom 1.6 at rp_bounce
    frame:
        style "rp_panel"
        align (0.5, 0.5)
        xsize 1560
        ysize 1050
        padding (46, 18, 46, 18)
        vbox:
            spacing 12
            hbox:
                xfill True
                hbox:
                    spacing 16
                    add "gui/rp/ic_gear.png" zoom 0.55 yalign 0.5
                    text _("설정") style "rp_text" size 66 color "#fff3a8" yalign 0.5 outlines [(8, "#6a3aa8", 0, 3)]
                    text (_("렌파이 온라인 v%s") % config.version) style "rp_text" size 22 color "#dcd4ff" yalign 0.9
                textbutton _("닫기 (Esc)") style "rp_btn_mint" xalign 1.0 yalign 0.5 xsize 300 text_size 34 action Return()
            hbox:
                spacing 30
                vbox:
                    xsize 700
                    spacing 12
                    use setting_card(_("소리")):
                        use slider_row(_("배경음"), Preference("music volume"))
                        use slider_row(_("효과음"), Preference("sound volume"))
                        textbutton _("전체 음소거") style "rp_button" xsize 260 text_size 26 action Preference("all mute", "toggle")
                    use setting_card(_("화면")):
                        hbox:
                            spacing 18
                            textbutton _("창 모드") style "rp_button" xsize 250 text_size 28 action Preference("display", "window")
                            textbutton _("전체 화면") style "rp_button" xsize 250 text_size 28 action Preference("display", "fullscreen")
                        hbox:
                            spacing 12
                            textbutton "한국어" style ("rp_btn_mint" if _preferences.language is None else "rp_button") xsize 160 text_size 24 action Language(None)
                            textbutton "简体中文" style ("rp_btn_mint" if _preferences.language == "schinese" else "rp_button") xsize 160 text_size 24 action Language("schinese")
                            textbutton "繁體中文" style ("rp_btn_mint" if _preferences.language == "tchinese" else "rp_button") xsize 160 text_size 24 action Language("tchinese")
                    use setting_card(_("스토리 대사")):
                        use slider_row(_("대사 속도"), Preference("text speed"))
                    use setting_card(_("조작법")):
                        text _("1~8 스킬  /  Space 방어 자세") style "rp_text" size 26
                        text _("Esc 설정 (전투 중에는 도망)") style "rp_text" size 24
                        text _("스킬을 2초 안에 이어 쓰면 콤보로 피해 최대 +20%!") style "rp_text" size 22 color "#ffe1f3"
                vbox:
                    xsize 700
                    spacing 12
                    use setting_card(_("전투 효과"), "card_purple"):
                        use toggle_row(_("화면 흔들림"), _("맞을 때 캐릭터가 부르르 떨려요"), "opt_shake")
                        use toggle_row(_("피해 숫자"), _("떠오르는 데미지/회복 숫자"), "opt_floaters")
                        use toggle_row(_("전투 기록"), _("오른쪽 아래 전투 로그"), "opt_log")
                        use toggle_row(_("유혈 표현"), _("맞을 때 피가 튀는 연출"), "opt_blood")
                        use toggle_row(_("거친 대사"), _("보스 외침과 대사에 거친 말투"), "opt_rude")
                    use setting_card(_("계정"), "card_blue"):
                        if G.player:
                            text ("%s   Lv.%d" % (G.player["username"], G.player["level"])) style "rp_text" size 30
                        else:
                            text _("아직 로그인하지 않았어요") style "rp_text" size 26 color "#dcd4ff"
                        textbutton (_("아이디 저장: 켜짐") if persistent.save_id else _("아이디 저장: 꺼짐")):
                            style ("rp_btn_mint" if persistent.save_id else "rp_button")
                            xsize 320
                            text_size 26
                            action ToggleField(persistent, "save_id")
                        hbox:
                            spacing 18
                            if G.player:
                                textbutton _("로그아웃") style "rp_btn_pink" xsize 250 text_size 28 action Jump("logout_flow")
                            if not renpy.emscripten:
                                textbutton _("게임 종료") style "rp_btn_orange" xsize 250 text_size 28 action Quit(confirm=True)
