﻿# TODO: Translation updated at 2026-09-28 16:13

translate schinese strings:

    # game/rpg/screens_fun.rpy:21
    old "레이팅  %d"
    new "评分  %d"

    # game/rpg/screens_fun.rpy:22
    old "%d승  %d패"
    new "%d胜  %d负"

    # game/rpg/screens_fun.rpy:27
    old "PVP 코인  %d"
    new "PVP币  %d"

    # game/rpg/screens_fun.rpy:28
    old "코인 %d개  >  강화석 1개"
    new "%d枚币  >  1个强化石"

    # game/rpg/screens_fun.rpy:35
    old "상대는 실시간으로 움직이는 AI예요.\n이기면 레이팅, 코인, 골드를 얻고\n져도 골드와 코인을 조금 받아요.\n\n스킬을 이어 쓰면 콤보로 피해가 늘고,\n기절하면 잠깐 조작할 수 없어요."
    new "对手是实时行动的AI。\n获胜可获得评分、代币与金币，\n落败也能获得少量金币与代币。\n\n连续使用技能可通过连击提升伤害，\n眩晕时会暂时无法操作。"

    # game/rpg/screens_fun.rpy:36
    old "상대 새로고침"
    new "刷新对手"

    # game/rpg/screens_fun.rpy:47
    old "도전 상대"
    new "挑战对象"

    # game/rpg/screens_fun.rpy:66
    old "어려움"
    new "困难"

    # game/rpg/screens_fun.rpy:66
    old "쉬움"
    new "简单"

    # game/rpg/screens_fun.rpy:67
    old "도전 >"
    new "挑战 >"

    # game/rpg/screens_fun.rpy:78
    old "방어 기록"
    new "防守记录"

    # game/rpg/screens_fun.rpy:80
    old "아직 도전받은 기록이 없어요."
    new "还没有被挑战的记录。"

    # game/rpg/screens_fun.rpy:82
    old "%s 님의 도전  %s\n%s"
    new "%s 的挑战  %s\n%s"

    # game/rpg/screens_fun.rpy:82
    old "방어 성공"
    new "防守成功"

    # game/rpg/screens_fun.rpy:82
    old "방어 실패"
    new "防守失败"

    # game/rpg/screens_fun.rpy:172
    old "항복 (Esc)"
    new "投降（Esc）"

    # game/rpg/screens_fun.rpy:234
    old "결과를 서버에 반영하지 못했어요."
    new "无法将结果同步到服务器。"

    # game/rpg/screens_fun.rpy:241
    old "레이팅  %+d   (%d  %s)"
    new "评分  %+d   (%d  %s)"

    # game/rpg/screens_fun.rpy:247
    old "PVP 코인 +%d"
    new "PVP币 +%d"

    # game/rpg/screens_fun.rpy:271
    old "일일 미션"
    new "每日任务"

    # game/rpg/screens_fun.rpy:272
    old "매일 오전 0시(KST)에 초기화돼요."
    new "每天凌晨0点（KST）重置。"

    # game/rpg/screens_fun.rpy:285
    old "%d / %d   보상: 골드 %s, 강화석 %d"
    new "%d / %d   奖励：金币 %s，强化石 %d"

    # game/rpg/screens_fun.rpy:286
    old "수령 완료"
    new "已领取"

    # game/rpg/screens_fun.rpy:286
    old "보상 받기"
    new "领取奖励"

    # game/rpg/screens_fun.rpy:303
    old "올 클리어 보너스"
    new "全部完成奖励"

    # game/rpg/screens_fun.rpy:304
    old "강화석 +%d, 각성 결정 +1, 경험치 부스트 %d분"
    new "强化石 +%d，觉醒结晶 +1，经验加成 %d分钟"

    # game/rpg/screens_fun.rpy:305
    old "보너스 받기"
    new "领取奖励"

    # game/rpg/screens_fun.rpy:322
    old "출석 체크"
    new "签到"

    # game/rpg/screens_fun.rpy:324
    old "연속 출석  %d일"
    new "连续签到  %d天"

    # game/rpg/screens_fun.rpy:337
    old "%d일"
    new "%d天"

    # game/rpg/screens_fun.rpy:338
    old "완료"
    new "完成"

    # game/rpg/screens_fun.rpy:338
    old "대박"
    new "超值"

    # game/rpg/screens_fun.rpy:341
    old "오늘의 보상 (%d일차)"
    new "今日奖励（第%d天）"

    # game/rpg/screens_fun.rpy:342
    old "골드 %s\n강화석 %d%s"
    new "金币 %s\n强化石 %d%s"

    # game/rpg/screens_fun.rpy:342
    old "\n경험치 부스트 1시간"
    new "\n经验加成1小时"

    # game/rpg/screens_fun.rpy:343
    old "출석하기"
    new "签到"

    # game/rpg/screens_fun.rpy:345
    old "오늘은 이미 출석했어요.\n내일 또 만나요!"
    new "今天已经签到过了。\n明天再见！"

    # game/rpg/screens_fun.rpy:346
    old "7일째는 강화석과 경험치 부스트가 듬뿍!\n하루를 거르면 처음부터 다시 시작해요."
    new "第7天可获得大量强化石与经验加成！\n中断一天将从头开始。"

    # game/rpg/screens_fun.rpy:364
    old "레벨 랭킹"
    new "等级排行"

    # game/rpg/screens_fun.rpy:366
    old "%2d위   %s   Lv.%d"
    new "第%2d名   %s   Lv.%d"

    # game/rpg/screens_fun.rpy:368
    old "내 순위: %s위 / %d명"
    new "我的排名：第%s名 / 共%d人"

    # game/rpg/screens_fun.rpy:378
    old "PVP 랭킹"
    new "PVP排行"

    # game/rpg/screens_fun.rpy:380
    old "%2d위   %s   %s  %d"
    new "第%2d名   %s   %s  %d"

