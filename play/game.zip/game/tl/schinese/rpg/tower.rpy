# 무한의 탑 / 업적 문자열

translate schinese strings:

    old "무한의 탑"
    new "无尽之塔"

    old "최고 기록  %d층"
    new "最高纪录  %d层"

    old "%d층 도전"
    new "挑战 %d层"

    old "보스 체력 %s"
    new "Boss生命 %s"

    old "층보스! 보상 2배 + 각성 결정"
    new "层主！奖励翻倍 + 觉醒结晶"

    old "클리어 보상"
    new "通关奖励"

    old "경험치 +%s   골드 +%s   강화석 +%d"
    new "经验 +%s   金币 +%s   强化石 +%d"

    old "도전!"
    new "挑战！"

    old "무한의 탑 순위"
    new "无尽之塔排名"

    old "아직 기록이 없어요."
    new "暂无记录。"

    old "%d층"
    new "%d层"

    old "%d층 돌파!"
    new "突破 %d层！"

    old "업적"
    new "成就"

    old "업적 보상을 받았어요!"
    new "已领取成就奖励！"

    old "Lv.%d 달성"
    new "达到 Lv.%d"

    old "솔로 보스 %d회 처치"
    new "单人Boss击败 %d次"

    old "레이드 %d회 승리"
    new "团本胜利 %d次"

    old "PVP %d승"
    new "PVP %d胜"

    old "무한의 탑 %d층 도달"
    new "无尽之塔到达 %d层"

    old "전직하기"
    new "完成转职"

    old "골드 %s   강화석 %d"
    new "金币 %s   强化石 %d"

    old "   각성 결정 %d"
    new "   觉醒结晶 %d"
