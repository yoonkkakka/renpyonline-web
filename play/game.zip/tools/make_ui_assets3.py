"""허브 아이콘(히로인/경매장/가방) + 유혈 이펙트(피 튀김, 얼룩, 저체력 비네트) 에셋 생성."""
import math
import random
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

OUT = Path(__file__).resolve().parent.parent / "game" / "gui" / "rp"
SS = 4


def hexc(h, a=255):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) + (a,)


def heart_pts(cx, cy, sz):
    pts = []
    for i in range(120):
        t = i / 120 * 2 * math.pi
        x = 16 * math.sin(t) ** 3
        y = -(13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t))
        pts.append((cx + x * sz, cy + y * sz))
    return pts


def menu_icon(name, draw_fn, bg):
    size = 128
    im = Image.new("RGBA", (size * SS, size * SS), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.ellipse((0, 0, size * SS - 1, size * SS - 1), fill=hexc("#ffffff"))
    d.ellipse((8 * SS, 8 * SS, (size - 8) * SS, (size - 8) * SS), fill=hexc(bg))
    draw_fn(d, SS)
    im.resize((size, size), Image.LANCZOS).save(OUT / name)


def love(d, s):
    w = hexc("#ffffff")
    d.polygon(heart_pts(52 * s, 66 * s, 1.75 * s), fill=w)
    d.polygon(heart_pts(86 * s, 48 * s, 0.95 * s), fill=hexc("#ffe0ee"))
    for (x, y, r) in ((92, 84, 5), (34, 36, 4)):
        d.ellipse(((x - r) * s, (y - r) * s, (x + r) * s, (y + r) * s), fill=hexc("#fff4a8"))


def auction(d, s):
    w = hexc("#ffffff")
    for i, y in enumerate((88, 74, 60)):
        d.ellipse((34 * s, y * s, 94 * s, (y + 20) * s), fill=w, outline=hexc("#d98a00"), width=3 * s)
    d.polygon([(64 * s, 40 * s), (69 * s, 52 * s), (82 * s, 52 * s), (72 * s, 60 * s), (76 * s, 72 * s), (64 * s, 65 * s),
               (52 * s, 72 * s), (56 * s, 60 * s), (46 * s, 52 * s), (59 * s, 52 * s)], fill=hexc("#ffd23a"))


def bag(d, s):
    w = hexc("#ffffff")
    d.arc((46 * s, 30 * s, 82 * s, 66 * s), 180, 360, fill=w, width=6 * s)          # 손잡이
    d.polygon([(34 * s, 50 * s), (94 * s, 50 * s), (100 * s, 100 * s), (28 * s, 100 * s)], fill=w)   # 가방 몸통
    d.line((34 * s, 68 * s, 94 * s, 68 * s), fill=hexc("#3fbf9c"), width=4 * s)
    d.ellipse((58 * s, 64 * s, 70 * s, 76 * s), fill=hexc("#3fbf9c"))


menu_icon("ic_love.png", love, "#ff5c8a")
menu_icon("ic_auction.png", auction, "#ffa51f")
menu_icon("ic_bag.png", bag, "#3fbf9c")


# ── 피 튀김(스타일화된 게임 이펙트) ──────────────────────────
def splat(seed, size=256):
    rnd = random.Random(seed)
    W = size * SS
    im = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = W / 2
    dark, mid, light = hexc("#7a0b1e"), hexc("#b3122c"), hexc("#e0284a")
    # 중심 덩어리
    for _ in range(9):
        r = rnd.uniform(0.10, 0.20) * W
        ox, oy = rnd.uniform(-0.1, 0.1) * W, rnd.uniform(-0.1, 0.1) * W
        d.ellipse((c + ox - r, c + oy - r, c + ox + r, c + oy + r), fill=dark)
    # 사방으로 튀는 줄기 + 끝 방울
    for _ in range(rnd.randint(9, 13)):
        a = rnd.uniform(0, 2 * math.pi)
        ln = rnd.uniform(0.22, 0.46) * W
        wd = rnd.uniform(0.018, 0.05) * W
        x1, y1 = c + math.cos(a) * 0.08 * W, c + math.sin(a) * 0.08 * W
        x2, y2 = c + math.cos(a) * ln, c + math.sin(a) * ln
        d.line((x1, y1, x2, y2), fill=dark, width=int(wd * 1.6))
        d.line((x1, y1, x2, y2), fill=mid, width=int(wd))
        r = wd * rnd.uniform(0.9, 1.6)
        d.ellipse((x2 - r, y2 - r, x2 + r, y2 + r), fill=mid)
    for _ in range(rnd.randint(10, 18)):                          # 흩뿌려진 작은 방울
        a = rnd.uniform(0, 2 * math.pi)
        dist = rnd.uniform(0.3, 0.48) * W
        r = rnd.uniform(0.008, 0.028) * W
        x, y = c + math.cos(a) * dist, c + math.sin(a) * dist
        d.ellipse((x - r, y - r, x + r, y + r), fill=mid)
    # 중심 하이라이트
    r = 0.11 * W
    d.ellipse((c - r, c - r, c + r, c + r), fill=mid)
    r = 0.05 * W
    d.ellipse((c - r * 1.4, c - r * 1.6, c - r * 0.2, c - r * 0.5), fill=light)
    im = im.filter(ImageFilter.GaussianBlur(SS * 0.8))
    return im.resize((size, size), Image.LANCZOS)


for i in range(1, 5):
    splat(i * 17).save(OUT / f"blood_{i}.png")

# 저체력/피격용 붉은 비네트 (화면 가장자리만 붉게)
W, H = 960, 540
vg = Image.new("RGBA", (W, H))
px = vg.load()
for y in range(H):
    for x in range(W):
        dx, dy = (x - W / 2) / (W / 2), (y - H / 2) / (H / 2)
        d = min(1.0, math.sqrt(dx * dx * 0.9 + dy * dy))
        a = int(max(0.0, (d - 0.55) / 0.45) ** 2 * 210)
        px[x, y] = (150, 0, 25, a)
vg.resize((1920, 1080), Image.BICUBIC).save(OUT / "blood_vignette.png")
print("assets3 ok")
