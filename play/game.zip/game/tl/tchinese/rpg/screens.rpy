﻿# TODO: Translation updated at 2026-09-28 16:26

translate tchinese strings:

    # game/rpg/screens.rpy:64
    old "서버에 연결하는 중"
    new "正在連線伺服器"

    # game/rpg/screens.rpy:64
    old "처음 접속하면 서버가 깨어나느라 최대 1분쯤 걸려요"
    new "首次連線時伺服器喚醒最多需要1分鐘左右"

    # game/rpg/screens.rpy:107
    old "신체를 단련해 서울의 필드 보스를 쓰러뜨려요!"
    new "鍛鍊身體，擊敗首爾的野外首領吧！"

    # game/rpg/screens.rpy:109
    old "아이디"
    new "賬號"

    # game/rpg/screens.rpy:114
    old "비밀번호"
    new "密碼"

    # game/rpg/screens.rpy:119
    old "아이디 저장: 켜짐"
    new "記住賬號：開"

    # game/rpg/screens.rpy:119
    old "아이디 저장: 꺼짐"
    new "記住賬號：關"

    # game/rpg/screens.rpy:127
    old "로그인"
    new "登入"

    # game/rpg/screens.rpy:128
    old "회원가입"
    new "註冊"

    # game/rpg/screens.rpy:129
    old "회원가입은 공식 홈페이지에서 해 주세요!"
    new "請到官方網站進行註冊！"

    # game/rpg/screens.rpy:159
    old "서울 마을"
    new "首爾村莊"

    # game/rpg/screens.rpy:166
    old "경험치 부스트 ON  %s"
    new "經驗加成 開啟  %s"

    # game/rpg/screens.rpy:173
    old "캐릭터 / 강화"
    new "角色／強化"

    # game/rpg/screens.rpy:174
    old "필드 보스"
    new "野外首領"

    # game/rpg/screens.rpy:175
    old "자동 사냥"
    new "自動狩獵"

    # game/rpg/screens.rpy:178
    old "PVP 아레나"
    new "PVP競技場"

    # game/rpg/screens.rpy:179
    old "미션 / 출석"
    new "任務／簽到"

    # game/rpg/screens.rpy:180
    old "랭킹"
    new "排行榜"

    # game/rpg/screens.rpy:183
    old "히로인"
    new "女主角"

    # game/rpg/screens.rpy:184
    old "경매장"
    new "拍賣行"

    # game/rpg/screens.rpy:185
    old "가방 / 상점"
    new "揹包／商店"

    # game/rpg/screens.rpy:188
    old "로그아웃"
    new "登出"

    # game/rpg/screens.rpy:190
    old "[[DEV] 만렙"
    new "[DEV]滿級"

    # game/rpg/screens.rpy:212
    old "전신 일러스트 업로드"
    new "上傳全身插畫"

    # game/rpg/screens.rpy:217
    old "이미지는 Storage가 아닌 DB에 코드로 저장돼요"
    new "圖片以程式碼形式存於資料庫，而非儲存桶"

    # game/rpg/screens.rpy:230
    old "신체 강화"
    new "身體強化"

    # game/rpg/screens.rpy:231
    old "각성"
    new "覺醒"

    # game/rpg/screens.rpy:231
    old "각성 (잠김)"
    new "覺醒（未解鎖）"

    # game/rpg/screens.rpy:233
    old "현재 한도: %d단계 (레벨 4당 1단계)"
    new "當前上限：%d級（每4級+1級）"

    # game/rpg/screens.rpy:247
    old "%s  %d단계"
    new "%s  %d級"

    # game/rpg/screens.rpy:253
    old "한도 도달"
    new "已達上限"

    # game/rpg/screens.rpy:255
    old "강화 %s G + %d석"
    new "強化 %s 金 + %d 石"

    # game/rpg/screens.rpy:256
    old "강화할 때마다 12% 확률로 대성공(2단계 상승)!"
    new "每次強化有12%機率大成功（提升2級）！"

    # game/rpg/screens.rpy:260
    old "각성 잠김"
    new "覺醒未解鎖"

    # game/rpg/screens.rpy:261
    old "신체 6부위를 모두 50단계로 만들면 열려요.\n현재 %d / 6 부위 완료"
    new "將全部6個身體部位強化至50級即可解鎖。\n當前完成 %d / 6 部位"

    # game/rpg/screens.rpy:262
    old "각성하면 부위마다 +3단계 상당의 능력치를 얻고,\n치명타/쿨타임/회피 상한도 늘어나요."
    new "覺醒後每個部位可獲得相當於+3級的屬性，\n暴擊/冷卻/閃避上限也會提升。"

    # game/rpg/screens.rpy:264
    old "각성 결정  %d"
    new "覺醒結晶  %d"

    # game/rpg/screens.rpy:265
    old "10번~ 보스, PVP 승리, 전설 상자, 일일 올클리어로 얻어요."
    new "可透過10號以後的首領、PVP勝利、傳說寶箱、每日全清獲得。"

    # game/rpg/screens.rpy:277
    old "%s  각성 %d / %d"
    new "%s  覺醒 %d / %d"

    # game/rpg/screens.rpy:278
    old "신체 +%d단계 상당"
    new "相當於身體 +%d級"

    # game/rpg/screens.rpy:283
    old "최대 각성"
    new "已達最大覺醒"

    # game/rpg/screens.rpy:286
    old "각성 %s G + 결정 %d"
    new "覺醒 %s 金 + 結晶 %d"

    # game/rpg/screens.rpy:297
    old "능력치"
    new "屬性"

    # game/rpg/screens.rpy:298
    old "체력  %s"
    new "體力  %s"

    # game/rpg/screens.rpy:299
    old "공격력  %s"
    new "攻擊力  %s"

    # game/rpg/screens.rpy:300
    old "방어력  %s"
    new "防禦力  %s"

    # game/rpg/screens.rpy:301
    old "기력  %s (+%.1f/초)"
    new "氣力  %s（+%.1f/秒）"

    # game/rpg/screens.rpy:302
    old "치명타  %.1f%%"
    new "暴擊  %.1f%%"

    # game/rpg/screens.rpy:303
    old "쿨타임 감소  %.1f%%"
    new "冷卻縮減  %.1f%%"

    # game/rpg/screens.rpy:304
    old "회피  %.1f%%"
    new "閃避  %.1f%%"

    # game/rpg/screens.rpy:305
    old "자연 회복  %.2f%%/초"
    new "自然恢復  %.2f%%/秒"

    # game/rpg/screens.rpy:307
    old "스킬"
    new "技能"

    # game/rpg/screens.rpy:311
    old "Space. 방어 자세"
    new "空格鍵．防禦姿態"

    # game/rpg/screens.rpy:349
    old "권장 Lv.%d"
    new "推薦 Lv.%d"

    # game/rpg/screens.rpy:354
    old "처치 %d회"
    new "擊敗 %d次"

    # game/rpg/screens.rpy:376
    old "사냥 지역 선택"
    new "選擇狩獵地區"

    # game/rpg/screens.rpy:387
    old "(사냥 중)"
    new "（狩獵中）"

    # game/rpg/screens.rpy:404
    old "자동 사냥 현황"
    new "自動狩獵狀態"

    # game/rpg/screens.rpy:406
    old "진행 중인 사냥이 없어요.\n왼쪽에서 지역을 고르면\n최대 8시간까지 자동으로 진행돼요."
    new "目前沒有進行中的狩獵。\n在左側選擇地區，\n最多可自動進行8小時。"

    # game/rpg/screens.rpy:410
    old "사냥 시간  %d시간 %d분%s"
    new "狩獵時間  %d小時%d分鐘%s"

    # game/rpg/screens.rpy:410
    old "  (최대)"
    new "  （最長）"

    # game/rpg/screens.rpy:411
    old "경험치 획득  %s"
    new "獲得經驗  %s"

    # game/rpg/screens.rpy:412
    old "골드 획득  %s"
    new "獲得金幣  %s"

    # game/rpg/screens.rpy:413
    old "강화석 획득  %s"
    new "獲得強化石  %s"

    # game/rpg/screens.rpy:414
    old "수령하기"
    new "領取"

    # game/rpg/screens.rpy:417
    old "경험치 부스트 ON  (%s)"
    new "經驗加成 開啟  (%s)"

    # game/rpg/screens.rpy:419
    old "경험치 부스트 OFF\n(필드 보스를 처치하면 30분간 +50%)"
    new "經驗加成 關閉\n（擊敗野外首領可獲得30分鐘+50%）"

    # game/rpg/screens.rpy:420
    old "새로고침"
    new "重新整理"

    # game/rpg/screens.rpy:439
    old "기력 %d"
    new "氣力 %d"

    # game/rpg/screens.rpy:454
    old "방어\n자세"
    new "防禦\n姿態"

    # game/rpg/screens.rpy:541
    old "!! 강공격 준비 !!"
    new "!! 強力攻擊預備 !!"

    # game/rpg/screens.rpy:543
    old "다음 공격: %s"
    new "下一次攻擊：%s"

    # game/rpg/screens.rpy:550
    old "접근: %s"
    new "應對方式：%s"

    # game/rpg/screens.rpy:553
    old "도망 (Esc)"
    new "逃跑（Esc）"

    # game/rpg/screens.rpy:570
    old "체력 %s / %s"
    new "體力 %s / %s"

    # game/rpg/screens.rpy:572
    old "기력 %d / %d"
    new "氣力 %d / %d"

    # game/rpg/screens.rpy:620
    old "경험치 +%s"
    new "經驗 +%s"

    # game/rpg/screens.rpy:625
    old "골드 +%s"
    new "金幣 +%s"

    # game/rpg/screens.rpy:630
    old "강화석 +%d"
    new "強化石 +%d"

    # game/rpg/screens.rpy:636
    old "각성 결정 +%d"
    new "覺醒結晶 +%d"

    # game/rpg/screens.rpy:638
    old "레벨 UP!  Lv.%d"
    new "等級提升!  Lv.%d"

    # game/rpg/screens.rpy:641
    old "전리품 상자  %s"
    new "戰利品箱  %s"

    # game/rpg/screens.rpy:643
    old "보너스 골드 +%s%s"
    new "獎勵金幣 +%s%s"

    # game/rpg/screens.rpy:643
    old "   강화석 +%d"
    new "   強化石 +%d"

    # game/rpg/screens.rpy:645
    old "전설 보너스: 경험치 부스트 +1시간!"
    new "傳說獎勵：經驗加成 +1小時！"

    # game/rpg/screens.rpy:646
    old "경험치 부스트 30분 획득 (+50%)"
    new "獲得經驗加成30分鐘 (+50%)"

    # game/rpg/screens.rpy:648
    old "승리했지만 서버 검증에 실패했어요."
    new "雖然獲勝了，但伺服器驗證失敗了。"

    # game/rpg/screens.rpy:650
    old "전투에서 물러났어요"
    new "已從戰鬥中撤退"

    # game/rpg/screens.rpy:653
    old "신체를 더 강화하고 다시 도전해요!"
    new "先強化身體，再重新挑戰吧！"

    # game/rpg/screens.rpy:654
    old "확인"
    new "確認"

    # game/rpg/screens.rpy:664
    old "이용 등급 안내"
    new "使用等級提示"

    # game/rpg/screens.rpy:680
    old "15세 이용가"
    new "15歲以上適用"

    # game/rpg/screens.rpy:684
    old "언어의 부적절성"
    new "語言不當"

    # game/rpg/screens.rpy:686
    old "이 게임에는 거친 언어가 포함되어 있어요.\n※ 원스토어 등급분류 결과에 따른 표기입니다."
    new "本遊戲包含粗俗語言內容。\n※ 本標示依據 ONE store 官方分級結果標註。"

    # game/rpg/screens.rpy:681
    old "화면을 누르면 넘어가요"
    new "點選畫面即可繼續"

# TODO: Translation updated at 2026-09-28 18:01

translate tchinese strings:

    # game/rpg/screens.rpy:194
    old "레이드"
    new "團本"

