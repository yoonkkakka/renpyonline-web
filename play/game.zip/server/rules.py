"""게임 규칙 / 밸런스 상수. 클라이언트(Ren'Py)는 /api/meta 로 이 데이터를 그대로 받아 쓴다."""
from __future__ import annotations

import math

MAX_LEVEL = 200

# ── 캐릭터 기본 스탯 (레벨 기준) ───────────────────────────────
def base_atk(lv: int) -> float: return 10 + 4 * lv
def base_hp(lv: int) -> float: return 100 + 40 * lv
def base_def(lv: int) -> float: return 2 + 1.2 * lv
def base_mana(lv: int) -> float: return 100 + lv

def exp_to_next(lv: int) -> int:
    """lv -> lv+1 에 필요한 경험치. 200 은 만렙이라 0."""
    if lv >= MAX_LEVEL:
        return 0
    return int(40 * lv ** 2.2 + 60)

# ── 신체 강화 (장비 없음: 몸을 직접 강화) ─────────────────────
BODY_PARTS = [
    {"id": "muscle", "name": "근육",   "desc": "공격력 +4% / 단계"},
    {"id": "heart",  "name": "심장",   "desc": "최대 체력 +5% / 단계"},
    {"id": "bone",   "name": "골격",   "desc": "방어력 +5% / 단계"},
    {"id": "nerve",  "name": "신경",   "desc": "쿨타임 -0.6%, 치명타 +0.4% / 단계"},
    {"id": "lung",   "name": "폐",     "desc": "최대 기력 및 기력 회복 +4% / 단계"},
    {"id": "legs",   "name": "다리",   "desc": "회피율 +0.3% / 단계 (최대 15%)"},
]
BODY_IDS = [p["id"] for p in BODY_PARTS]
BODY_MAX = 50

def body_cap(char_level: int) -> int:
    """신체 부위 강화 상한: 캐릭터 레벨 4당 1단계 (200레벨 = 50단계)."""
    return min(BODY_MAX, max(1, math.ceil(char_level / 4)))

def body_cost(part_level: int) -> tuple[int, int]:
    """part_level -> +1 에 필요한 (골드, 강화석)."""
    return int(50 * (part_level + 1) ** 1.6), 1 + part_level // 4

# ── 스킬 (숫자 키 1~6, Space = 방어 자세) ─────────────────────
SKILLS = [
    {"slot": 1, "name": "강타",        "level": 1,   "mult": 1.3,  "hits": 1, "cd": 0.7,  "mana": 0,   "heal": 0,    "stun": 0},
    {"slot": 2, "name": "연속 타격",   "level": 10,  "mult": 0.85, "hits": 3, "cd": 3.0,  "mana": 15,  "heal": 0,    "stun": 0},
    {"slot": 3, "name": "회복 호흡",   "level": 20,  "mult": 0,    "hits": 0, "cd": 15.0, "mana": 30,  "heal": 0.25, "stun": 0},
    {"slot": 4, "name": "섬광 돌진",   "level": 40,  "mult": 4.5,  "hits": 1, "cd": 8.0,  "mana": 30,  "heal": 0,    "stun": 1.5},
    {"slot": 5, "name": "폭발 기합",   "level": 70,  "mult": 8.0,  "hits": 1, "cd": 14.0, "mana": 50,  "heal": 0,    "stun": 0},
    {"slot": 6, "name": "서울 브레이커", "level": 120, "mult": 20.0, "hits": 1, "cd": 40.0, "mana": 100, "heal": 0,    "stun": 2.0},
    # 회복 계열: 대회복 / 기력 회복
    {"slot": 7, "name": "생명의 파동", "level": 90,  "mult": 0,    "hits": 0, "cd": 40.0, "mana": 80,  "heal": 0.5,  "stun": 0},
    {"slot": 8, "name": "명상 호흡",   "level": 50,  "mult": 0,    "hits": 0, "cd": 30.0, "mana": 0,   "heal": 0,    "stun": 0, "mana_gain": 0.5},
]
GUARD = {"name": "방어 자세", "duration": 0.9, "cd": 4.0, "reduce": 0.6}

# ── 필드 보스 16종 (번호 = 사용자가 지정한 순서, 레벨 제한 오름차순) ──
# bg: 배경 타일 번호(t01~t16), sprite: 시트 상 스프라이트 번호(s01~s16)
BOSSES = [
    {"id": 1,  "name": "서울의 여왕",     "min_level": 1,   "bg": 1,  "sprite": 1,  "attack": "여왕의 사격",     "interval": 3.0},
    {"id": 2,  "name": "강남의 철갑 경찰", "min_level": 8,   "bg": 2,  "sprite": 2,  "attack": "진압 포격",       "interval": 3.0},
    {"id": 3,  "name": "경복궁의 환령",   "min_level": 16,  "bg": 11, "sprite": 3,  "attack": "원한의 참격",     "interval": 2.9},
    {"id": 4,  "name": "한강의 야경 마녀", "min_level": 25,  "bg": 13, "sprite": 4,  "attack": "야경 저주",       "interval": 2.8},
    {"id": 5,  "name": "홍대의 불량소녀", "min_level": 35,  "bg": 14, "sprite": 5,  "attack": "스트리트 저격",   "interval": 2.7},
    {"id": 6,  "name": "넥슨의 노예",     "min_level": 45,  "bg": 12, "sprite": 6,  "attack": "야근 데이터 폭풍", "interval": 2.6},
    {"id": 7,  "name": "교통혼잡맨",      "min_level": 55,  "bg": 16, "sprite": 7,  "attack": "정체 유발 사격",  "interval": 2.5},
    {"id": 8,  "name": "롯데타워 토끼",   "min_level": 70,  "bg": 5,  "sprite": 8,  "attack": "거대 발구르기",   "interval": 2.5},
    {"id": 9,  "name": "서울 이륙녀",     "min_level": 85,  "bg": 10, "sprite": 10, "attack": "이륙 돌풍",       "interval": 2.4},
    {"id": 10, "name": "국정원",          "min_level": 100, "bg": 3,  "sprite": 12, "attack": "기밀 작전",       "interval": 2.3},
    {"id": 11, "name": "해킹소녀",        "min_level": 115, "bg": 7,  "sprite": 11, "attack": "시스템 침투",     "interval": 2.2},
    {"id": 12, "name": "오세이돈",        "min_level": 130, "bg": 4,  "sprite": 9,  "attack": "해일",            "interval": 2.1},
    {"id": 13, "name": "서울타워 귀신",   "min_level": 145, "bg": 6,  "sprite": 13, "attack": "저주받은 우산",   "interval": 2.0},
    {"id": 14, "name": "아이돌",          "min_level": 160, "bg": 9,  "sprite": 14, "attack": "팬미팅 폭죽",     "interval": 2.0},
    {"id": 15, "name": "드론 조종녀",     "min_level": 180, "bg": 15, "sprite": 15, "attack": "드론 편대 폭격",  "interval": 1.9},
    {"id": 16, "name": "서울의 종말",     "min_level": 200, "bg": 6,  "sprite": 16, "attack": "종말의 촉수",     "interval": 1.8},
]
BOSS_BY_ID = {b["id"]: b for b in BOSSES}

BATTLE_TIME_LIMIT = 240          # 초
HEAVY_EVERY = 4                  # 보스 N번째 공격은 강공격
HEAVY_MULT = 2.2
BOSS_KILL_SECONDS = 45           # 기준(강화 0) 플레이어가 보스를 잡는 데 걸리는 시간
BOSS_KILL_SECONDS_FINAL = 60
PLAYER_SURVIVE_SECONDS = 55      # 기준 플레이어가 무방비로 버티는 시간
REF_SKILL_MULT_PER_SEC = 2.2     # 기준 초당 공격력 배율(스킬 혼합)

def boss_stats(boss_id: int) -> dict:
    b = BOSS_BY_ID[boss_id]
    lv = max(1, b["min_level"])
    kill_s = BOSS_KILL_SECONDS_FINAL if boss_id == 16 else BOSS_KILL_SECONDS
    hp = base_atk(lv) * REF_SKILL_MULT_PER_SEC * kill_s
    k = 50 + 6 * lv
    mitig = k / (k + base_def(lv))
    avg_heavy = ((HEAVY_EVERY - 1) + HEAVY_MULT) / HEAVY_EVERY
    atk = base_hp(lv) / PLAYER_SURVIVE_SECONDS * b["interval"] / mitig / avg_heavy
    return {
        "id": b["id"], "name": b["name"], "level": lv, "hp": int(hp), "atk": round(atk, 1),
        "interval": b["interval"], "attack": b["attack"], "k": k,
        "heavy_every": HEAVY_EVERY, "heavy_mult": HEAVY_MULT,
    }

def boss_rewards(boss_id: int) -> dict:
    lv = max(1, BOSS_BY_ID[boss_id]["min_level"])
    return {
        "exp": int(exp_to_next(min(lv, MAX_LEVEL - 1)) * 0.35) + 20,
        "gold": int(40 * lv ** 1.3) + 30,
        "stones": 1 + lv // 25,
    }

BOOST_SECONDS = 1800   # 보스 처치 시 경험치 부스트 지속
BOOST_MULT = 1.5

# ── 자동 사냥 센터 ───────────────────────────────────────────
HUNT_MAX_MINUTES = 480
HUNT_ZONES = [
    {"id": 1,  "name": "한강 둔치 산책로",  "min_level": 1},
    {"id": 2,  "name": "동네 골목 언덕길",  "min_level": 10},
    {"id": 3,  "name": "지하철 서울역",     "min_level": 22},
    {"id": 4,  "name": "강남 대로",         "min_level": 34},
    {"id": 5,  "name": "홍대 뒷골목",       "min_level": 48},
    {"id": 6,  "name": "옥상 정원",         "min_level": 62},
    {"id": 7,  "name": "김포 공항 활주로",  "min_level": 78},
    {"id": 8,  "name": "여의도 사무 빌딩",  "min_level": 95},
    {"id": 9,  "name": "한강 야경 다리",    "min_level": 115},
    {"id": 10, "name": "남산 야경 공원",    "min_level": 135},
    {"id": 11, "name": "롯데타워 전망대",   "min_level": 160},
    {"id": 12, "name": "무너진 서울 중심",  "min_level": 185},
]
HUNT_ZONE_BY_ID = {z["id"]: z for z in HUNT_ZONES}

def hunt_rates(zone_id: int) -> dict:
    lv = HUNT_ZONE_BY_ID[zone_id]["min_level"]
    return {
        "exp_per_min": exp_to_next(lv) * 0.02 + 2,
        "gold_per_min": 6 * lv ** 1.3 + 5,
        "stone_per_10min": 1 + lv // 50,
    }

# ── 스탯 계산 ────────────────────────────────────────────────
def compute_stats(level: int, body: dict, awake: dict | None = None, bonus: dict | None = None) -> dict:
    st = _compute_stats(level, body, awake)
    b = bonus or {}
    if b:
        st["hp"] = int(st["hp"] * (1 + b.get("hp", 0)))
        st["atk"] = round(st["atk"] * (1 + b.get("atk", 0)), 1)
        st["mana"] = round(st["mana"] * (1 + b.get("mana", 0)), 1)
        st["crit"] = round(min(0.6, st["crit"] + b.get("crit", 0)), 3)
        st["dodge"] = round(min(0.30, st["dodge"] + b.get("dodge", 0)), 3)
    return st


def _compute_stats(level: int, body: dict, awake: dict | None = None) -> dict:
    awake = awake or {}
    # 각성 1단계 = 신체 단계 +AWAKE_EQ 상당
    g = lambda k: int(body.get(k, 0)) + AWAKE_EQ * int(awake.get(k, 0))
    return {
        "atk": round(base_atk(level) * (1 + 0.04 * g("muscle")), 1),
        "hp": int(base_hp(level) * (1 + 0.05 * g("heart"))),
        "def": round(base_def(level) * (1 + 0.05 * g("bone")), 1),
        "mana": round(base_mana(level) * (1 + 0.04 * g("lung")), 1),
        "mana_regen": round(6.0 * (1 + 0.04 * g("lung")), 2),
        "crit": round(min(0.6, 0.05 + 0.004 * g("nerve")), 3),
        "crit_dmg": 1.8,
        "cd_reduce": round(min(0.40, 0.006 * g("nerve")), 3),
        "dodge": round(min(0.25, 0.003 * g("legs")), 3),
        "hp_regen": round(0.0001 * g("heart"), 5),   # 초당 최대 체력 비율(심장 단계가 높을수록 자연 회복)
    }

def max_possible_damage(stats: dict, level: int, seconds: float) -> float:
    """서버 검증용: 주어진 시간 동안 이론상 낼 수 있는 최대 피해(전 타 치명타, 마나 무시)."""
    total = 0.0
    for s in SKILLS:
        if s["level"] > level or s["hits"] == 0:
            continue
        cd = max(0.2, s["cd"] * (1 - stats["cd_reduce"]))
        uses = int(seconds / cd) + 1
        total += uses * s["hits"] * stats["atk"] * s["mult"] * 1.1 * stats["crit_dmg"]
    return total * COMBO_MAX_MULT


# ══════════════════════════════════════════════════════════════
# 재미 요소 / PVP
# ══════════════════════════════════════════════════════════════
KST_OFFSET = 9 * 3600

# 콤보: 스킬을 COMBO_WINDOW 초 안에 이어서 쓰면 콤보가 쌓이고 피해가 늘어난다.
COMBO_WINDOW = 2.0
COMBO_STEP = 0.02
COMBO_MAX = 10                      # 최대 +20%
COMBO_MAX_MULT = 1 + COMBO_STEP * COMBO_MAX

# 신체 강화 "대성공": 일정 확률로 2단계 상승(비용은 1단계분)
ENHANCE_JACKPOT_CHANCE = 0.12

# 보스 전리품 상자
LOOT_TABLE = [
    {"rarity": "일반", "weight": 60, "mult": 1},
    {"rarity": "희귀", "weight": 25, "mult": 2},
    {"rarity": "영웅", "weight": 12, "mult": 4},
    {"rarity": "전설", "weight": 3,  "mult": 10},
]

# 일일 미션
DAILY_MISSIONS = [
    {"id": "boss", "name": "필드 보스 3회 처치", "need": 3, "gold": 300, "stones": 2},
    {"id": "body", "name": "신체 강화 2회",       "need": 2, "gold": 200, "stones": 1},
    {"id": "hunt", "name": "자동 사냥 1회 수령",  "need": 1, "gold": 200, "stones": 1},
    {"id": "pvp",  "name": "PVP 3회 도전",        "need": 3, "gold": 400, "stones": 2},
]
DAILY_ALL_BONUS = {"stones": 5, "boost_seconds": 3600}

def daily_reward(m: dict, level: int) -> tuple[int, int]:
    return int(m["gold"] * (1 + level / 20)), m["stones"]

# 출석 (7일 주기, 7일차 대박)
def checkin_reward(streak: int, level: int) -> dict:
    day = (streak - 1) % 7 + 1
    gold = int((300 + level * 20) * day)
    stones = 1 + day // 2
    boost = 0
    if day == 7:
        stones += 5
        boost = 3600
    return {"day": day, "gold": gold, "stones": stones, "boost_seconds": boost}

# ── PVP ──────────────────────────────────────────────────────
PVP_START_RATING = 1000
PVP_HP_MULT = 3.0            # 대인전은 체력을 늘려 몇십 초 교전이 되게 한다
PVP_TIME_LIMIT = 120
PVP_K = 32
PVP_COIN_PER_STONE = 10
PVP_TIERS = [(1900, "마스터"), (1700, "다이아"), (1500, "플래티넘"), (1300, "골드"), (1100, "실버"), (0, "브론즈")]

def pvp_tier(rating: int) -> str:
    for th, name in PVP_TIERS:
        if rating >= th:
            return name
    return "브론즈"

def pvp_stats(level: int, body: dict, awake: dict | None = None, bonus: dict | None = None) -> dict:
    st = compute_stats(level, body, awake, bonus)
    st["hp"] = int(st["hp"] * PVP_HP_MULT)
    return st

def pvp_mitigation(target_level: int, target_def: float) -> float:
    k = 50 + 6 * target_level
    return k / (k + target_def)

def elo_delta(my: int, opp: int, won: bool) -> int:
    exp = 1 / (1 + 10 ** ((opp - my) / 400))
    d = round(PVP_K * ((1.0 if won else 0.0) - exp))
    return max(5, d) if won else min(-5, d)

BOT_NAMES = ["서울의 그림자", "한강 검객", "강남 저격수", "홍대 파이터", "여의도 전사",
             "남산 수호자", "종로 자객", "잠실 격투가", "마포 방랑자", "용산 기갑병"]
# tier: (레벨 보정, 신체 비율, AI 효율, 레이팅 보정, 보상 배수)
BOT_TIERS = {
    "easy":   {"dl": -3, "body": 0.40, "eff": 0.55, "dr": -120, "reward": 0.8},
    "normal": {"dl": 0,  "body": 0.70, "eff": 0.75, "dr": 0,    "reward": 1.0},
    "hard":   {"dl": 4,  "body": 1.00, "eff": 0.95, "dr": 150,  "reward": 1.4},
}
# 봇 초상화로 쓸 보스 시트 스프라이트 번호(사람 모양)
BOT_SPRITES = [1, 3, 4, 5, 6, 7, 9, 10, 11, 12, 13, 14, 15]

def pvp_rewards(level: int, won: bool, mult: float, coin_bonus: int) -> dict:
    gold = int((20 * max(1, level) ** 1.3 + 20) * mult)
    if won:
        return {"gold": gold, "coins": 3 + coin_bonus}
    return {"gold": gold // 4, "coins": 1}


# ══════════════════════════════════════════════════════════════
# 각성: 신체 6부위를 모두 BODY_MAX 로 만들면 열리는 다음 성장 단계
# ══════════════════════════════════════════════════════════════
AWAKE_MAX = 10
AWAKE_EQ = 3            # 각성 1단계 = 신체 3단계 상당 (부위당 최대 +30단계)

def awake_unlocked(body: dict) -> bool:
    return all(int(body.get(k, 0)) >= BODY_MAX for k in BODY_IDS)

def awake_cost(a: int) -> tuple[int, int]:
    """각성 a -> a+1 에 필요한 (골드, 각성 결정)."""
    return int(20000 * (a + 1) ** 1.5), 1 + a

def crystal_drop_boss(boss_id: int) -> int:
    """고레벨 보스가 각성 결정을 떨어뜨린다."""
    if boss_id >= 16:
        return 3
    if boss_id >= 10:
        return 1
    return 0


# ══════════════════════════════════════════════════════════════
# 스토리 대치: 보스전 전에 대사를 나누고 접근 방식을 고른다 (선택이 실제 전투를 바꾼다)
# ══════════════════════════════════════════════════════════════
APPROACHES = {
    "direct":  {"name": "정면 돌파", "hp": 1.0,  "atk": 1.0,  "reward": 1.0,
                "desc": "아무 변화 없음"},
    "analyze": {"name": "약점 분석", "hp": 0.85, "atk": 1.0,  "reward": 0.9,
                "desc": "보스 체력 -15% / 보상 -10%"},
    "taunt":   {"name": "도발",      "hp": 1.0,  "atk": 1.25, "reward": 1.4,
                "desc": "보스 공격력 +25% / 보상 +40%"},
    # 대화는 도박: 50% 로 보스가 방심(체력 -30%, 공격 -10%), 50% 로 격노(공격 +40%)
    "talk":    {"name": "대화 시도", "hp": 1.0,  "atk": 1.0,  "reward": 1.0,
                "desc": "도박: 50% 방심(체력 -30%) / 50% 격노(공격 +40%)",
                "success": {"hp": 0.7, "atk": 0.9}, "fail": {"atk": 1.4}},
}


# ══════════════════════════════════════════════════════════════
# 아이템 / 히로인(전연령 미연시) / 경매장 (게임 골드만 사용, 현금 거래 없음)
# ══════════════════════════════════════════════════════════════
def _boss_price(min_level: int) -> int:
    return int(60 * max(1, min_level) ** 1.25) + 30


HEROINES = [
    {"id": "queen", "name": "서울의 여왕", "boss_id": 1, "sprite": 1, "likes": "gift_flower",
     "bonus": ("hp", 0.10), "bonus_text": "최대 체력",
     "desc": "도도하지만 은근히 외로움을 타는 서울의 여왕.",
     "events": [{"aff": 20, "title": "왕관 뒤의 표정"}, {"aff": 50, "title": "한강 산책"}, {"aff": 90, "title": "왕관을 내려놓고"}]},
    {"id": "witch", "name": "한강의 야경 마녀", "boss_id": 4, "sprite": 4, "likes": "gift_book",
     "bonus": ("mana", 0.15), "bonus_text": "최대 기력",
     "desc": "밤의 한강을 지키는 조용한 마녀. 책과 별을 좋아한다.",
     "events": [{"aff": 20, "title": "밤의 도서관"}, {"aff": 50, "title": "별빛 산책로"}, {"aff": 90, "title": "마녀의 마지막 소원"}]},
    {"id": "pilot", "name": "서울 이륙녀", "boss_id": 9, "sprite": 10, "likes": "gift_sweet",
     "bonus": ("dodge", 0.05), "bonus_text": "회피율",
     "desc": "언제나 어딘가로 떠나려던 공항의 승무원. 단 걸 좋아한다.",
     "events": [{"aff": 20, "title": "활주로의 노을"}, {"aff": 50, "title": "여행 계획"}, {"aff": 90, "title": "돌아올 곳"}]},
    {"id": "idol", "name": "아이돌", "boss_id": 14, "sprite": 14, "likes": "gift_sweet",
     "bonus": ("crit", 0.05), "bonus_text": "치명타율",
     "desc": "무대 위에서는 빛나지만 무대 아래서는 서툰 아이돌.",
     "events": [{"aff": 20, "title": "연습실의 불빛"}, {"aff": 50, "title": "비 오는 날의 무대"}, {"aff": 90, "title": "단 한 명의 관객"}]},
]
HEROINE_BY_ID = {h["id"]: h for h in HEROINES}
AFF_MAX = 100
TALKS_PER_DAY = 3
_MEM_NAMES = {
    "queen": ["여왕의 레이스 손수건", "작은 왕관 핀", "야경 엽서"],
    "witch": ["별빛이 든 작은 병", "낡은 마녀의 일기장", "마녀의 등불"],
    "pilot": ["항공 배지", "여행 티켓", "활주로 모래시계"],
    "idol": ["사인 카드", "응원봉", "무대 리본"],
}

ITEMS: dict[str, dict] = {}
for _b in BOSSES:
    ITEMS[f"trophy_{_b['id']}"] = {"name": f"{_b['name']} 트로피", "price": _boss_price(_b["min_level"]),
                                    "kind": "trophy", "desc": f"{_b['name']}을(를) 쓰러뜨린 증표."}
for _h in HEROINES:
    for _k, _n in enumerate(_MEM_NAMES[_h["id"]], 1):
        ITEMS[f"mem_{_h['id']}_{_k}"] = {"name": _n, "price": 1500 * _k * _k, "kind": "memento",
                                          "desc": f"{_h['name']}과(와)의 추억이 담긴 기념품."}
ITEMS["gift_flower"] = {"name": "꽃다발", "price": 300, "kind": "gift", "aff": 6, "desc": "호감도 +6 (좋아하면 +9)"}
ITEMS["gift_sweet"] = {"name": "달콤한 디저트", "price": 700, "kind": "gift", "aff": 14, "desc": "호감도 +14 (좋아하면 +21)"}
ITEMS["gift_book"] = {"name": "신비한 책", "price": 1500, "kind": "gift", "aff": 30, "desc": "호감도 +30 (좋아하면 +45)"}
ITEMS["exp_potion"] = {"name": "경험치 물약", "price": 2500, "kind": "potion", "desc": "사용하면 경험치 부스트 30분"}
SHOP_ITEMS = ["gift_flower", "gift_sweet", "gift_book", "exp_potion"]

NPC_SELL_RATE = 0.40          # 상점에 되팔 때 기본가 비율
AUCTION_FEE = 0.08            # 낙찰 수수료
AUCTION_MAX_LISTINGS = 10
AUCTION_HOURS = (6, 12, 24)
AUCTION_MAX_MULT = 100        # 시작가 상한: 기본가의 100배
AUCTION_MIN_RAISE = 0.05      # 최소 입찰 인상률
TROPHY_DROP_CHANCE = 0.35

def heroine_bonus(extra: dict, clears: dict) -> dict:
    """처치한 보스에 해당하는 히로인의 호감도에 비례한 전투 보너스."""
    out: dict[str, float] = {}
    hs = (extra or {}).get("heroines", {})
    for h in HEROINES:
        if int((clears or {}).get(str(h["boss_id"]), 0)) > 0:
            aff = int(hs.get(h["id"], {}).get("aff", 0))
            k, v = h["bonus"]
            out[k] = out.get(k, 0.0) + v * aff / AFF_MAX
    return out
