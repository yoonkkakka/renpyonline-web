﻿# TODO: Translation updated at 2026-09-28 18:01

translate schinese strings:

    # game/rpg/screens_raid.rpy:42
    old "레이드 2~4인"
    new "团本 2~4人"

    # game/rpg/screens_raid.rpy:63
    old "레이드 매칭 대기 중..."
    new "团本匹配中…"

    # game/rpg/screens_raid.rpy:64
    old "대기 인원  %d / 4"
    new "等待人数  %d / 4"

    # game/rpg/screens_raid.rpy:67
    old "%.0f초 후 자동 시작 (인원이 차면 즉시 시작)"
    new "%.0f秒后自动开始（人数满员则立即开始）"

    # game/rpg/screens_raid.rpy:69
    old "2명 이상 모이면 카운트다운이 시작돼요."
    new "满2人以上就会开始倒计时。"

    # game/rpg/screens_raid.rpy:87
    old " (나)"
    new "（我）"

    # game/rpg/screens_raid.rpy:90
    old "이탈함"
    new "已离开"

    # game/rpg/screens_raid.rpy:92
    old "전투 불능"
    new "战斗不能"

    # game/rpg/screens_raid.rpy:94
    old "기여 %s"
    new "贡献 %s"

    # game/rpg/screens_raid.rpy:257
    old "레이드 승리!"
    new "团本胜利!"

    # game/rpg/screens_raid.rpy:258
    old "내 기여도  %.0f%%"
    new "我的贡献度  %.0f%%"

    # game/rpg/screens_raid.rpy:279
    old "보스는 쓰러졌지만 보상 수령에 실패했어요."
    new "首领虽然倒下了，但领取奖励失败了。"

    # game/rpg/screens_raid.rpy:281
    old "전멸했어요..."
    new "全灭了…"

    # game/rpg/screens_raid.rpy:284
    old "시간 초과로 레이드가 종료됐어요."
    new "因超时，团本已结束。"

    # game/rpg/screens_raid.rpy:286
    old "레이드에서 물러났어요"
    new "已退出团本"

