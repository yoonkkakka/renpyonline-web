# 렌파이 온라인 - Ren'Py 클라이언트 (서버: FastAPI + Supabase)

# 기본 메인 메뉴를 건너뛰고 바로 게임(로그인 창)으로 진입
label main_menu:
    return

label start:
    $ quick_menu = False
    $ login_prefill = None
    # 게임을 켜자마자(로그인 화면 이미지를 불러오는 동안) 하트 로딩 화면을 보여준다.
    scene expression "#3a2a7a"
    show screen connecting("게임을 불러오는 중", "잠시만 기다려 주세요")
    $ renpy.start_predict_screen("login_screen")
    $ bgm("town", 0.5)
    $ renpy.pause(1.6, hard=True)
    hide screen connecting
    call screen rating_notice
    jump login_flow

label login_flow:
    scene expression "#3a2a7a"
    $ bgm("town", 0.8)
    call screen login_screen
    $ login_info = _return
    $ login_prefill = login_info[0]
    show screen connecting
    $ login_ok = do_login(login_info[0], login_info[1], login_info[2])
    hide screen connecting
    if not login_ok:
        jump login_flow
    jump hub_loop

label hub_loop:
    scene expression "#3a2a7a"
    $ bgm("town")
    call screen hub
    if _return == "char":
        call screen character_screen
    elif _return == "boss":
        call screen boss_select
        if _return != "back":
            call boss_fight(_return)
    elif _return == "hunt":
        $ refresh_hunt()
        call screen hunt_screen
    elif _return == "pvp":
        call pvp_lobby
    elif _return == "missions":
        $ refresh_daily()
        call screen missions_screen
    elif _return == "heroine":
        call heroine_flow
    elif _return == "auction":
        call auction_flow
    elif _return == "bag":
        call bag_flow
    elif _return == "ranking":
        $ refresh_ranking()
        if G.ranking:
            call screen ranking_screen
    elif _return == "logout":
        jump logout_flow
    jump hub_loop

label logout_flow:
    $ logout()
    $ login_prefill = None
    jump login_flow

# ESC / 오른쪽 클릭으로 열리는 렌파이 기본 메뉴를 게임 설정 화면으로 바꾼다.
label game_menu:
    call screen rp_settings
    jump _noisy_return

label boss_fight(boss_id):
    $ first_clear = story_first(boss_id)
    $ bgm("story")
    call boss_story(boss_id)
    $ started = start_battle(boss_id, story_approach)
    if not started:
        return
    if B.approach["id"] == "talk":
        $ story_reaction(boss_id, B.approach["outcome"])
    $ bgm("battle", 0.5)
    call screen battle_screen
    $ outcome = _return
    $ bgm("town")
    $ fin = finish_battle(outcome)
    call screen battle_result(outcome, fin)
    if outcome == "win" and fin and first_clear:
        call boss_epilogue(boss_id)
    return

label pvp_lobby:
    $ refresh_pvp()
    call screen pvp_screen
    if _return == "back":
        return
    call pvp_fight(_return)
    jump pvp_lobby

label pvp_fight(target_id):
    $ started = start_pvp(target_id)
    if not started:
        return
    $ bgm("battle", 0.5)
    call screen pvp_battle_screen
    $ outcome = _return
    $ bgm("town")
    $ fin = finish_pvp(outcome)
    call screen pvp_result(outcome, fin)
    return
