﻿# TODO: Translation updated at 2026-09-28 16:13

translate schinese strings:

    # game/rpg/battle.rpy:117
    old "시간 초과!"
    new "时间到!"

    # game/rpg/battle.rpy:131
    old "회피!"
    new "闪避!"

    # game/rpg/battle.rpy:132
    old "공격을 회피했다!"
    new "闪避了攻击!"

    # game/rpg/battle.rpy:136
    old " (방어)"
    new "（防御）"

    # game/rpg/battle.rpy:144
    old " (강공격)"
    new "（强力攻击）"

    # game/rpg/battle.rpy:146
    old "%s: %s 피해%s"
    new "%s：%s 伤害%s"

    # game/rpg/battle.rpy:149
    old "쓰러졌다..."
    new "倒下了…"

    # game/rpg/battle.rpy:158
    old "Lv.%d 에 해금"
    new "Lv.%d 解锁"

    # game/rpg/battle.rpy:163
    old "기력 부족!"
    new "气力不足!"

    # game/rpg/battle.rpy:172
    old "%s: 체력 %s 회복"
    new "%s：恢复体力 %s"

    # game/rpg/battle.rpy:176
    old "기력 +"
    new "气力 +"

    # game/rpg/battle.rpy:177
    old "%s: 기력 %s 회복"
    new "%s：恢复气力 %s"

    # game/rpg/battle.rpy:197
    old " (치명타)"
    new "（暴击）"

    # game/rpg/battle.rpy:200
    old "기절!"
    new "眩晕!"

    # game/rpg/battle.rpy:204
    old "보스를 쓰러뜨렸다!"
    new "击败了首领!"

    # game/rpg/battle.rpy:214
    old "방어 자세!"
    new "防御姿态!"

