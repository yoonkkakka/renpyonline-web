# PVP 아레나: 상대(유저 스냅샷 / 봇)와 실시간 교전. 상대는 AI 가 조종하고 승패는 서버가 검증한다.
# 숫자키 1~6 = 스킬, Space = 방어 자세, Esc = 항복

init -4 python:
    class Fighter(object):
        def __init__(self, name, level, st):
            self.name = name
            self.level = level
            self.st = st
            self.hp = float(st["hp"])
            self.hp_max = float(st["hp"])
            self.mana = float(st["mana"])
            self.ready = dict((s["slot"], 0.0) for s in G.meta["skills"])
            self.guard_until = 0.0
            self.guard_ready = 0.0
            self.stun_until = 0.0
            self.hit_until = 0.0

    class PvpBattle(object):
        def __init__(self, res, opp_img):
            self.id = res["battle_id"]
            self.skills = G.meta["skills"]
            self.guard = G.meta["guard"]
            self.limit = G.meta["pvp"]["time_limit"]
            self.opp_info = res["opp"]
            self.opp_img = opp_img
            self.me = Fighter(G.player["username"], G.player["level"], res["stats"])
            self.opp = Fighter(self.opp_info["name"], self.opp_info["level"], self.opp_info["stats"])
            self.level = self.me.level
            self.st = self.me.st
            now = time.time()
            self.t0 = now
            self.last = now
            self.ai_next = now + 1.8
            self.floaters = []
            self.log = []
            self.result = None
            self.combo = 0
            self.last_cast = 0.0
            self.blood = []
            self.stains = []
            self.bg_path = "images/bg/t15.webp"

        # ── 화면용 조회 (skill_slot 화면과 같은 인터페이스) ──
        @property
        def mana(self):
            return self.me.mana

        def cd_left(self, slot):
            return max(0.0, self.me.ready[slot] - time.time())

        def guard_left(self):
            return max(0.0, self.me.guard_ready - time.time())

        def guarding(self):
            return time.time() < self.me.guard_until

        def stunned(self):
            return time.time() < self.me.stun_until

        def time_left(self):
            return max(0.0, self.limit - (time.time() - self.t0))

        def splash(self, target_is_opp, n=1, big=False):
            if not persistent.opt_blood:
                return
            now = time.time()
            cx, cy = (1250, 450) if target_is_opp else (300, 450)
            for _ in range(n):
                self.blood.append({"t": now, "x": cx + random.randint(-140, 140), "y": cy + random.randint(-150, 150),
                                   "img": random.randint(1, 4), "z": random.uniform(0.7, 1.4) * (1.3 if big else 1.0),
                                   "rot": random.randint(0, 359), "life": 1.1})
            if big or random.random() < 0.3:
                self.stains.append({"x": cx + random.randint(-240, 240), "y": cy + random.randint(-180, 200),
                                    "img": random.randint(1, 4), "z": random.uniform(0.6, 1.1), "rot": random.randint(0, 359)})
                self.stains = self.stains[-14:]

        # ── 내부 ──
        def add_log(self, text, color="#dfe8ff"):
            self.log.append((text, color))
            self.log = self.log[-7:]

        def float_text(self, text, x, y, color="#ffffff", size=44):
            self.floaters.append({"text": text, "x": x + random.randint(-40, 40), "y": y,
                                  "color": color, "size": size, "t": time.time()})

        def _mit(self, target):
            k = 50 + 6 * target.level
            return k / (k + target.st["def"])

        def _hit(self, atk, tgt, sk, now, bonus, fx, fy, mine):
            if tgt.hp <= 0 or not sk["hits"]:
                return 0
            if random.random() < tgt.st["dodge"]:
                self.float_text(_("회피!"), fx, fy, "#8ff0ff", 40)
                return 0
            total = 0
            crits = 0
            for _ in range(sk["hits"]):
                d = atk.st["atk"] * sk["mult"] * bonus * random.uniform(0.9, 1.1) * self._mit(tgt)
                if random.random() < atk.st["crit"]:
                    d *= atk.st["crit_dmg"]
                    crits += 1
                total += int(d)
            if now < tgt.guard_until:
                total = int(total * (1.0 - self.guard["reduce"]))
            total = max(1, total)
            tgt.hp = max(0.0, tgt.hp - total)
            tgt.hit_until = now + 0.15
            self.splash(tgt is self.opp, 3 if crits else 1, bool(crits))
            self.float_text(fmt(total) + ("!" if crits else ""), fx, fy,
                            "#ffe066" if crits else ("#ffffff" if mine else "#ff6b6b"),
                            58 if crits else 44)
            return total

        def _cast(self, atk, tgt, sk, now, mine, bonus=1.0):
            atk.mana -= sk["mana"]
            atk.ready[sk["slot"]] = now + max(0.2, sk["cd"] * (1.0 - atk.st["cd_reduce"]))
            if sk["heal"]:
                amt = int(atk.hp_max * sk["heal"])
                atk.hp = min(atk.hp_max, atk.hp + amt)
                self.float_text("+" + fmt(amt), 320 if mine else 1400, 380, "#7dff9b")
                self.add_log(_("%s: %s 체력 %s 회복") % (atk.name, sk["name"], fmt(amt)), "#9dffb5")
            if sk.get("mana_gain"):
                got = int(atk.st["mana"] * sk["mana_gain"])
                atk.mana = min(atk.st["mana"], atk.mana + got)
                self.float_text(_("기력 +") + fmt(got), 320 if mine else 1400, 340, "#7fb0ff", 40)
            dealt = self._hit(atk, tgt, sk, now, bonus, 1400 if mine else 320, 300 if mine else 380, mine)
            if sk["stun"] and dealt:
                tgt.stun_until = max(tgt.stun_until, now + sk["stun"])
                self.float_text(_("기절!"), 1400 if mine else 320, 240, "#ffd27f", 40)
            if dealt:
                self.add_log(_("%s: %s %s 피해") % (atk.name, sk["name"], fmt(dealt)), "#dfe8ff" if mine else "#ffb0b0")

        def tick(self):
            if self.result:
                return
            now = time.time()
            dt = min(0.25, now - self.last)
            self.last = now
            for f in (self.me, self.opp):
                f.mana = min(f.st["mana"], f.mana + f.st["mana_regen"] * dt)
                if f.st.get("hp_regen"):
                    f.hp = min(f.hp_max, f.hp + f.hp_max * f.st["hp_regen"] * dt)
            self.floaters = [f for f in self.floaters if now - f["t"] < 1.0]
            self.blood = [b for b in self.blood if now - b["t"] < b["life"]]
            if self.combo and now - self.last_cast > G.meta["combo"]["window"]:
                self.combo = 0
            if now - self.t0 >= self.limit:
                self.result = "lose"
                self.add_log(_("시간 초과! (무승부는 패배)"), "#ff8080")
                return
            if now >= self.ai_next:
                self._ai(now)
            self._check_end()

        def _ai(self, now):
            eff = self.opp_info["eff"]
            self.ai_next = now + random.uniform(0.7, 1.1) / max(0.3, eff)
            o = self.opp
            if now < o.stun_until:
                self.ai_next = max(self.ai_next, o.stun_until + 0.2)
                return
            usable = [s for s in self.skills
                      if s["level"] <= o.level and o.ready[s["slot"]] <= now and o.mana >= s["mana"]]
            heal = [s for s in usable if s["heal"]]
            if heal and o.hp < o.hp_max * 0.4:
                self._cast(o, self.me, max(heal, key=lambda s: s["heal"]), now, False)
                return
            gain = [s for s in usable if s.get("mana_gain")]
            if gain and o.mana < o.st["mana"] * 0.3:
                self._cast(o, self.me, gain[0], now, False)
                return
            dmg = [s for s in usable if s["hits"]]
            if dmg:
                sk = max(dmg, key=lambda s: s["mult"] * s["hits"])
                self._cast(o, self.me, sk, now, False)

        def _check_end(self):
            if self.result:
                return
            if self.opp.hp <= 0:
                self.result = "win"
                self.add_log(_("승리!"), "#ffe066")
            elif self.me.hp <= 0:
                self.result = "lose"
                self.add_log(_("패배..."), "#ff8080")

        # ── 입력 ──
        def use_skill(self, slot):
            if self.result:
                return
            now = time.time()
            m = self.me
            if now < m.stun_until:
                return
            sk = [s for s in self.skills if s["slot"] == slot][0]
            if sk["level"] > self.level:
                renpy.notify(_("Lv.%d 에 해금") % sk["level"])
                return
            if now < m.ready[slot]:
                return
            if m.mana < sk["mana"]:
                self.float_text(_("기력 부족!"), 320, 420, "#7fa8ff", 36)
                return
            cb = G.meta["combo"]
            bonus = (1.0 + cb["step"] * self.combo) if sk["hits"] else 1.0
            self.combo = min(cb["max"], self.combo + 1)
            self.last_cast = now
            self._cast(m, self.opp, sk, now, True, bonus)
            self._check_end()

        def use_guard(self):
            if self.result:
                return
            now = time.time()
            m = self.me
            if now < m.guard_ready or now < m.stun_until:
                return
            m.guard_until = now + self.guard["duration"]
            m.guard_ready = now + self.guard["cd"]

        def flee(self):
            if not self.result:
                self.result = "lose"

    PB = None

    def pb_tick():
        PB.tick()
        return PB.result

    def pb_skill(slot):
        PB.use_skill(slot)
        return PB.result

    def pb_guard():
        PB.use_guard()

    def pb_flee():
        PB.flee()
        return PB.result

    def start_pvp(target_id):
        global PB
        res = safe(api, "POST", "/api/pvp/start", {"target": target_id})
        if not res:
            return False
        info = res["opp"]
        if info["bot"]:
            img = "images/boss/s%02d.png" % info["sprite"]
        else:
            img = "images/placeholder.png"
            av = safe(api, "GET", "/api/pvp/avatar?target=" + target_id)
            if av and av.get("data"):
                try:
                    img = im.Data(base64.b64decode(av["data"].split(";base64,", 1)[1]), "opp.png")
                except Exception:
                    pass
        PB = PvpBattle(res, img)
        return True

    def finish_pvp(outcome):
        return safe(api, "POST", "/api/pvp/finish",
                    {"battle_id": PB.id, "result": "win" if outcome == "win" else "lose"})
