# 웹 빌드 전용 로그인: Ren'Py 화면 키보드(영문/숫자만, 화면을 가림) 대신 브라우저 기본 입력창을 쓴다.
# (폰 키보드, 한글 입력, 비밀번호 마스킹, 비밀번호 관리자 지원)

init -7 python:
    import json

    _WEB_LOGIN_JS = r"""
(function(pref, save, msg, signup){
  var old = document.getElementById('rp-login'); if (old) old.remove();
  window.__rp_login = null;
  var d = document.createElement('div'); d.id = 'rp-login';
  d.style.cssText = 'position:fixed;left:0;top:0;right:0;bottom:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:rgba(58,42,122,.35);font-family:"Malgun Gothic","Noto Sans KR",sans-serif;overflow:auto;padding:12px;';
  var esc = function(s){ return String(s).replace(/[&<>"]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); };
  d.innerHTML =
    '<form id="rp-form" autocomplete="on" style="width:min(92vw,430px);background:rgba(47,37,96,.96);border:3px solid #cdbdff;border-radius:26px;padding:22px 22px 20px;color:#fffaf2;box-shadow:0 8px 0 rgba(0,0,0,.2)">' +
    '<div style="text-align:center;font-size:30px;font-weight:800;color:#fff3a8;text-shadow:2px 2px 0 #6a3aa8,-2px -2px 0 #6a3aa8,2px -2px 0 #6a3aa8,-2px 2px 0 #6a3aa8">렌파이 온라인</div>' +
    '<div style="text-align:center;font-size:13px;color:#ffe1f3;margin:6px 0 10px">' + __TAGLINE__ + '</div>' +
    '<label style="display:block;font-size:13px;color:#ffd6ec;margin:8px 0 4px">' + __LBL_ID__ + '</label>' +
    '<input id="rp-u" name="username" type="text" autocomplete="username" autocapitalize="off" maxlength="16" value="' + esc(pref) + '" style="width:100%;box-sizing:border-box;padding:12px 14px;border-radius:18px;border:3px solid #ff9dc0;background:#fff4e4;color:#5a3f7a;font-size:17px">' +
    '<label style="display:block;font-size:13px;color:#ffd6ec;margin:10px 0 4px">' + __LBL_PW__ + '</label>' +
    '<input id="rp-p" name="password" type="password" autocomplete="current-password" maxlength="64" style="width:100%;box-sizing:border-box;padding:12px 14px;border-radius:18px;border:3px solid #ff9dc0;background:#fff4e4;color:#5a3f7a;font-size:17px">' +
    '<label style="display:flex;gap:8px;align-items:center;margin:12px 0 0;font-size:14px;color:#dcd4ff"><input id="rp-s" type="checkbox" ' + (save ? 'checked' : '') + ' style="width:18px;height:18px"> ' + __LBL_SAVE__ + '</label>' +
    '<div id="rp-msg" style="min-height:20px;margin:10px 0 0;font-size:14px;color:#ffb0c8">' + esc(msg) + '</div>' +
    '<button type="submit" style="width:100%;margin-top:6px;border:0;border-radius:20px;padding:13px;font-size:20px;font-weight:800;color:#fff;background:linear-gradient(#69b4ff,#3d80ff);box-shadow:0 5px 0 #2456b3">' + __BTN_LOGIN__ + '</button>' +
    '<button type="button" id="rp-reg" style="width:100%;margin-top:12px;border:0;border-radius:20px;padding:12px;font-size:17px;font-weight:800;color:#fff;background:linear-gradient(#ff92bd,#ff5f9b);box-shadow:0 5px 0 #c23a73">' + __BTN_SIGNUP__ + '</button>' +
    '<div style="text-align:center;font-size:12px;color:#c9c0ea;margin-top:10px">' + __HINT_ROTATE__ + '</div>' +
    '</form>';
  document.body.appendChild(d);
  // 입력창의 키 입력이 게임 화면까지 새어나가 단축키(예: S=스크린샷)로 처리되는 것을 막는다.
  ['keydown', 'keyup', 'keypress'].forEach(function(evt){
    d.addEventListener(evt, function(e){ e.stopPropagation(); }, false);
  });
  var f = document.getElementById('rp-form');
  f.addEventListener('submit', function(e){
    e.preventDefault();
    window.__rp_login = JSON.stringify({u: document.getElementById('rp-u').value, p: document.getElementById('rp-p').value, s: document.getElementById('rp-s').checked});
    f.style.display = 'none'; d.style.pointerEvents = 'none'; d.style.background = 'transparent';
  });
  document.getElementById('rp-reg').addEventListener('click', function(){ window.open(signup, '_blank'); });
  setTimeout(function(){ var u = document.getElementById('rp-u'); (u.value ? document.getElementById('rp-p') : u).focus(); }, 50);
})(__PREF__, __SAVE__, __MSG__, __SIGNUP__);
"""

    def web_login_show(prefill, save, msg):
        import emscripten
        js = (_WEB_LOGIN_JS.replace("__PREF__", json.dumps(prefill)).replace("__SAVE__", json.dumps(bool(save)))
              .replace("__MSG__", json.dumps(msg)).replace("__SIGNUP__", json.dumps(SIGNUP_URL))
              .replace("__TAGLINE__", json.dumps(_("신체를 단련해 서울의 필드 보스를 쓰러뜨려요!")))
              .replace("__LBL_ID__", json.dumps(_("아이디")))
              .replace("__LBL_PW__", json.dumps(_("비밀번호")))
              .replace("__LBL_SAVE__", json.dumps(_("아이디 저장")))
              .replace("__BTN_LOGIN__", json.dumps(_("로그인")))
              .replace("__BTN_SIGNUP__", json.dumps(_("회원가입 (공식 홈페이지)")))
              .replace("__HINT_ROTATE__", json.dumps(_("폰은 가로 화면으로 돌리면 더 잘 보여요"))))
        emscripten.run_script(js)

    def web_login_read():
        import emscripten
        s = emscripten.run_script_string("window.__rp_login || ''")
        return json.loads(s) if s else None

    def web_login_hide():
        import emscripten
        emscripten.run_script("var e=document.getElementById('rp-login'); if(e) e.remove(); window.__rp_login=null;")

    def web_login_wait():
        """제출될 때까지 화면(배경)을 계속 그리며 기다린다. 제출 값을 dict 로 반환."""
        while True:
            renpy.pause(0.1, hard=True)
            r = web_login_read()
            if r:
                return r

screen web_login_bg():
    add "images/bg/t01.webp"
    add Solid("#4a3a9a66")
    add "gui/rp/sparkle.png" pos (330, 170) zoom 1.4 at rp_bounce
    add "gui/rp/sparkle.png" pos (1520, 260) zoom 1.0 at rp_bounce
    add "gui/rp/deco_heart.png" pos (1450, 700) zoom 1.6 at rp_bounce
    add "gui/rp/deco_heart.png" pos (380, 760) zoom 1.1 at rp_bounce

label web_login_flow:
    $ web_err = ""
    $ web_prefill = persistent.last_user if persistent.save_id else ""
    $ web_save = persistent.save_id
    show screen web_login_bg
    label .again:
    $ web_login_show(web_prefill, web_save, web_err)
    $ web_r = web_login_wait()
    $ persistent.save_id = bool(web_r["s"])
    $ web_prefill = web_r["u"]
    $ web_save = persistent.save_id
    hide screen web_login_bg
    show screen connecting
    $ login_ok = do_login(web_r["u"], web_r["p"], False)
    hide screen connecting
    if login_ok:
        $ web_login_hide()
        return
    $ web_err = G.last_err or _("로그인에 실패했어요.")
    show screen web_login_bg
    jump .again
