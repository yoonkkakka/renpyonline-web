# 가방/상점, 히로인, 경매장 클라이언트 API 도우미 + 히로인 장면

init -6 python:
    G.inv = {"items": [], "shop": [], "mail": []}
    G.heroines = []
    G.gifts = []
    G.auction = {"listings": [], "fee": 8, "max_listings": 10, "hours": [6, 12, 24]}

    def fmt_left(sec):
        sec = max(0, int(sec))
        if sec >= 3600:
            return "%d시간 %d분" % (sec // 3600, (sec % 3600) // 60)
        return "%d분 %d초" % (sec // 60, sec % 60)

    # ── 가방 / 상점 ────────────────────────────────────────
    def refresh_inventory():
        res = safe(api, "GET", "/api/inventory")
        if res:
            G.inv = res

    def shop_buy(item, qty=1):
        if safe(api, "POST", "/api/shop/buy", {"item": item, "qty": qty}):
            renpy.notify("구매했어요!")
            refresh_inventory()

    def use_item(item):
        if safe(api, "POST", "/api/item/use", {"item": item}):
            renpy.notify("경험치 부스트 30분!")
            refresh_inventory()

    def sell_item(item, qty=1):
        res = safe(api, "POST", "/api/item/sell", {"item": item, "qty": qty})
        if res:
            renpy.notify("%s 골드를 받았어요." % fmt(res["gold"]))
            refresh_inventory()

    # ── 히로인 ─────────────────────────────────────────────
    def refresh_heroines():
        res = safe(api, "GET", "/api/heroines")
        if res:
            G.heroines = res["heroines"]
            G.gifts = res["gifts"]

    def heroine_talk_api(hid):
        return safe(api, "POST", "/api/heroines/talk", {"id": hid})

    def heroine_gift_api(hid, item):
        return safe(api, "POST", "/api/heroines/gift", {"id": hid, "item": item})

    def heroine_event_api(hid, idx):
        return safe(api, "POST", "/api/heroines/event", {"id": hid, "idx": idx})

    def heroine_by_id(hid):
        return [h for h in G.heroines if h["id"] == hid][0]

    # ── 경매장 ─────────────────────────────────────────────
    def refresh_auction():
        res = safe(api, "GET", "/api/auction")
        if res:
            G.auction = res
        safe(api, "GET", "/api/me")

    def auction_bid(lid, amount):
        if safe(api, "POST", "/api/auction/bid", {"id": lid, "amount": amount}):
            renpy.notify("입찰했어요! (밀려나면 골드가 돌아와요)")
            refresh_auction()

    def auction_buyout(lid):
        if safe(api, "POST", "/api/auction/buyout", {"id": lid}):
            renpy.notify("즉시 구매 완료!")
            refresh_auction()
            refresh_inventory()

    def auction_cancel(lid):
        if safe(api, "POST", "/api/auction/cancel", {"id": lid}):
            renpy.notify("경매를 취소했어요.")
            refresh_auction()
            refresh_inventory()

    def auction_create_api(item, qty, start, buyout, hours):
        if safe(api, "POST", "/api/auction/create",
                {"item": item, "qty": qty, "start_price": start, "buyout": buyout, "hours": hours}):
            renpy.notify("경매에 올렸어요!")
            refresh_auction()
            refresh_inventory()
            return True

# ── 히로인 장면 (전연령) ──────────────────────────────────────
label heroine_stage(hid):
    python:
        _h = heroine_by_id(hid)
    scene expression ("images/bg/t%02d.webp" % HEROINE_SCENE_BG[hid])
    show expression Transform("images/boss/s%02d.png" % _h["sprite"], fit="contain", xysize=(760, 700)) as story_boss at story_boss_pos
    show expression avatar_disp(460, 700) as story_me at story_me_pos
    with dissolve
    return

label heroine_talk_scene(hid, mood, gain):
    call heroine_stage(hid)
    python:
        _h = heroine_by_id(hid)
        _hc = Character(_h["name"])
        for _l in HEROINE_TALK[hid][mood]:
            renpy.say(_hc, _l)
        renpy.notify("호감도 +%d" % gain)
    return

label heroine_gift_scene(hid, liked, gain):
    call heroine_stage(hid)
    python:
        _h = heroine_by_id(hid)
        _hc = Character(_h["name"])
        renpy.say(_hc, HEROINE_GIFT[hid]["liked" if liked else "normal"])
        renpy.notify("호감도 +%d" % gain)
    return

label heroine_event_scene(hid, idx, item_name):
    call heroine_stage(hid)
    python:
        _h = heroine_by_id(hid)
        _who = {"h": Character(_h["name"]),
                "m": Character(G.player["username"]), "n": None}
        for _w, _t in HEROINE_EVENTS[hid][idx]:
            renpy.say(_who[_w], _t)
        renpy.notify("기념품 획득: " + item_name)
    return

label heroine_flow:
    $ bgm("story")
    $ refresh_heroines()
    call screen heroine_screen
    $ act = _return
    if act == "back":
        $ bgm("town")
        return
    if act[0] == "talk":
        $ res = heroine_talk_api(act[1])
        if res:
            call heroine_talk_scene(act[1], res["mood"], res["gain"])
    elif act[0] == "gift":
        $ res = heroine_gift_api(act[1], act[2])
        if res:
            call heroine_gift_scene(act[1], res["liked"], res["gain"])
    elif act[0] == "event":
        $ res = heroine_event_api(act[1], act[2])
        if res:
            call heroine_event_scene(act[1], act[2], res["item"]["name"])
    jump heroine_flow

label bag_flow:
    $ refresh_inventory()
    call screen bag_screen
    return

label auction_flow:
    $ refresh_auction()
    $ refresh_inventory()
    call screen auction_screen
    return
