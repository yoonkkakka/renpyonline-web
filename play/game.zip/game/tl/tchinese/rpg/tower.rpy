# 무한의 탑 / 업적 문자열

translate tchinese strings:

    old "무한의 탑"
    new "無盡之塔"

    old "최고 기록  %d층"
    new "最高紀錄  %d層"

    old "%d층 도전"
    new "挑戰 %d層"

    old "보스 체력 %s"
    new "Boss生命 %s"

    old "층보스! 보상 2배 + 각성 결정"
    new "層主！獎勵翻倍 + 覺醒結晶"

    old "클리어 보상"
    new "通關獎勵"

    old "경험치 +%s   골드 +%s   강화석 +%d"
    new "經驗 +%s   金幣 +%s   強化石 +%d"

    old "도전!"
    new "挑戰！"

    old "무한의 탑 순위"
    new "無盡之塔排名"

    old "아직 기록이 없어요."
    new "暫無記錄。"

    old "%d층"
    new "%d層"

    old "%d층 돌파!"
    new "突破 %d層！"

    old "업적"
    new "成就"

    old "업적 보상을 받았어요!"
    new "已領取成就獎勵！"

    old "Lv.%d 달성"
    new "達到 Lv.%d"

    old "솔로 보스 %d회 처치"
    new "單人Boss擊敗 %d次"

    old "레이드 %d회 승리"
    new "團本勝利 %d次"

    old "PVP %d승"
    new "PVP %d勝"

    old "무한의 탑 %d층 도달"
    new "無盡之塔到達 %d層"

    old "전직하기"
    new "完成轉職"

    old "골드 %s   강화석 %d"
    new "金幣 %s   強化石 %d"

    old "   각성 결정 %d"
    new "   覺醒結晶 %d"
